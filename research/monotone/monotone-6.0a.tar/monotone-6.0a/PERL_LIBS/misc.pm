use 5.008006;
use strict;
use warnings;


###########################################################
# Perl Procedures written by 
# C. Hillar 
# March 7 2008
#
# May 8 2008: Zach: 1. Enable negative numbers in necklacetables
#         by changing [0-9] into [-0-9], maybe -?[0-9] is better
#   2. Moved some of Frank's Perl functions into this library
#   3. Wrote some rudimentary documentation, bumped version number to 0.01b
#
###########################################################

############################################################
# integer addstring(string)
#
# takes a string which is a delimited list of positive
# integers and adds them together
#
# e.g.  2, 3, 1 -->  6  
# e.g.  2 3 1 -->  6  
#
sub addstring {
	my($string) = @_;
	my $sum = 0;
	# parse string
	while ($string =~ m/([0-9]+)/g) {
  		$sum += $1;
	}
	return $sum;
}

############################################################
# (ref to array of refs arrays) setpartitions_to_arrays(array ref, array ref)
#
# takes a ref to a single array and to a set partition
# and converts them to a ref to array of refs
#
# e.g.  (0,1,2,5,3,4), (2,3,1) ---->  (0,1), (2,5,3), (4)
#
# @a = (0,1,2,5,3,4); @b = (2,3,1);
# $lists = setpartitions_to_arrays(\@a,\@b);
# @list1 = @{${@{$lists}}[0]};
# @list2 = @{${@{$lists}}[1]};
# @list3 = @{${@{$lists}}[2]};
# print @list1;  print "\n";  print @list2;  print "\n"; print @list3;
#
sub setpartitions_to_arrays {
	my ($listref,$setpartref) = @_;
	my @setpart = @{$setpartref};
	my @list = @{$listref};
	my @totlist;
	my $counter = 0;
	for (my $i = 0; $i <= $#setpart; $i++) {
		my @newlist;
		my $lastnum = $counter + $setpart[$i] - 1;
		@newlist = @list[$counter ..  $lastnum];
		$totlist[$i] = \@newlist;
		$counter += $setpart[$i];
	}
	return \@totlist;
}


############################################################
# (array ref, array ref) arrays_to_setpartitions(ref to array of references)
#
# takes a ref to an array of refs and coverts it to refs
# to a single array and a set partition
#
# e.g.  (0,1), (2,5,3), (4) -->  (0,1,2,5,3,4), (2,3,1) 
#
# @a = (0,1); @b = (2,5,3); @c = (4);
# @arr = (\@a,\@b,\@c);
# @tot = arrays_to_setpartitions(\@arr);
# @newlist = @{$tot[0]};
# @setpart = @{$tot[1]};
# print @newlist;  print "\n";  print @setpart;  print "\n";
#
sub arrays_to_setpartitions {
	my ($arrayref) = @_;
	my @sets = @{$arrayref};
	my @newlist;
	my @setpart;
	for (my $i = 0; $i <= $#sets; $i++) {
		push(@newlist,@{$sets[$i]});
		$setpart[$i] = $#{@{$sets[$i]}}+1;
	}
	return (\@newlist,\@setpart);
}



############################################################
# (hashtable) permutationlist_to_permhashtable( string )
#
# takes a string with a list of permuatations and outputs a
# hashtable idexed by permutations and having values he corresponding multiplicities
# 
# e.g.  [1,2,3] [2,3,1] [2,3,1] -->  [1,2,3] => 1, [2,3,1] => 2 
#
# $a = "[1,2,3] [2,3,1] [2,3,1]";
# %hash = permutationlist_to_permhashtable($a);
# print $hash("[2,3,1]");
#
sub permutationlist_to_permhashtable {
	my ($list) = @_;
	my %permhash;
	while ($list =~ m/(\[[,0-9]+\])/g) {
		if ( $permhash{$1} ) {
			$permhash{$1} = $permhash{$1}+1;
		} else {
			$permhash{$1} = 1;
		}
	}
	return (%permhash);
}



############################################################
# (array) permutationlist_to_array( string )
#
# takes a string with a list of permuatations and outputs a
# array with these permutations as elements
# 
# e.g.  [1,2,3] [2,3,1] [2,3,1] -->  ('[1,2,3]','[2,3,1]','[2,3,1]') 
#
# $a = "[1,2,3] [2,3,1] [2,3,1]";
# @arr = permutationlist_to_array($a);
# print "@arr\n";
#
sub permutationlist_to_array {
	my ($list) = @_;
	my @permarr;
	while ($list =~ m/(\[[,0-9]+\])/g) {
		push(@permarr,$1);
	}
	return (@permarr);
}


############################################################
# (array) permutationlist_to_arrayNoBrackets( string )
#
# takes a string with a list of permuatations and outputs a
# array with these permutations as elements
# 
# e.g.  [1,2,3] [2,3,1] [2,3,1] -->  ('1,2,3','2,3,1','2,3,1') 
#
# $a = "[1,2,3] [2,3,1] [2,3,1]";
# @arr = permutationlist_to_array($a);
# print "@arr\n";
#
sub permutationlist_to_arrayNoBrackets {
	my ($list) = @_;
	my @permarr;
	while ($list =~ m/\[([,0-9]+)\]/g) {
		push(@permarr,$1);
	}
	return (@permarr);
}


############################################################
# (array) permutation_to_array( string )
#
# takes a string with a single permuatation and outputs an
# array representing this permutation
# 
# e.g.  [1,2,3] -->  (1,2,3) 
#
# $a = "[1,2,3]";
# @arr = permutation_to_array($a);
# print "@arr\n";
#
sub permutation_to_array {
	my ($list) = @_;
	my @permarr;
	while ($list =~ m/([0-9]+)/g) {
		push(@permarr,$1);
	}
	return (@permarr);
}

############################################################
# number ninversions( array )
#
# Computes the number of inversions (length) of an array 
#  representing a permutation 
#
#  e.g. (1,3,5,2,6,4) --> 4
#
sub ninversions{
  my @perm = @_;
  my $ell = 0;
  for (my $i = 0; $i < $#perm; $i++) {
    for (my $j=$i+1; $j <= $#perm; $j++) {
      if ($perm[$i]>$perm[$j]) { $ell++; }
    }
  }
  return ( $ell );
}

#############################################################
# (array of arrays) necklaces_to_arrays( string )
#
# takes a string, which is a list of permutations of 1..m 
# representing necklaces, and returns an array of arrays,
# where the inner array is the list of necklaces, which are
# permutations 0..(m-1) with initial value 0
#
#  my $necklaces='[1,2,3,4][1,3,2,4]';
#  @neck_arr = necklaces_to_arrays($necklaces);
#  print @{$neck_arr[0]}, "\n";
#
sub necklaces_to_arrays {
  my ($necklaces) = @_;
  my @AoA;
  while  ($necklaces =~ m/\[([,0-9]+)\]/g) {
    my $permstring=$1;
    my @perm=();
    while ($permstring =~ m/([0-9])/g) {
      push(@perm,$1-1);
    }
    push( @AoA,  \@perm);
  }
  return ( @AoA );
}
##########################################################3

###########################################################
#
#   get_points ( )  This simply sets the array of points
#                and returns it as a reference to an array of strings
#
sub get_points {
  my @master_points = 
     ("-10","-9","-8","-7","-6","-5","-9/2","-4","-7/2","-10/3","-3","-8/3","-5/2","-7/3",
      "-9/4","-2","-9/5","-7/4","-5/3","-8/5","-3/2","-7/5","-4/3","-5/4","-6/5","-7/6",
      "-8/7","-1","-7/8","-6/7","-5/6","-4/5","-3/4","-5/7","-2/3","-5/8","-3/5","-4/7",
      "-5/9","-1/2","-4/9","-3/7","-2/5","-3/8","-1/3","-3/10","-2/7","-1/4","-2/9","-1/5",
      "-1/6","-1/7","-1/8","-1/9","-1/10","0","1/10","1/9","1/8","1/7","1/6","1/5","2/9",
      "1/4","2/7","3/10","1/3","3/8","2/5","3/7","4/9","1/2","5/9","4/7","3/5","5/8","2/3",
      "5/7","3/4","4/5","5/6","6/7","7/8","1","8/7","7/6","6/5","5/4","4/3","7/5","3/2",
      "8/5","5/3","7/4","9/5","2","9/4","7/3","5/2","8/3","3","10/3","7/2","4","9/2",
      "5","6","7","8","9","10");
  return \@master_points;
}


#########################################################
# fast_cross_number(ref to array of refs to arrays, int n)
#
# Faster Crossing Number calculation using 
# dynamic programming tricks
#
# C. Hillar March 3, 2008
#
# Complexity is O(n(n+m)), which is essentially 
#
#				n^2
#
#  INPUT: Arrays S1,...,Sm of distinct integers from 0 to (n-1)
#  OUTPUT: An integer which is 0 <==> S1,...,Sm are noncrossing
#
#
# @a1 = (0,1);
# @a2 = (2,3);
# @a3 = (4,6);
# @a4 = (5,7);
# @b = (\@a1,\@a2,\@a3,\@a4);
# $n = 8;
# print "The Crossing number is: ".fast_cross_number(\@b,$n)."\n";
#
# Should print 2
#
#
sub fast_cross_number {
	my ($arrayref,$n) = @_;
	my @arrayofSi = @{$arrayref};
	my $CNmin = -1;
	
	# for each cyclic permutation of 0...(n-1)
	for (my $c = 0; $c < $n; $c++) {
		# cyclically permute the integers 0...(n-1)
		for ( my $i = 0; $i <= $#arrayofSi; $i++) {
			for (my $j = 0; $j <= $#{$arrayofSi[$i]}; $j++) {
				 @{$arrayofSi[$i]}[$j] = (@{$arrayofSi[$i]}[$j] + 1) % $n;
			}
		}
		# first make lookup table for which Si are the integers 0..(n-1)
		my @toSi;
		for ( my $i = 0; $i <= $#arrayofSi; $i++) {
			for (my $j = 0; $j <= $#{$arrayofSi[$i]}; $j++) {
				 $toSi[@{$arrayofSi[$i]}[$j]] = $i;
			}
		}
		# compute the maxs and mins - Note: this can be made a bit faster
		my @m; my @M;
		for ( my $i = 0; $i <= $#arrayofSi; $i++) {
			$m[$i] = $n; $M[$i] = 0;
			for (my $j = 0; $j <= $#{$arrayofSi[$i]}; $j++) {
				 if ( @{$arrayofSi[$i]}[$j] < $m[$i] ) {
					$m[$i] = @{$arrayofSi[$i]}[$j];				 				 
				 }
				 if ( @{$arrayofSi[$i]}[$j] > $M[$i] ) {
					$M[$i] = @{$arrayofSi[$i]}[$j];				 
				 }
			}
		}		
		# make bookkeeping table for color bracketings		
		# this array stores which colors have open brackets
		my @brackettable;
		for (my $i = 0; $i <= $#arrayofSi; $i++) {
			$brackettable[$i] = 0;
		}
		my $brackettot = 0;  # stores the total of number brackets open
		my $crossnumsum = 0;

		# dynamic programming step which walks left to right through the 
		# integers $c + 0,...,(n-1)  % $n
		for (my $i = 0; $i < $n; $i++) {
			# update crossnum total
			$crossnumsum += $brackettot - $brackettable[$toSi[$i]];		

			# update bracket table to add this color bracket start
			if ( $m[$toSi[$i]] == $i ) {
				$brackettable[$toSi[$i]] = 1;
				$brackettot++;
			}
			# update bracket table to reflect this color bracket ends
			# thus if $i is a member of a singleton Si this reverse the previous update
			if ( $M[$toSi[$i]] == $i ) {
				$brackettable[$toSi[$i]] = 0;
				$brackettot--;
			}
		}
		if ( ($crossnumsum < $CNmin) || ($CNmin < 0) ) {
			$CNmin = $crossnumsum;
		}
	}
	return $CNmin;
}



#########################################################
# fast_cross_numberGeneral(ref to array of refs to arrays, int n, string computationtype)
# fast_cross_numberGeneral(ref to array of refs to arrays, int n, string computationtype,int $infmultiplicity,int $zeroindex,int $zeromultiplicity)
#
# Faster Crossing Number calculation using 
# dynamic programming tricks
#
# but for the special computation types:
#
# computationtype = "Infinity", "ZeroInfinity"
#
# infmultiplicity, zeromultiplicity:  the corresponding multiplicities of the special conditions
#
# Note: (1) for the Infinity calculation all we do is start the crossing number calculation at the 0
# 		and do NOT cycle around the circle computing the rest
#		(2) for the ZeroInfinity one, we do the crossing number calculation at both the start 
#			and at the index of the Zero condition only
#		
#  INPUT: Arrays S1,...,Sm of distinct integers from 0 to (n-1)
#  OUTPUT: An integer which is 0 <==> S1,...,Sm are noncrossing
#
# @a1 = (0,2,5);
# @a2 = (1,6,7);
# @a3 = (4,3,8);
# @b = (\@a1,\@a2,\@a3);
# $n = 9;
# print "The regular Crossing number is: ".fast_cross_number(\@b,$n)."\n";
# print "The Infinity Crossing number is: ".fast_cross_numberGeneral(\@b,$n,"Infinity",0)."\n";
#
#
# Should print 8 and then 10
#
# @a0 = (1);
# @a1 = (2,0,3);
# @a2 = (4,5);
# @a3 = (7,6);
# @b = (\@a0,\@a1,\@a2,\@a3);
# $n = 8;
#
# print "The Infinity/Special Crossing number is: ".fast_cross_numberGeneral(\@b,$n,"ZeroInfinity",2,3)."\n";
# should print 3
#
# @a0 = (0);
# @a1 = (2,1,3);
# @a2 = (4,5);
# @a3 = (7,6);
# @b = (\@a0,\@a1,\@a2,\@a3);
# $n = 8;
#
# print "The Infinity/Special Crossing number is: ".fast_cross_numberGeneral(\@b,$n,"ZeroInfinity",2,3)."\n";
# should print 0
#

sub fast_cross_numberGeneral {
	my ($arrayref,$n,$comptype,$infmultiplicity,$zeroindex,$zeroconditionplace,$zeromultiplicity);
	my @arrayofSi;
	if ( $#_ == 2 ) {  # if in "Infinity" (computation type 2)
		($arrayref,$n,$comptype) = @_;
		@arrayofSi = @{$arrayref};
	}
	if ( $#_ == 5 ) {  # if in "ZeroInfinity" (computation type 3)
		($arrayref,$n,$comptype,$infmultiplicity,$zeroindex,$zeromultiplicity) = @_;
		# need to adjust the input arrays to add the infinity and zero conditions
		my @infarr;
		# add oo-condition
		for ( my $i = 0; $i < $infmultiplicity; $i++ ) {
			push(@infarr,$i);
		}
		my @temparrayofSi = @{$arrayref};
		
		# create zero condition
		# note: where the 0-condition goes is stored in $zeroindex-1
		$zeroconditionplace = @{$temparrayofSi[$zeroindex-1]}[0];
#		print "zerocondplace = $zeroconditionplace\n";
		my @zeroarr;
		for ( my $i = 0; $i < $zeromultiplicity; $i++ ) {
			push(@zeroarr,$i+$infmultiplicity+$zeroconditionplace);
		}
		# adjust other conditions
		for ( my $i = 0; $i <= $#temparrayofSi; $i++) {
			if ( $i != ($zeroindex-1) ) {
#				print "$i in here:  @{$temparrayofSi[$i]}\n";
				for (my $j = 0; $j <= $#{$temparrayofSi[$i]}; $j++) {
					 if ( @{$temparrayofSi[$i]}[$j] < $zeroconditionplace ) {
					 	@{$temparrayofSi[$i]}[$j] += $infmultiplicity;
#					 	print "@{$temparrayofSi[$i]}[$j], ";
					 } else {
				 	if ( @{$temparrayofSi[$i]}[$j] > $zeroconditionplace ) {
				 		@{$temparrayofSi[$i]}[$j] += $zeromultiplicity+$infmultiplicity-1;
				 	}}
				}
#				print "\n";
			}
		}
		push(@arrayofSi,\@infarr);
		push(@arrayofSi,\@zeroarr);		
		for ( my $i = 0; $i <= $#temparrayofSi; $i++) {
			if ( $i != ($zeroindex-1) ) {
				push(@arrayofSi,\@{$temparrayofSi[$i]});
			}
		}

#########################
# for debugging purposes to see what is going on here
#		for ( my $i = 0; $i <= $#arrayofSi; $i++) {
#			for (my $j = 0; $j <= $#{$arrayofSi[$i]}; $j++) {
#				 	print "@{$arrayofSi[$i]}[$j],";
#			}
#			print "\n";
#		}
		$n += $zeromultiplicity + $infmultiplicity-1;
#		print "$n (@infarr) (@zeroarr)\n";
#		exit;
	}
	my $CNmin = -1;
	if ( $comptype eq "Infinity" ) {
		my $c = 0;
		# first make lookup table for which Si are the integers 0..(n-1)
		my @toSi;
		for ( my $i = 0; $i <= $#arrayofSi; $i++) {
			for (my $j = 0; $j <= $#{$arrayofSi[$i]}; $j++) {
				 $toSi[@{$arrayofSi[$i]}[$j]] = $i;
			}
		}
		# compute the maxs and mins - Note: this can be made a bit faster
		my @m; my @M;
		for ( my $i = 0; $i <= $#arrayofSi; $i++) {
			$m[$i] = $n; $M[$i] = 0;
			for (my $j = 0; $j <= $#{$arrayofSi[$i]}; $j++) {
				 if ( @{$arrayofSi[$i]}[$j] < $m[$i] ) {
					$m[$i] = @{$arrayofSi[$i]}[$j];				 				 
				 }
				 if ( @{$arrayofSi[$i]}[$j] > $M[$i] ) {
					$M[$i] = @{$arrayofSi[$i]}[$j];				 
				 }
			}
		}
		# make bookkeeping table for color bracketings		
		# this array stores which colors have open brackets
		my @brackettable;
		for (my $i = 0; $i <= $#arrayofSi; $i++) {
			$brackettable[$i] = 0;
		}
		my $brackettot = 0;  # stores the total of number brackets open
		my $crossnumsum = 0;

		# dynamic programming step which walks left to right through the 
		# integers $c + 0,...,(n-1)  % $n
		for (my $i = 0; $i < $n; $i++) {
			# update crossnum total
			$crossnumsum += $brackettot - $brackettable[$toSi[$i]];		

			# update bracket table to add this color bracket start
			if ( $m[$toSi[$i]] == $i ) {
				$brackettable[$toSi[$i]] = 1;
				$brackettot++;
			}
			# update bracket table to reflect this color bracket ends
			# thus if $i is a member of a singleton Si this reverse the previous update
			if ( $M[$toSi[$i]] == $i ) {
				$brackettable[$toSi[$i]] = 0;
				$brackettot--;
			}
		}
		if ( ($crossnumsum < $CNmin) || ($CNmin < 0) ) {
			$CNmin = $crossnumsum;
		}	
		return $CNmin;
	}
	
	if ( $comptype eq "ZeroInfinity" ) {

	my @tempc = (0,$zeroconditionplace+$infmultiplicity);
	for (my $c = 0; $c <= $#tempc; $c++) {
		# count at beginning and at special condition
		for ( my $i = 0; $i <= $#arrayofSi; $i++) {
			for (my $j = 0; $j <= $#{$arrayofSi[$i]}; $j++) {
				 @{$arrayofSi[$i]}[$j] = (@{$arrayofSi[$i]}[$j] + $tempc[$c]) % $n;
			}
		}
		# first make lookup table for which Si are the integers 0..(n-1)
		my @toSi;
		for ( my $i = 0; $i <= $#arrayofSi; $i++) {
			for (my $j = 0; $j <= $#{$arrayofSi[$i]}; $j++) {
				 $toSi[@{$arrayofSi[$i]}[$j]] = $i;
			}
		}
		# compute the maxs and mins - Note: this can be made a bit faster
		my @m; my @M;
		for ( my $i = 0; $i <= $#arrayofSi; $i++) {
			$m[$i] = $n; $M[$i] = 0;
			for (my $j = 0; $j <= $#{$arrayofSi[$i]}; $j++) {
				 if ( @{$arrayofSi[$i]}[$j] < $m[$i] ) {
					$m[$i] = @{$arrayofSi[$i]}[$j];				 				 
				 }
				 if ( @{$arrayofSi[$i]}[$j] > $M[$i] ) {
					$M[$i] = @{$arrayofSi[$i]}[$j];				 
				 }
			}
		}		
		# make bookkeeping table for color bracketings		
		# this array stores which colors have open brackets
		my @brackettable;
		for (my $i = 0; $i <= $#arrayofSi; $i++) {
			$brackettable[$i] = 0;
		}
		my $brackettot = 0;  # stores the total of number brackets open
		my $crossnumsum = 0;

		# dynamic programming step which walks left to right through the 
		# integers $c + 0,...,(n-1)  % $n
		for (my $i = 0; $i < $n; $i++) {
			# update crossnum total
			$crossnumsum += $brackettot - $brackettable[$toSi[$i]];		

			# update bracket table to add this color bracket start
			if ( $m[$toSi[$i]] == $i ) {
				$brackettable[$toSi[$i]] = 1;
				$brackettot++;
			}
			# update bracket table to reflect this color bracket ends
			# thus if $i is a member of a singleton Si this reverse the previous update
			if ( $M[$toSi[$i]] == $i ) {
				$brackettable[$toSi[$i]] = 0;
				$brackettot--;
			}
		}
		if ( ($crossnumsum < $CNmin) || ($CNmin < 0) ) {
			$CNmin = $crossnumsum;
		}
	}
	return $CNmin;

	}
}	


############################################################
# print_multidim_hashtable(hashtable)
#
# Simply prints out a hash table with two keys
#
sub print_multidim_hashtable {
    my(%hash) = @_;
	foreach my $j (keys %hash) {
		foreach my $k (keys %{$hash{$j}}) {
		    print "$j $k - $hash{$j}{$k}\n";
		}
	}
}



############################################################
# (hashtable) merge_two_solutions_table(ref to hashtable1, ref to hashtable2 )
#
# takes two references to hashtables which store solutions tables
# and merges the information on them, returning 
# an updated solutions table
# 
#  $solutionstable{r}{c} = the number of instances with real solutions r
#					   and necklace number c
#
#
sub merge_two_solutions_table {
    my($hashref1,$hashref2) = @_;
	my %hash1 = %{$hashref1};
	my %hash2 = %{$hashref2};
	my %mergedhash;
	
	foreach my $j (keys %hash1) {
		foreach my $k (keys %{$hash1{$j}}) {
		    if ( $hash2{$j}{$k} ) {
		    	$mergedhash{$j}{$k} = $hash1{$j}{$k} + $hash2{$j}{$k};
		    } else {
		    	$mergedhash{$j}{$k} = $hash1{$j}{$k};    	
		    }
		}
	}
	foreach my $j (keys %hash2) {
		foreach my $k (keys %{$hash2{$j}}) {
		    if ( !$hash1{$j}{$k} ) {
		    	$mergedhash{$j}{$k} = $hash2{$j}{$k};    	
		    }
		}
	}
	return %mergedhash;
}




############################################################
# (string) solutions_table_to_string(ref to multidim hash)
#
# reads a hashtable 
#
#  $solutiontable{r}{c} = the number of instances i with real solutions r
#						  and necklace number c
#
# and converts it to a string which is a list of triples r,c,i:
# e.g.    2,0,5  2,1,7  0,2,1 ...
#
sub solutions_table_to_string {
    my($hashref) = @_;
    my %hash = %{$hashref};
    my $string = "";
	foreach my $j (keys %hash) {
		foreach my $k (keys %{$hash{$j}}) {
		    $string .= "  $j,$k,$hash{$j}{$k}";
		}
	}
	return $string;
}





############################################################
# (hashtable) load_dbase_solutions_table(string)
#
# reads a string containing a list of triples of integers
#				num real solns, necklace number, total count
# e.g.  2,0,5  2,1,7  0,2,1 ...
#
# returns a hashtable solutiontable that is a hashtable
# with two keys and one value:
# 
#  $solutiontable{r}{c} = the number of instances with real solutions r
#						  and necklace number c
#
#
sub load_dbase_solutions_table {
    my($solutionstring) = @_;
    my %solutiontable;
	while ($solutionstring =~ m/([-0-9]+),([-0-9]+),([-0-9]+)/g) {
			$solutiontable{$1}{$2} = $3;
	}
	return %solutiontable;
}


############################################################
# count_instances_in_necklacetable(reference to hashtable)
#
# Given necklacetable as reference to hashtable
#   a,b,c : means a=#real solutions, b=necklace#, c=total count
# Return total of c's
#
sub count_instances_in_necklacetable {
    my($hashref) = @_;
    my %hash = %{$hashref};
    my $total = 0;
	foreach my $j (keys %hash) {
		foreach my $k (keys %{$hash{$j}}) {
		    $total += $hash{$j}{$k};
		}
	}
	return $total;
}


##############################################################################################
#
# (scalar, array reference) = get_partition( enumerative problem)
#
#  determines the total number of points needed for this enumerative problem
#   (the scalar) and the underlying partition for the points (the referenced array)
#
sub get_partition {
    my ($ep) = @_;
    my @num_points_list = &n_points_list($ep);
    my @partition = (); 
    my $sum = 0;
        for ( my $i = 0; $i <= $#num_points_list; $i++ ) {
            $sum = $sum + $num_points_list[$i];
	    push(@partition, $num_points_list[$i]);
        }
    return ($sum,\@partition);
}
###############################################################################################
#
# (array) = n_points_list( enumerative problem )
#
#    This returns a list whose i-th entry is the number of points 
# needed by the i-th condition in the enumerative problem.
#
#$enumproblem = "[1,3,5,2,4,6],[1,2,4,3,5,6]";
#print "enumerative problem = $enumproblem\n";
#my $format = "points needed = " . ("%2d " x @num_points_list) . "\n";
#printf $format, @num_points_list;
#
sub n_points_list {
    my $ep = $_[0];
    my @num_list=();
# parse enumerative problem for its  permutations
    while ($ep =~ m/\[([^\]]*)\]/g) {
        my @perm;
        my $a = $1;
        while ($a =~ m/([0-9]+)/g) {
            push(@perm,$1);
        }
    push(@num_list,&points_needed(@perm));
    }
    return @num_list;
}
#############################################################
#############################################################
#
# (scalar) = points_needed( permutation )
#
#   This computes the number of points needed to generate a secant flag for 
# the given Schubert condition, which is passed to the subroutine as the 
# argument.   This works for any permutation (not just Grassmannian)
#
#@perm = (1,5,8,4,6,3,2,7);
#@perm = (1,3,5,2,4,6);
#@perm = (1,2,4,3,5,6,7,8);
#printf "Number of points needed = %d\n",  points_needed(@perm);
#

sub points_needed {
    my @perm = @_;
    my $number_of_points = 0;
    for (my $des=0; $des < $#perm; $des++) {
#   find the descents of the permutation
        if ($perm[$des] > $perm[$des+1]) {
#   @tmp is the Schubert condition in the Grassmannian projection    
            my @tmp = sort(@perm[0..$des]);
            my $j = 0;
#   Finds the first essential condition
            while (( $j == $tmp[$j]-1 ) && ( $j < $des ) ) {
                $j++;
            }
#    Sees if this requires more points
            if (  ( $j <= $des ) && ($number_of_points < $#perm+2-$tmp[$j] ) ) {
                $number_of_points = $#perm+2-$tmp[$j];
            }
        }
    }
    return $number_of_points;
}


# find_packet_random_seed
# Find the random seed for a packet
# Input:
#   initialrandseed - random seed for the Request
#   packetnumber - which packet of the Request
# Output:
#   integer, random seed for that packetnumber
sub find_packet_random_seed {
    my ($initialrandseed, $packetnumber) = @_;
    my $packetseed;
    
    frsc_srand($initialrandseed); # random seed deterministically
    while ($packetnumber-- > 0) {
        $packetseed = int(frsc_rand(100000000));
    }
    
    return $packetseed;
}

# generate_random_seed
# Generate a new random seed (for a Request that doesn't have one).
# Input: None.
# Output: A more or less random integer.
sub generate_random_seed {
    return int (time ^ $$ ^ unpack "%L*", 'ps axww | gzip');
}


# shift_permutation_down
# shift permutations down by 1, e.g., 1,3,2,4 --> 0,2,1,3
# Input: a comma-separated list of numbers
# Output: comma-separated list of numbers obtained by subtracting one from each number
sub shift_permutation_down {
  my ($oldperm) = @_;
  return join(',', map {--$_} split(/,/,$oldperm) );
}


# shift_permutation_up
# shift permutations up by 1, e.g., 0,2,1,3 --> 1,3,2,4
# Input: a comma-separated list of numbers
# Output: comma-separated list of numbers obtained by adding one to each number
sub shift_permutation_up {
  my ($oldperm) = @_;
  return join(',', map {++$_} split(/,/,$oldperm) );
}
  
# permutation_statistics
# Computes the length and descent set of a permutation, passed as a string
# Input: comma-seperated list of numbers as a string '1,3,2,5,4'
# Output: ($length, \@descents) a scalar and an array reference
sub permutation_statistics {
 my ($permstring) = @_;
 my @perm;
 while ($permstring =~ m/([(0-9)+])/g){
   push (@perm,$1);
 }
 my $length=0;
 my @descents;
   for (my $i=0; $i<$#perm; $i++){
   if ($perm[$i]>$perm[$i+1]) { push(@descents,$i+1) }
     for (my $j=$i+1; $j<=$#perm; $j++){
        if ($perm[$i]>$perm[$j]) { $length++}
    }
 }
 return ($length,\@descents);
}

# cycle_permutation
# forms a permutation ($a, $a+1, ..., $n, 0, ..., $a-1)
# Output $cycleperm
#  Frank Sottile April 2010
sub cycle_permutation {
 my ($a,$n) = @_;
 my @perm;
 for ( my $i = 0; $i <= $n; $i++ ) { 
   if ( $i <= $n-$a ) {push(@perm, $i+$a);}
    else {push(@perm, $i+$a-$n-1);}
 }
 return \@perm;
}

#cycle_shift_permutation
# 
#  This convert a necklace (as generated by the maple input code, which corresponds to 
# the canonical order in which to list Schubert conditions) into a necklace that 
# corresponds to the order where that list is shifted cyclically so that the longest
# permutation comes first, and is thereby evaluated at infinity to give smaller local 
# local coordinates.  
#
#   Here is *a* description
#
#  The necklaces come as necklaces corresponding to the canonical (human-readible) list of the Schubert conditions.
#   Since we cycle the necklaces for computationtype 4, we'll need to conjugate the necklaces.  Here is the 
#   algorithm  For  X X X X Y2 Y Y with $longest = 4
# 1) Given a necklace (1,2,3,6,4,5,7), first convert it into a perl permutation, (0,1,2,5,3,4,6)
# 2) cycle by position of longest element to get (3,4,6,0,1,2,5)
# 3) cycle by first value (0,1,3,4,5,6,2)
# 4) return the perl pointer 
#
# Frank Sottile April 19 2010.
sub cycle_shift_permutation {
  my ($longest,$permctr) = @_;
  my @perm = @{$permctr};
  my $cpctr = &cycle_permutation($longest,$#perm);
  my @cycleperm = @{$cpctr};
  for (my $i=0; $i<=$#perm; $i++) {
    $perm[$i]=$perm[$i]-1;
  }
  my @newperm=@perm;
  for (my $i=0; $i<=$#perm; $i++) {
    $newperm[$i]=$perm[$cycleperm[$i]];
  }
  my @outperm=();
  for (my $i=0;  $i<=$#newperm; $i++) {
    if ($newperm[$i]>=$newperm[0]) 
      {push(@outperm,$newperm[$i]-$newperm[0]);}
      else
      {push(@outperm,$newperm[$i]-$newperm[0]+$#newperm+1);}
    }
  return  \@outperm;
}

# necklace_pointer 
#
#   This takes a pair of array references to (@necklace, @partition) where @necklace is a 
# necklace and @partition is the list of points needed for the Schubert conditions (that 
# are permuted by necklace).  It returns a pointer to permute the points so that if the Schubert
# conditions are evaluated in the order they come in in the file, then this will be a 
# collection of disjoint secant flags ordered acording to the given necklace.  In doing so,
# it applies a random permutation to each block of points.
#
# @necklace = (0,1,3,2);
# @partition= (2,3,4,1);
# $ptr = necklace_pointer(\@necklace,\@partition);
# print "@{$ptr} \n";
#
##############################################################
sub necklace_pointer {
  my ($necklace_ptr,$partition_ptr) =  @_;

  my @necklace = @{$necklace_ptr};
  my @partition = @{$partition_ptr};

  my @skips=();
  for ( my $i=0; $i<=$#necklace; $i++ ) {
    my $skip=0;
    for ( my $j=0; $j<=$#necklace; $j++ ) {
      if ( $necklace[$j] < $necklace[$i] )  {
        $skip = $skip + $partition[$j];
      }
    }
    push(@skips,$skip);
  }

  my @ptr=();
  for ( my $i=0; $i<=$#necklace; $i++ ){
    my $randperm = &randPermutation($partition[$i]);
    for ( my $j=0; $j<$partition[$i]; $j++ ){
      push(@ptr, @{$randperm}[$j]+$skips[$i]);
#      push(@ptr, $j+$skips[$i]);
    } 
  }

  return  \@ptr;
}

return 1;
__END__


