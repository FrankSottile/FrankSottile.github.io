# Sequel Pro dump
# Version 2210
# http://code.google.com/p/sequel-pro
#
# Host: dbu.math.tamu.edu (MySQL 5.0.67)
# Database: secantDevelopment
# Generation Time: 2010-05-12 13:16:20 -0500
# ************************************************************

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table ComputationLengthType
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ComputationLengthType`;

CREATE TABLE `ComputationLengthType` (
  `id` int(11) NOT NULL auto_increment,
  `computation_length` tinytext,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

LOCK TABLES `ComputationLengthType` WRITE;
/*!40000 ALTER TABLE `ComputationLengthType` DISABLE KEYS */;
INSERT INTO `ComputationLengthType` (`id`,`computation_length`)
VALUES
	(1,'Less than two hours'),
	(2,'two to four hours'),
	(3,'four to eight hours'),
	(4,'eight to sixteen hours'),
	(5,'over sixteen hours');

/*!40000 ALTER TABLE `ComputationLengthType` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table ComputationType
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ComputationType`;

CREATE TABLE `ComputationType` (
  `id` int(11) NOT NULL auto_increment,
  `description` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

LOCK TABLES `ComputationType` WRITE;
/*!40000 ALTER TABLE `ComputationType` DISABLE KEYS */;
INSERT INTO `ComputationType` (`id`,`description`)
VALUES
	(1,'Grassmannian, all secant flags, and Markov steps'),
	(2,'Grassmannian, osculating flag at infinity, and Markov steps'),
	(3,'Grassmannian, osculating flags at zero and infinity, and Markov steps'),
	(4,'Partial flags, all osculating flags with one at infinity, fine necklaces'),
	(5,'Partial flags,  all secant flags, and fine necklaces'),
	(6,'Partial flags, one osculating flag at infinity, the rest secant flags, and fine necklaces'),
	(7,'Partial flags, all osculating flags, and coarse necklaces '),
	(8,'Partial flags, all secant flags, and coarse necklaces'),
	(9,'Partial flags, one osculating flag at infinity, the rest secant flags, and coarse necklaces');

/*!40000 ALTER TABLE `ComputationType` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Computer
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Computer`;

CREATE TABLE `Computer` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(64) default NULL,
  `numcpus` int(11) default '1',
  `clockspeed` int(11) default NULL,
  `time_mhzseconds` bigint(40) default '0',
  `ostype_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

LOCK TABLES `Computer` WRITE;
/*!40000 ALTER TABLE `Computer` DISABLE KEYS */;
INSERT INTO `Computer` (`id`,`name`,`numcpus`,`clockspeed`,`time_mhzseconds`,`ostype_id`)
VALUES
	(1,'miln303',4,2830,0,1);

/*!40000 ALTER TABLE `Computer` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table FlagVariety
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FlagVariety`;

CREATE TABLE `FlagVariety` (
  `id` int(11) NOT NULL auto_increment,
  `flagvariety` tinytext,
  `dimension` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table Necklaces
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Necklaces`;

CREATE TABLE `Necklaces` (
  `id` int(11) NOT NULL auto_increment,
  `necklaces` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table OSType
# ------------------------------------------------------------

DROP TABLE IF EXISTS `OSType`;

CREATE TABLE `OSType` (
  `id` int(11) NOT NULL auto_increment,
  `description` varchar(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

LOCK TABLES `OSType` WRITE;
/*!40000 ALTER TABLE `OSType` DISABLE KEYS */;
INSERT INTO `OSType` (`id`,`description`)
VALUES
	(1,'linux'),
	(2,'darwin');

/*!40000 ALTER TABLE `OSType` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Requests
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Requests`;

CREATE TABLE `Requests` (
  `id` int(11) NOT NULL auto_increment,
  `totalnumpackets` int(11) default '0',
  `packetnumber` int(11) default '0',
  `schubertproblem_id` int(11) default NULL,
  `computationtype_id` tinyint(4) default NULL,
  `computationlength_id` tinyint(4) default '0',
  `algebraprogram` char(8) default 'Singular',
  `necklace_id` int(11) default NULL,
  `number_necklaces` int(11) default NULL,
  `priority` tinyint(4) default '0',
  `initialrandseed` bigint(20) default '0',
  `packetsize` int(11) default NULL,
  `numcomputationsperfile` int(11) default NULL,
  `mhzsecondsperinstance` double default '100',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table Results
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Results`;

CREATE TABLE `Results` (
  `id` int(11) NOT NULL auto_increment,
  `request_id` int(11) default NULL,
  `numinstances` int(11) default '0',
  `lastcomputeddate` text,
  `necklacetable` text,
  `schubertproblem_id` int(11) default NULL,
  `time_mhzseconds` bigint(40) default '0',
  `packetssubmitted` int(11) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table RunningInstance
# ------------------------------------------------------------

DROP TABLE IF EXISTS `RunningInstance`;

CREATE TABLE `RunningInstance` (
  `id` int(11) NOT NULL auto_increment,
  `request_id` int(11) default NULL,
  `startdate` int(11) default NULL,
  `computer_id` int(11) default NULL,
  `packetnumber` int(11) default NULL,
  `expected_time_to_finish` int(11) default NULL,
  `startdate_human` text,
  `expected_finish_human` text,
  `priority` tinyint(4) default NULL,
  `computationlength_id` tinyint(4) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table SchubertProblems
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SchubertProblems`;

CREATE TABLE `SchubertProblems` (
  `id` int(11) NOT NULL auto_increment,
  `problemname` varchar(40) default NULL,
  `schubertconditions` text,
  `numsolutions` int(11) default NULL,
  `flagvariety_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;






/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
