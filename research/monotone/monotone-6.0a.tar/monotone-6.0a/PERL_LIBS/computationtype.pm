use 5.008006;
use strict;
use warnings;

#  Computation types
#  Completed:    4, 5
#  Working on:   6
#  To do 7, 8, 9

################################
# write_algebra_file
#
# note: we permute conditions (within blocks) and secantcy points within conditions
#          This is a little delicate, as the way it was done before is no longer adequate.
#
sub write_algebra_file {
  my ($options, $prob, $files, $masterpoints) = @_;
  my (@enumproblemarr) = permutationlist_to_arrayNoBrackets($prob->{'schubertconditions'});  # arrray of conditions
  my @cycleperm;               # a permutation that cycles the enumerative problem so the first longest condition is initial
  my @permutedenumproblemarr;  # this stores the permuted Schubert conditions; some computation types require the 
                               #   Schubert conditions to be permuted from how they stored in the database.
  my $longest=0;               # position of the longest permutation in the list of Schubert conditions
                               #   Valid only for computation types 4, 6, and 7, 9 where one condition is evaluated
                               #   at infinity.
  
  if ( $prob->{'computationtypeid'} == 4 or  $prob->{'computationtypeid'} == 6 ) {
  #
  #  For Computationtype 4 and 6 (both fine necklace computation types), 
  #  we find the first longest element, and then cycle the Schubert conditions so that this one is initial.
  #   
    my $longest_length = 0;
    for ( my $i = 0; $i <= $#enumproblemarr; $i++ ) { 
      my ($length,$descentref) =  permutation_statistics($enumproblemarr[$i]);
      if ( $length > $longest_length ) {
        $longest_length = $length;
        $longest = $i;
      }
    }
    my $cpctr = &cycle_permutation($longest,$#enumproblemarr);
    my @cycleperm = @{$cpctr};
    for ( my $i = 0; $i <= $#enumproblemarr; $i++ ) { 
      $permutedenumproblemarr[$i] = $enumproblemarr[$cycleperm[$i]];
    }
  }

 #
 # For computationtype 5 just pass the enumerative problem as is.
 #
  if ( $prob->{'computationtypeid'} == 5 ) {
     @permutedenumproblemarr = @enumproblemarr;
  }

#  print "Schubert conditions = @permutedenumproblemarr \n";

  ###################################################
  # Make a SINGULAR/Macaulay file that will compute $numcomputationsperfile instances of 
  # the problem.  Each computation in the file does $number_necklaces instances of the problem
  ###################################################
  # creates new singular/macaulay file with problem initializations

  if( $prob->{'algebraprogram'} eq 'singular' ) {
    open( SINGULARFILE , ">" , $files->{'singularinput'} ) or return 0;
    write_singular_file_header(\*SINGULARFILE,$prob,@permutedenumproblemarr) or return 0;
  } elsif ( $prob->{'algebraprogram'} eq 'macaulay' ) {
    open( MACAULAYFILE , ">" , $files->{'macaulayinput'} ) or return 0;
    write_macaulay_file_header(\*MACAULAYFILE,$prob,@permutedenumproblemarr) or return 0;
  } else {
    return -1;
  }

  #################################################################### 
  # Iterate through $number_necklaces instances of the 
  # problem by changing the points chosen.
  #
  # this is accomplished by choosing a random subset of points from
  # a master (ordered) list @master_points
  #
  # first choose the correct number of random points from master list for this problem
  #
  my @numberlist;           # Legacy code keeping trach of which necklace was used
                            #  Could have also used reduction modulo number of necklaces.
  my ($numpointsneeded, $multarray_r);
  my $newconditions = "";
  
  # For Computation type 4, the initial condition is evaluated at infinity, so the number of
  #    points needed is one less than the number of Schubert conditions
  #
  if ( $prob->{'computationtypeid'} == 4 ) {
     $numpointsneeded = $#permutedenumproblemarr;
  }
  # For Computation type 5, all conditions are evaluated as secant flags, so we need to 
  # actually compute the number of points needed.
  #
  if ( $prob->{'computationtypeid'} == 5 ) {
    # gets number of points needed given these Schubert conditions
    for (my $j = 0; $j <= $#permutedenumproblemarr; $j++ ) {
      $newconditions = $newconditions."[".$permutedenumproblemarr[$j]."]";
    }
    ($numpointsneeded, $multarray_r) = get_partition($newconditions);
   $prob->{'multiplicity_array'}=$multarray_r;
  }

  # For Computation type 6, all conditions but the first are evaluated as secant flags, 
  # so we need to actually compute the number of points needed.
  #
  if ( $prob->{'computationtypeid'} == 6 ) {
    # gets number of points needed given these Schubert conditions, skipping condition[0]
    for (my $j = 1; $j <= $#permutedenumproblemarr; $j++ ) {
      $newconditions = $newconditions."[".$permutedenumproblemarr[$j]."]";
    }
#    print "New conditions = $newconditions \n";
    ($numpointsneeded, $multarray_r) = get_partition($newconditions);
   $prob->{'multiplicity_array'}=$multarray_r;
#    print "number of points needed = $numpointsneeded,  multiplicity array = @{$multarray_r} \n";
  }

  ######################################################################################
  #
  #  This loops over the different selections of points (number of computations per file), each of 
  #    which is applied to all necklaces.
  #
  for( my $computation_counter = 1; $computation_counter <= $prob->{'numcomputationsperfile'}; ++$computation_counter ) {
    # Grab a random subset of (number of points needed) points from our master set
    my @randpoints = @{randSubset($masterpoints,$numpointsneeded)};

    ###########################################################################################################
    #
    # This code block writes the body of the algebra file for computation type 4.
    #  In the future, we could make this a procedure. 
    #
    ###########################################################################################################
    if ( $prob->{'computationtypeid'} == 4 ) {
      my @necklaces =  necklaces_to_arrays($prob->{'necklaces'});

      for ( my $i = 0; $i <=  $#necklaces; $i++ ) {  
        push(@numberlist,$i);
    
        #  Apply the cycle permutation to the set of points.
        my $necklace = &cycle_shift_permutation($longest,$necklaces[$i]);
        #
        #  Truncate first element (0) of necklace and flatten to a permutation of 0..(m-1)
        #
        my @oldperm=@{$necklace};
        my @newperm=();
        for (my $j=1; $j<=$#oldperm; $j++) {
	  push (@newperm, $oldperm[$j]-1);
        }
        $necklace=\@newperm;

        # place the rest of the algebra code into the file
        if( $prob->{'algebraprogram'} eq 'singular' ) {
          write_singular_file_loop(\*SINGULARFILE,\@randpoints,$necklace,$files->{'singularoutput'},$prob,$computation_counter) or return 0;
        } elsif ( $prob->{'algebraprogram'} eq 'macaulay' ) {
          write_macaulay_file_loop(\*MACAULAYFILE,\@randpoints,$necklace,$files->{'macaulayoutput'},$prob,$computation_counter) or return 0;
        } else {
          return -1;
        }

      }
    }  ## This ends the code block for computationtype 4

    ###########################################################################################################
    #
    # This code block writes the body of the algebra file for computation type 5.
    #  In the future, we could make this a procedure. 
    #
    ############################################################################################################
    if ( $prob->{'computationtypeid'} == 5 ) {
     my @necklaces =  necklaces_to_arrays($prob->{'necklaces'});
     for ( my $i = 0; $i <= $#necklaces; $i++ ) {
       push(@numberlist,$i);
       my $permutation = &necklace_pointer($necklaces[$i],$prob->{'multiplicity_array'});
       if( $prob->{'algebraprogram'} eq 'singular' ) {
         write_singular_file_loop(\*SINGULARFILE,\@randpoints,$permutation,$files->{'singularoutput'},$prob,$computation_counter) or return 0;
        } elsif ( $prob->{'algebraprogram'} eq 'macaulay' ) {
          write_macaulay_file_loop(\*MACAULAYFILE,\@randpoints,$permutation,$files->{'macaulayoutput'},$prob,$computation_counter) or return 0;
        } else {
          return -1;
        }
     }
   }  ## This ends the code block for computationtype 5

    ###########################################################################################################
    #
    # This code block writes the body of the algebra file for computation type 6.
    #  In the future, we could make this a procedure. 
    #
    ############################################################################################################
    if ( $prob->{'computationtypeid'} == 6 ) {
     my @necklaces =  necklaces_to_arrays($prob->{'necklaces'});
     for ( my $i = 0; $i <= $#necklaces; $i++ ) {
      push(@numberlist,$i);
#
#  Here is where we'll need to figure things out for computationlength 6.
#   $permutation takes care of pointing the points to the order in which they belong
#  We'll need to cycle the necklaces around for this and flatten.
#
      #  Apply the cycle permutation to the set of points.
      my $necklace = &cycle_shift_permutation($longest,$necklaces[$i]);
      #
      #  Truncate first element (0) of necklace and flatten to a permutation of 0..(m-1)
      #
      my @oldperm=@{$necklace};
      my @newperm=();
      for (my $j=1; $j<=$#oldperm; $j++) {
        push (@newperm, $oldperm[$j]-1);
      }
      $necklace=\@newperm;
      my $permutation = &necklace_pointer($necklace,$prob->{'multiplicity_array'});
#      print "Necklace = @{$necklace}, necklace_pointer = @{$permutation}\n";
      if( $prob->{'algebraprogram'} eq 'singular' ) {
         write_singular_file_loop(\*SINGULARFILE,\@randpoints,$permutation,$files->{'singularoutput'},$prob,$computation_counter) or return 0;
        } elsif ( $prob->{'algebraprogram'} eq 'macaulay' ) {
          write_macaulay_file_loop(\*MACAULAYFILE,\@randpoints,$permutation,$files->{'macaulayoutput'},$prob,$computation_counter) or return 0;
        } else {
          return -1;
      }
     }
   }  ## This ends the code block for computationtype 6

  } ### this ends the numcomputationsperfile loop
    
  # close up algebra file  
  if( $prob->{'algebraprogram'} eq 'singular' ) {
    write_singular_file_tail(\*SINGULARFILE) or return 0;
    close(SINGULARFILE) or return 0;
  } elsif ( $prob->{'algebraprogram'} eq 'macaulay' ) {
    write_macaulay_file_tail(\*MACAULAYFILE,$files->{'macaulayoutput'}) or return 0;
    close(MACAULAYFILE) or return 0;
  } else {
    return -1;
  }

  return (@numberlist);
}

###################################### SINGULAR ######################################
###################################### SINGULAR ######################################
###################################### SINGULAR ######################################

###############################
#  write_singular_file_header
#
sub write_singular_file_header {
  my ($singularfile,$prob,@permutedenumproblemarr) = @_;
    # write header of SINGULAR computation file
    print $singularfile "// Problem name: ". $prob->{'problemname'} ."\n" or return 0;
    print $singularfile "// Flag variety: Fl(". $prob->{'flagvariety'} .";". $prob->{'dimension'} .")\n" or return 0;
    print $singularfile "LIB \"SINGULAR_LIBS/schubert.lib\";\n" or return 0;
    print $singularfile "intvec a = ". $prob->{'flagvariety'} .";\n" or return 0; 
    print $singularfile "int n = ". $prob->{'dimension'} .";\n" or return 0; 
    my $count = 1;  
    my $conditionstring = "";

    # parse enumerative problem
    my $minus1;
    for ( my $i = 0; $i <= $#permutedenumproblemarr; $i++ ) {
      print $singularfile "intvec w$count = $permutedenumproblemarr[$i];\n" or return 0;
      $minus1 = $count-1;  $count++;
      if ( $minus1 > 0 ) { $conditionstring .= "w$minus1, "; }
    }
    $minus1 = $count - 1;
    $conditionstring .= "w$minus1";
    print $singularfile "list conditions = $conditionstring;\n" or return 0; 
    print $singularfile "int degEP = $prob->{'numsolutions'};\n" or return 0;

  # For computation type 4 the flag of the initial condition is osculating at infinity
  if ( $prob->{'computationtypeid'} == 4 or $prob->{'computationtypeid'} == 6) {
       print $singularfile "def R = flagRing(a,n,w1);\n" or return 0;
  }
  # For computation type 5 all conditions are secant
  if ( $prob->{'computationtypeid'} == 5) { 
       print $singularfile "def R = flagRing(a,n);\n" or return 0;  
  }
  #########################################################################################
  print $singularfile "setring R;\n" or return 0;
  print $singularfile "ideal I;\n" or return 0;
  print $singularfile "poly e,f;\n" or return 0;
  print $singularfile "list points;  int i;\n" or return 0;
  return 1;
}

sub write_singular_file_loop {
  my ($singularfile,$randpointsptr,$permutationptr,$singularoutput,$prob,$iterationnumber) = @_;
  my @randpoints = @{$randpointsptr};
  my @permutation = @{$permutationptr};  # This is the permutation of the necklace
  
  # create the list of points for the singular file     
  my $pointstring = "points = ";
  for (my $k = 0; $k < $#randpoints; $k++) {
    $pointstring .= $randpoints[$permutation[$k]].",";
  }
  $pointstring .= "$randpoints[$permutation[$#randpoints]];\n";

  print $singularfile $pointstring or return 0;

  # now we must place the rest of the SINGULAR code into the file Singular computes:
  # For the monotone conjecture (computationtype 4) 
  if ( $prob->{'computationtypeid'} == 4 ) {
      print $singularfile "I = std(osculatingIdeal(points,conditions,a,n));\n" or return 0;
  }
  # For the monotone secant (computationtype 5) 
  if ( $prob->{'computationtypeid'} == 5 ) {
      print $singularfile "I = std(secantIdeal(points,conditions,a,n));\n" or return 0;
  }
  # For the monotone secant conjecture with one flag at infinity (computationtype 6)
  if ( $prob->{'computationtypeid'} == 6 ) {
      print $singularfile " I = std(secantIdeal(points,conditions,a,n,1));\n" or return 0;
  }

  print $singularfile " e = 0; \n f=1; \n i=1;\n" or return 0;
  print $singularfile " while ( (deg(e)<>degEP or f<>1) and i<=nvars(R))  {\n" or return 0;
  print $singularfile "    e = univarpol(I,i); \n" or return 0;
  print $singularfile "    f = gcd(e,diff(e, var(i)));  i++; } \n" or return 0;
  # if it finds an eliminant, write it:
  print $singularfile " if (i<=nvars(R))    {   \n" or return 0;
  print $singularfile "    write(\":a $singularoutput\", e);\n" or return 0;
  # if not,  the Singular procedure wiggle will perturb the points 

  #   If this still fails, record a failure:
  print $singularfile " }  else   {  \n" or return 0;
################################    Wiggling  ##################################
  print $singularfile " points=wiggle(points);\n" or return 0;
  # For the monotone conjecture (computationtype 4) 
  if ( $prob->{'computationtypeid'} == 4 ) {
      print $singularfile " I = std(osculatingIdeal(points,conditions,a,n));\n" or return 0;
  }
  # For Vanilla computation type
  if ( $prob->{'computationtypeid'} == 5) {
      print $singularfile " I = std(secantIdeal(points,conditions,a,n));\n" or return 0;
  }
  # For the monotone secant conjecture with one flag at infinity (computationtype 6)
  if ( $prob->{'computationtypeid'} == 6 ) {
      print $singularfile " I = std(secantIdeal(points,conditions,a,n,1));\n" or return 0;
  }
  print $singularfile " e = 0; \n f=1; \n i=1;\n" or return 0;
  print $singularfile " while ( (deg(e)<>degEP or f<>1) and i<=nvars(R))  {\n" or return 0;
  print $singularfile "    e = univarpol(I,i); \n" or return 0;
  print $singularfile "    f = gcd(e,diff(e, var(i)));  i++; } \n" or return 0;
  # if it finds an eliminant, write it:
  print $singularfile " if (i<=nvars(R))    {   \n" or return 0;
  print $singularfile "    write(\":a $singularoutput\", e);\n" or return 0;
  # if not,  we record a failure
  print $singularfile " }  else   {  \n" or return 0;
  ################################  End  Wiggling  ##################################

  my $failurestring = failure_to_line($prob,$randpointsptr,$permutationptr);
  $failurestring .= "!!iterationnumber~~$iterationnumber";
   print $singularfile "    write(\":a $singularoutput\", \"$failurestring\"); } \n" or return 0;

  ################################    Wiggling  ##################################
  print $singularfile "     } \n" or return 0;
  ################################  End  Wiggling  ##################################

####### If you want to test the failure recording mechanism:
### replace the last 7 lines of the above function with these:
#
#    #print $singularfile " if (i<=nvars(R))    {   \n";
#    #print $singularfile "    write(\":a $singularoutput\", e);\n";
#    #if not, record a failure:
#    #print $singularfile " }  else   {  \n";
#    my $failurestring = failure_to_line($prob,$randpointsptr,$permutationptr);
#    $failurestring .= "!!iterationnumber~~$iterationnumber";
#    print $singularfile "    write(\":a $singularoutput\", \"$failurestring\"); \n";
#
### (note that four are commented and two are not,
### and the last line has a brace } removed near the end of the line---this is on purpose!)
  return 1;
}

sub write_singular_file_tail {
  my $singularfile = $_[0];
  print $singularfile "quit;\n" or return 0;
  return 1;
}


###################################### MACAULAY ######################################
###################################### MACAULAY ######################################
###################################### MACAULAY ######################################


sub write_macaulay_file_header {
  my ($macaulayfile,$prob,@permutedenumproblemarr) = @_;
  # write header of Macaulay 2 computation file
  print $macaulayfile "-- Problem name: ". $prob->{'problemname'} ."\n" or return 0;
  print $macaulayfile "-- Flag variety: Fl(". $prob->{'flagvariety'} .";". $prob->{'dimension'} .")\n" or return 0;
  print $macaulayfile "load \"MACAULAY_LIBS/schubert.libm2\";\n" or return 0;
  print $macaulayfile "a = {$prob->{'flagvariety'}};\n" or return 0; 
  print $macaulayfile "n = $prob->{'dimension'};\n" or return 0; 
  
  my $shiftedperm;
  my $conditionstring = "{";
  # parse enumerative problem
  for ( my $i = 0; $i <= $#permutedenumproblemarr; $i++ ) {
    # shift permutations down by 1 !!! e.g singular's 1,3,2 --> macaulay's 0,2,1
    $shiftedperm = shift_permutation_down($permutedenumproblemarr[$i]);
    print $macaulayfile "w_$i = {$shiftedperm};\n" or return 0;
    $conditionstring .= "w_$i";
    if ( $i < $#permutedenumproblemarr ) { $conditionstring .= ", " ; }
  }
  $conditionstring .= "}";
  print $macaulayfile "conditions = $conditionstring;\n" or return 0; 
  print $macaulayfile "degEP = $prob->{'numsolutions'};\n" or return 0;

  # For computation type 4 the flag of the initial condition is osculating at infinity
  if ( $prob->{'computationtypeid'} == 4 or $prob->{'computationtypeid'} == 6) {
    print $macaulayfile "R = flagRing(a,n,PermutationList=>{w_0});\n" or return 0;
  }
  # For computation type 5 all conditions are secant
  if ( $prob->{'computationtypeid'} == 5) {
    print $macaulayfile "R = flagRing(a,n);\n" or return 0;
  }
  print $macaulayfile "use R;\n" or return 0;
  return 1;
}

sub write_macaulay_file_loop {
  my ($macaulayfile,$randpointsptr,$permutationptr,$macaulayoutput,$prob,$iterationnumber) = @_;
  my @randpoints = @{$randpointsptr};
  my @permutation = @{$permutationptr};

  # create the list of points for the Macaulay2 file     
  my $pointstring = "";
  for (my $k = 0; $k < $#randpoints; $k++) {
    $pointstring .= $randpoints[$permutation[$k]].",";
  }
  $pointstring .= "$randpoints[$permutation[$#randpoints]]";

#  print  "points = {$pointstring}\n"; 

  print $macaulayfile "points = {$pointstring};\n" or return 0;

  # now we must place the rest of the MACAULAY code into the file Macaulay computes:
  # For the monotone conjecture (computationtype 4) 
  if ( $prob->{'computationtypeid'} == 4) {
    print $macaulayfile " I = osculatingIdeal(points,conditions,a,n);\n" or return 0;
  }
  #  For the monotone secant (computationtype 5) 
  if ( $prob->{'computationtypeid'} == 5 ) {
      print $macaulayfile " I = secantIdeal(points,conditions,a,n);\n" or return 0;
  }
  # For the monotone secant conjecture with one flag at infinity (computationtype 6)
  if ( $prob->{'computationtypeid'} == 6 ) {
      print $macaulayfile " I = secantIdeal(points,conditions,a,n,ComputationTypeIndex=>{0});\n" or return 0;
  }

  print $macaulayfile " e = 0_R; \n f=1; \n i=0;\n" or return 0;
  print $macaulayfile " while ( (first degree(e) != degEP or f != 1) and i<#flatten entries vars R)  do (\n" or return 0;
  print $macaulayfile "    e = univarpol(I,i); \n" or return 0;
  print $macaulayfile "    f = gcd(e,diff(R_i, e));  i=i+1; ); \n" or return 0;
  # if it finds an eliminant, write it:
  print $macaulayfile " if (i<#flatten entries vars R)  then (   \n" or return 0;
  print $macaulayfile "    \"$macaulayoutput\" << toString e << endl;\n" or return 0;
  # if not,  Frank will write a Singular procedure for perturbing the points 
  # If this still fails, record a failure:
  print $macaulayfile " )  else   (  \n" or return 0;
  ################################    Wiggling  ##################################
  print $macaulayfile " points=wiggle(points);\n" or return 0;
  # For Vanilla computation type
  # For the monotone conjecture (computationtype 4) 
  if ( $prob->{'computationtypeid'} == 4) {
    print $macaulayfile " I = osculatingIdeal(points,conditions,a,n);\n" or return 0;
  }
  #  For the monotone secant (computationtype 5) 
  if ( $prob->{'computationtypeid'} == 5 ) {
      print $macaulayfile " I = secantIdeal(points,conditions,a,n);\n" or return 0;
  }
  #  For the monotone secant (computationtype 6) 
  if ( $prob->{'computationtypeid'} == 6 ) {
      print $macaulayfile " I = secantIdeal(points,conditions,a,n,ComputationTypeIndex=>{0});\n" or return 0;
  }

  print $macaulayfile " e = 0_R; \n f=1; \n i=0;\n" or return 0;
  print $macaulayfile " while ( (first degree(e) != degEP or f != 1) and i<#flatten entries vars R)  do (\n" or return 0;
  print $macaulayfile "    e = univarpol(I,i); \n" or return 0;
  print $macaulayfile "    f = gcd(e,diff(R_i, e));  i=i+1; ); \n" or return 0;
  # if it finds an eliminant, write it:
  print $macaulayfile " if (i<#flatten entries vars R)  then (   \n" or return 0;
  print $macaulayfile "    \"$macaulayoutput\" << toString e << endl;\n" or return 0;
  # if not,  we record a failure
  print $macaulayfile " )  else   (  \n" or return 0;

  ################################  End  Wiggling  ##################################
  my $failurestring = failure_to_line($prob,$randpointsptr,$permutationptr);
  $failurestring .= "!!iterationnumber~~$iterationnumber";
  print $macaulayfile "    \"$macaulayoutput\" << \"$failurestring\" << endl; );\n" or return 0;
  ################################    Wiggling  ##################################
  print $macaulayfile "     ); \n" or return 0;
  ################################  End  Wiggling  ##################################
  return 1;
}



sub write_macaulay_file_tail {
  my ($macaulayfile,$macaulayoutput) = @_;
  print $macaulayfile "\"$macaulayoutput\" << close;\n" or return 0;
  print $macaulayfile "quit;\n" or return 0;
  return 1;
}




1;
