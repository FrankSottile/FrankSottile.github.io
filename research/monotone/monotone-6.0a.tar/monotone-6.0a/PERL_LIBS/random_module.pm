use 5.008006;
use strict;
use warnings;

#############################################################
#
# Random functions
#

# Documentation: http://search.cpan.org/~fangly/Math-Random-MT-Perl-1.06/lib/Math/Random/MT/Perl.pm
# 

use PERL_LIBS::MathRandomMTPerl;
sub frsc_srand {
  &Math::Random::MT::Perl::srand($_[0]);
}
sub frsc_rand {
  return &Math::Random::MT::Perl::rand($_[0]);
}

############################################################

sub frsc_random_string {
  my $length_of_randomstring=shift;  # length random string to generate
  my @chars=('a'..'z','A'..'Z','0'..'9','_');
  my $random_string;
  foreach (1..$length_of_randomstring) {
    # rand @chars generates a random number between 0 and scalar @chars
    $random_string.=$chars[frsc_rand($#chars+1)];
  }
  return $random_string;
}

##############################################################
# (ref to array) randSubset(array ref p, int n)
#
# Returns a random subset of size n of array p
# that respects its original order
#
# The point of using hash tables in this code is to
# make the complexity small in n and not to depend
# on the size of p
#
# @list = (1..50000);
# @subset = @{randSubset(\@list,10)};
# print @subset, "\n";
#
# @list = ("a","b","c","d");
# @subset = @{randSubset(\@list,2)};
# print @subset, "\n";
#
#
sub randSubset {
  my ($arrayref,$n)=@_;
  my @array = @{$arrayref};
  my %randindexhash;
  my $numindexelements = 0;
  # we will store those indices chosen from 0...(n-1) in a hash
  # table.  numindexelements keeps track of the hash's size
  while ($numindexelements < $n) {
    my $randint = int frsc_rand($#array+1);
    if ( !$randindexhash{$randint} ) {  # index not taken yet
      $randindexhash{$randint} = 1;
      $numindexelements++;
    }
  }
  my @allindices = keys(%randindexhash);
  @allindices = sort { $a <=> $b } @allindices;
  my @randomsubset;
  for (my $i = 0; $i <= $#allindices; $i++) {
    $randomsubset[$i] = $array[$allindices[$i]];
  }
  return \@randomsubset;
}

##############################################################
# (ref to array) randPermutation(int n)
#
# Returns a random permutation of size n with integers from 0...(n-1)
#
# my $randperm = randPermutation(10);
# print "@{$randperm} \n";
#
sub randPermutation {
  my ($n)=@_;
  my @array;
    
  for ( my $i = 0; $i < $n; $i++ ) {
    $array[$i] = 0;
  }
  my @permarr;
  my $numchosen = 0;
  # we will store those indices chosen from 0...(n-1) in a hash
  # table.  numindexelements keeps track of the hash's size
  while ($numchosen < $n) {
    my $randint = int frsc_rand($n); 
    if ( !$array[$randint] ) {  # int not taken yet
      $array[$randint] = 1;
      $numchosen++;
      push(@permarr,$randint);
    }
  }
  return \@permarr;
}

##############################################################
# (ref to array) permute_subarray( array ref, start index, end index)
#
# Returns a random permutation of the elements of the subarray from
# startindex to endindex
#
# @arr = (2,3,11,4,1,20,35);
# $arr = permute_subarray(\@arr,3,5);
# print "@arr \n";
#
sub permute_subarray {
  my ($arrref,$start,$end)=@_;
  my @permarr = @{randPermutation($end-$start+1)};
  my @arr = @{$arrref};
  my @copyarr = @arr;
  for ( my $i = 0; $i < $end-$start+1; $i++ ) {
    $arr[$i+$start] = $copyarr[$permarr[$i]+$start];
  }
  return \@arr;
}


############################################################
# array next_markov(array reference, int N)
#
# takes an array ref and permutes two of the entries at random
#
# N is the number of times to act by a random transposition
#
# e.g.  (2, 3, 1, 5) -->  (3, 2, 1, 5) 
#
sub next_markov {
  my ($arrayref,$N) = @_;
  my @array = @{$arrayref};
  # iterate acting by random transposition N times
  for (my $i = 0; $i < $N; $i++) {
    my $firstint = int frsc_rand($#array+1);
    my $secondint = int frsc_rand($#array+1);
    # search for distinct pair
    while ( $secondint == $firstint ) {  
      $secondint = int frsc_rand($#array+1);
    }
    # now swap
    my $temp = $array[$firstint];
    $array[$firstint] = $array[$secondint];
    $array[$secondint] = $temp;
  }
  return \@array;
}


1;
__END__
