This should be run at home, on Hopf, and all in SINGULAR


#!/usr/bin/perl -w
################################################################################
#
#  This is for testing the loading
#
################################################################################
# Perl code to load problems into the data base for the monotone conjecture project.  
#   It puts in a Schubert problem, and initializes a request for its computation.
#
# Created by Christopher Hillar
#  Modified by Frank Sottile and Zach Teitler
# 
#   Usage: perl loadproblems.pl -l Problems.file
#
#  Problems.file is a text file which has a |-delimited list of data
#     describing a Schubert problem to run.  
# 
#  ---->> Will need variable for 
#         * block or fine necklaces
#         * computation type
#
#  # sols|name|Flag var.| enum perms | necklaces |
#
#       2|Y^3Z^2|2,3,4|1,3,2,4;1,3,2,4;1,3,2,4;1,2,4,3;1,2,4,3|1,2,3,4,5;1,2,4,3,5|
#
# For the conventions on how the conditions and necklaces are listed, see the documentation 
#   in the makeProblems directoy.
#
#   Computation type and algebraprogram  are set in this file
#
################################################################################

use PERL_LIBS::monotone;
#
my $computationtype = 4;
#
#  Computation type is set here
# type   Description
#  1    Straightforward secant conjecture on Grassmannian
#  2    Like #1, but with one osculating flag (at infinity)
#  3    Like #1, but with two osculating flags (at zero and at infinity)
#  4   +Pure monotone conjecture:  Osculating flags and necklaces, with one flag at infinity   fine necklaces
#  5   -Full monotone secant conjecture:  Disjoint secant flags and necklaces   fine necklaces
#  6   *Like #5, but with one osculating flag (at infinity)      fine necklaces
#  7   *Pure monotone conjecture:  Osculating flags and necklaces, with one flag at infinity  Block necklaces
#  8   *Full monotone secant conjecture:  Disjoint secant flags and necklaces  Block necklaces
#  9   *Like #8, but with one osculating flag (at infinity)        Block necklaces
#
#  + := being implemented
#  - := not fully implemented
#  * := not currently implemented
#
##############################################################
# Default variable declarations
#
my $numiterations 	= 1;   # default NUMBER of PACKET COMPUTATIONS
$FLUSH_WORKING  	= 0;   # leave 'working' flags alone in Problem tables

# database defaults:
$dbhr = {
#
# Local DB:                         
#    'database' => 'monotoneTesting', 
#    'db_server' => '127.0.0.1',   # Mac
#    'db_server' => '192.168.1.104',   # R2D2
#    'db_user_name' => 'secant',       #
#    'db_password' => 'Sec48MatH', 
#    'db_port' => '3306',

# Math department:
    'database' => 'secantDevelopment',     
   'db_server' => 'dbu.math.tamu.edu',
   'db_user_name' => 'secant',
   'db_password' => 'Sec48MatH',
  'db_port' => '3306',

};

#
#   This tells the code which algebra programs to test
#
$ALGEBRA_PROGRAM      = 'both';
#$ALGEBRA_PROGRAM      = 'singular';
#$ALGEBRA_PROGRAM      = 'macaulay';

$SINGULAR_path        = 'Singular'; 
$MACAULAY2_path        = 'M2'; 
$MAPLE_path 	      = 'maple';
$PROBLEM_FILE_NAME    = 'testing';
$KEEPTEMPFILES	      = 0;
##############################################################

############################################################
# Command line parameters
#
# -dd   -->   Do not Delete temporary files (for debugging, etc.)
#
# -l	  -->	pick filename to load problems from
#
#   Retrieval of command line parameters
#
my $parameters = "";
foreach my $argnum (0 .. $#ARGV) {
  $parameters .= $ARGV[$argnum];
}
if ( $parameters =~ m/-dd/ ) {
  $KEEPTEMPFILES = 1;
}
if ( $parameters =~ m/-l([a-zA-Z1-9.\/_]*)/ ) {
  $PROBLEM_FILE_NAME = $1;
}
#############################################################

$dbhr->{'datasource'} = "DBI:mysql:"
                   ."database=$dbhr->{'database'};"
                   ."hostname=$dbhr->{'db_server'};"
                   ."port=$dbhr->{'db_port'}";

# load this computer's information
my ($compid,$cpufreq,$host,$num_running_instances) = frsc_checkin( $dbhr );

if( $FLUSH_WORKING == 1 ) {
    frsc_flushdatabase( $dbhr );
}

########################################################################			
# Get the list of points (as rational numbers with , delimeters) 
# These are expected to be sorted in numeric order.
#######################################################################
@master_points=@{get_points( )};

my $logfile = $PROBLEM_FILE_NAME . ".log.load";
my $oldlog = $logfile."old";
if (-e $logfile) { 
  use File::Copy;
  move($logfile, $logfile.".old");
  print "moved old log file ! \n";
}
open LOGFILE, ">$logfile" or die "ERROR: could not open file $logfile - $!\n";

my $todaysdatetime = localtime(time);
printf(LOGFILE "Problems loaded from file  %s  into  %s  database by computer %s on %s \n", 
          $PROBLEM_FILE_NAME, $dbhr->{'database'}, $host,  $todaysdatetime);

one_iteration($dbhr,$compid,\@master_points,$host);

close(LOGFILE);

################################################################
# MAIN PROCEDURE
#
################################################################
# int one_iteration()
#
# This is the main heart of the code.  It opens the file containing problems to be 
# loaded into the database and computes each one, a few times (at least 5), in both Singular and 
# Macaulay 2, captures the timing, and then determines the packet size information and the algebra program.
#
sub one_iteration {
  my ($dbhr,$compid,$masterpoints,$host) = @_;
    
  use Benchmark;		

  # read input file
  open(PROBLEMS, $PROBLEM_FILE_NAME);
  my $line = "";
  my @problemarr;
  $problemcount = 0;
  # main loop to test timing and load each problem into dbase
  while (<PROBLEMS>){         # load file into $line	

    #  Avoid trying to compute empty lines
    if (length($_)>10) {
    $problemcount++;
    $line = $_;
    # parse input specifications
    #
    #  # sols|name|Flag var.| enum perms | necklaces |
    #
    #       2|Y^3Z^2|2,3,4|1,3,2,4;1,3,2,4;1,3,2,4;1,2,4,3;1,2,4,3|1,2,3,4,5;1,2,4,3,5|
    $line =~ m/([0-9]+)\|([A-Z^0-9,]+)\|([0-9,]+)\|([0-9,;]+)\|([0-9,;]+)\|/g;  
    #
    $numsolutions = $1;				
    $problemname = $2;
    $flagvariety = $3;
    $allperms = $4;
    $necklaces_raw = $5;

    my @flag;
    while ($flagvariety =~ m/([0-9]+)/g ) {	# pick out flag variety and dimension
      push(@flag,$1);
    }		

    $flagvariety = "$flag[0]";
    for ( my $i = 1; $i < $#flag; $i++ ) {
      $flagvariety = $flagvariety.", $flag[$i]";
    }
    $dimension = $flag[$#flag];

    # get list of Schubert conditions
    $schubertconditions = "";
    while ( $allperms =~ m/([0-9,]+)/g ) {
      $schubertconditions .= "[$1]";
    }

    # get list of necklaces
    $necklaces = "";
    $number_necklaces = 0;
    while ( $necklaces_raw =~ m/([0-9,]+)/g ) {
      $necklaces .= "[$1]";
      $number_necklaces++;
    }

    # check if this flag variety exists in the dbase
    my $datasource = "DBI:mysql:"
         ."database=$dbhr->{'database'};"
         ."hostname=$dbhr->{'db_server'};"
         ."port=$dbhr->{'db_port'}";
    my $dbh = DBI->connect($datasource,
           $dbhr->{'db_user_name'},
           $dbhr->{'db_password'},
                  {RaiseError => 1, AutoCommit => 0});
    my $sth = $dbh->prepare("SELECT id FROM FlagVariety WHERE (dimension='$dimension' AND
                               flagvariety='$flagvariety');");
    $sth->execute();

    # if the flag variety is in there
    if ( ($flagid) = $sth->fetchrow_array() ) {
      } else {		# need to add flag variety to dbase
      my $sth2 = $dbh->prepare(qq{INSERT INTO FlagVariety (flagvariety,dimension) values 
                                    ('$flagvariety','$dimension');});	
      $sth2->execute();
      $flagid = $dbh->{'mysql_insertid'};		
    }
    # now insert Schubert problem into database		
    $sth = $dbh->prepare("SELECT id FROM SchubertProblems WHERE (flagvariety_id='$flagid'
 			AND numsolutions='$numsolutions'
 			AND schubertconditions='$schubertconditions');");
    $sth->execute();
    my $schubertproblemid;
    
    # if the Schubert problem is in there 
    if ( ($schubertproblemid) = $sth->fetchrow_array() ) {
      } else {		# need to add Schubert problem to database
      my $sth2 = $dbh->prepare(qq{INSERT INTO SchubertProblems 
             (problemname, schubertconditions, numsolutions, flagvariety_id )
            values
             ('$problemname', '$schubertconditions', '$numsolutions', '$flagid');});
      $sth2->execute();
      $schubertproblemid = $dbh->{'mysql_insertid'};					
    }

    # now insert Necklaces into database		
    $sth = $dbh->prepare("SELECT id FROM Necklaces WHERE (necklaces='$necklaces');");
    $sth->execute();
    my $necklaceid;
    
    # if the Necklace is in there 
    if ( ($necklace_id) = $sth->fetchrow_array() ) {
      } else {		# need to add necklace to database
      my $sth2 = $dbh->prepare(qq{INSERT INTO Necklaces
             (necklaces)
            values
             ('$necklaces');});
      $sth2->execute();
      $necklace_id = $dbh->{'mysql_insertid'};					
    }

    $sth->finish();
    $dbh->commit();
    $dbh->disconnect();

    ##########################################################################################
    # We now run the problem to get the timing information, once for Singular and once for 
    # Macaulay2.    This is used to determine the optimal algebra program, as well as 
    # packet size AND number of computations per file according to the rule:
    # n packets * numcompperfile * number_necklaces ~ 2 hours of processing time
    # (This is then rounded to a nice even number)		

    printf( LOGFILE "\nStatistics for loading the Schubert problem %s=%d with computation type %d:\n",
                    $problemname,$numsolutions,$computationtype);

    #
    #  We compute small problems many time to reduce Singular/Macaulay2/Sage/Maple loading issues
    #
    my $prob = {
        'packetnumber'   => 1,
        'priority'       => 0,
        'request_id'     => $problemname,          
        'computationtypeid' => $computationtype,
        'necklace_id'      => $necklace_id,
        'number_necklaces' => $number_necklaces, 
        'schubertproblem_id' => $schubertproblemid,
        'problemname'    => $problemname,
        'schubertconditions'   => $schubertconditions,
        'numsolutions'   => $numsolutions,
        'flagvariety'    => $flagvariety,
        'dimension'      => $dimension,
#        'necklace_type'     => $necklace_type, 
        'necklaces'         => $necklaces, 
    };

    # First find computation time in Singular
    $Stime = 0.;
    $Scomputationsperfile = 1;
    if ( $ALGEBRA_PROGRAM ne 'macaulay' ) {
#      $numcomputationsperfile = 1;
      while ( $Stime < 10){ 

        $prob->{'numcomputationsperfile'} = $Scomputationsperfile;
        $prob->{'subpacket'} = $Scomputationsperfile;
        my $files = set_up_filenames($prob);

        ###################################################
        # make SINGULAR file for the computation
        ###################################################
    
        # creates new singular file with problem initializations
        $t0 = new Benchmark;
        my $prob = {'algebraprogram' => "singular" };
        my (@crossnumbers) = write_algebra_file($options,$prob,$files,$masterpoints);

        # run Singular file 
        my $status = system("nice -n20 $SINGULAR_path -q < $files->{'singularinput'}");

        # creates new maple file with proper header
        write_maple_input_file($prob,$files);
 
        # now run maple file 
        $status = system("nice -n20 $MAPLE_path -q < $files->{'mapleinput'} > $files->{'results'}");

        # perl time benchmarking
        $t1 = new Benchmark;           
        $td = timediff($t1, $t0);
        my $timestr = timestr($td);
        $timestr =~ m/([.0-9]+) CPU/g;
        $Stime = $1; # in seconds (NOT scaled to cpu speed), whole loop 
        printf "Singular computation time = %-7.2f",$Stime;
        printf "  time per instance = %-7.3f",$Stime/$Scomputationsperfile;
        printf "  iterations = %-3d \n",$#crossnumbers+1;
        #######################################################
        #
        # Erase temporary files unless the -dd option is used
        #
        #######################################################
        if( !$KEEPTEMPFILES ) {
          frsc_remove_temp_files($files) ;
        }
    
        #  If the computation went too fast, adjust the number of computations 
        #  and run the computation again.  This is to get more accurate timing data
        #
        if ( $Stime < 10 ) {
           $Scomputationsperfile = int ($Scomputationsperfile * 25/$Stime);
        }
      }
    }

    # First find computation time in Macaulay
    $Mtime = 0.;
    $Mcomputationsperfile = 1;
    if ( $ALGEBRA_PROGRAM ne 'singular' ) {
#      $numcomputationsperfile = 1;
      while ( $Mtime < 10){ 

        $prob->{'numcomputationsperfile'} = $Mcomputationsperfile;
        $prob->{'subpacket'} = $Mcomputationsperfile;
        my $files = set_up_filenames($prob);

        ###################################################
        # make SINGULAR file for the computation
        ###################################################
    
        # creates new singular file with problem initializations
        $t0 = new Benchmark;
        my $prob = {'algebraprogram' => "macaulay" };
        my (@crossnumbers) = write_algebra_file($options,$prob,$files,$masterpoints);

        # run Macaulay 2 file 
        my $status = system("nice -n20 $MACAULAY2_path --script $files->{'macaulayinput'}");

        # creates new maple file with proper header
        write_maple_input_file($prob,$files);
 
        # now run maple file 
        $status = system("nice -n20 $MAPLE_path -q < $files->{'mapleinput'} > $files->{'results'}");

        # perl time benchmarking
        $t1 = new Benchmark;           
        $td = timediff($t1, $t0);
        my $timestr = timestr($td);
        $timestr =~ m/([.0-9]+) CPU/g;
        $Mtime = $1; # in seconds (NOT scaled to cpu speed), whole loop 
        printf "Macaulay computation time = %-7.2f",$Mtime;
        printf "  time per instance = %-7.3f",$Mtime/$Mcomputationsperfile;
        printf "  iterations = %-3d \n",$#crossnumbers+1;

        #######################################################
        #
        # Erase temporary files unless the -dd option is used
        #
        #######################################################
        if( !$KEEPTEMPFILES ) {
          frsc_remove_temp_files($files) ;
        }
    
        #  If the computation went too fast, adjust the number of computations 
        #  and run the computation again.  This is to get more accurate timing data
        #
        if ( $Mtime < 10 ) {
           $Mcomputationsperfile = int ($Mcomputationsperfile * 25/$Mtime);
        }
      }
    }

    #  Decide which algebra program to use
    $AlPr = $ALGEBRA_PROGRAM;

    if ( $ALGEBRA_PROGRAM eq 'both' ) { 
      if ( $Mtime/$Mcomputationsperfile < $Stime/$Scomputationsperfile ) {
        $AlPr = "macaulay";
      }
       if ( $Mtime/$Mcomputationsperfile >=  $Stime/$Scomputationsperfile ) {
        $AlPr = "singular";
      }
     }
    if ( $AlPr eq 'macaulay' ) { 
      $algebraprogram = "macaulay";
      $computationtime = $Mtime;
      $numcomputationsperfile = $Mcomputationsperfile;
    }
    if ( $AlPr eq 'singular' ) { 
      $algebraprogram = "singular";
      $computationtime = $Stime;
      $numcomputationsperfile = $Scomputationsperfile;
     }
    #   We now use this to determine how many runs through all necklaces 
    # can be computed in one hour, and then use that to determine packetsize,  
    # the number of computations per file, and the total number of packets
    #
    my $secondsperrun = $computationtime/$numcomputationsperfile;
    my $numberInTwoHours = 7200/$secondsperrun;

    printf(LOGFILE "    ---- In two hours, %s can compute %3.0f runs through all %d necklaces.\n",
              $algebraprogram,$numberInTwoHours,$number_necklaces);


#
#  For initial testing and all problems are set to be easy
#
#
       $packetsize = 5;
       $numcomputationsperfile = 10;
       $totalnumpackets = 5;
############################################################################

##################################################################################


    printf(LOGFILE "   The time for a single run through all necklaces was %6.4f CPU seconds.\n",
                  $secondsperrun);
    printf(LOGFILE "   This problem will have %d packets, each consisting of %d files containing %d computations,\n",
                  $totalnumpackets,$packetsize,$numcomputationsperfile);
    printf(LOGFILE "      and is scheduled to compute %d distinct Schubert problems in all.\n",
             $number_necklaces*$packetsize*$numcomputationsperfile*$totalnumpackets);
    printf(LOGFILE "   -Expected time per packet is %7.3f hours, and the request should consume %8.3f hours.\n",
             $packetsize*$numcomputationsperfile*$secondsperrun/3600,
             $packetsize*$numcomputationsperfile*$secondsperrun*$totalnumpackets/3600);

    my $cpufreq = figure_out_clockspeed($host);
    if ( $cpufreq == 0 ) {
       $cpufreq = 2600 ; # Speed of Frank's machine Hopf
    }
    # Scale timeperinstance to MHz-seconds
    my $mhzsecondsperinstance = $secondsperrun*$number_necklaces*$cpufreq;
    
    # update the Schubert problem 
    $dbh = DBI->connect($dbhr->{'datasource'},
                        $dbhr->{'db_user_name'},
                        $dbhr->{'db_password'},
                          {RaiseError => 1, AutoCommit => 0});         

#######################################################################

    $sth = $dbh->prepare(qq{SELECT id FROM Requests WHERE 
                 (schubertproblem_id='$schubertproblemid' AND 
                  necklace_id='$necklace_id' AND computationtype_id='$computationtype');});
    $sth->execute();
    my $requestid; 

    print "totalnumpackets ", $totalnumpackets, "\n";
    print "schubertproblem_id ", $schubertproblemid, "\n";
    print "computationtype_id ", $computationtype, "\n";
    print "computationlength_id ", $computationLength, "\n";
    print "algebraprogram ", $algebraprogram, "\n";
    print "necklace_id ", $necklace_id, "\n";
    print "number_necklaces ", $number_necklaces, "\n";
    print "priority ", 0, "\n";
    print "packetsize ", $packetsize, "\n";
    print "numcomputationsperfile ", $numcomputationsperfile, "\n";

    #
    #  This does not write over an old request !
    #
    if ( ($requestid) = $sth->fetchrow_array() ) {
      } else {		# need to add request to database
      $sth3 = $dbh->prepare(qq{INSERT INTO Requests 
           (totalnumpackets,schubertproblem_id,computationtype_id,computationlength_id,algebraprogram,
            necklace_id,number_necklaces,priority,packetsize,numcomputationsperfile,mhzsecondsperinstance) 
	 values 
          ('$totalnumpackets','$schubertproblemid','$computationtype','$computationLength','$algebraprogram','$necklace_id',
           '$number_necklaces','0','$packetsize','$numcomputationsperfile','$mhzsecondsperinstance');});	
      $sth3->execute();                                             
      $requestid = $dbh->{'mysql_insertid'};					
    }

    $sth->finish();
    $dbh->commit();
    $dbh->disconnect();
    print "request_id ", $requestid, "\n";

}
}
  close(PROBLEMS);
  return 1;
}
