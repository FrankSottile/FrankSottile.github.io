import java.util.*;
import java.lang.*;


class m2twovargen {

    public int r;
    public int s;
    public int n;
    public int count = 0;

    public static void main(String[] args) {
	m2twovargen wc = new m2twovargen();
	wc.r = Integer.valueOf( args[0] ).intValue();
	wc.s = Integer.valueOf( args[1] ).intValue();
	wc.n = Integer.valueOf( args[2] ).intValue();
	wc.produceM2code( wc.r, wc.s, wc.n );
    }

    public void produceM2code (int r, int s, int n) {
	int i, j, k;
	String firstLine = "R = QQ[", secondLine = "S = QQ[", 
	    thirdLine = "f = map(S,R,{";

	for ( j = 1; j <= n; j++ ) {
	    for ( k = 1; k <= n; k++ ) {
		if ( k != j ) {
		    if ( j == n && k == n-1) 
			firstLine = firstLine + 'p' + j + k + ']';
		    else firstLine = firstLine + 'p' + j + k + ',';

		}
	    }	    		
	    
	}
	System.out.println(firstLine);
    
	for ( i = 1; i <= n-1; i++ ) {   
	    secondLine = secondLine + 'x' + i + ',';
	}
	System.out.println(secondLine + 'x' + n+ ']');

	for ( j = 1; j <= n; j++ ) {
	    for ( k = 1; k <= n; k++ ) {
		if ( k != j ) {
		    if ( j == n && k == n-1) 
			thirdLine = thirdLine + 'x' + j + '^' + r + '*' +  'x' + k + '^' + s + "})";
		    else thirdLine = thirdLine + 'x' + j + '^' + r + '*' +  'x' + k + '^' + s + ',';
		}
	    }	    		
	    
	}

	System.out.println(thirdLine);
	System.out.println("P = kernel(f);");
	System.out.println("mingens(P)");

    }
}
