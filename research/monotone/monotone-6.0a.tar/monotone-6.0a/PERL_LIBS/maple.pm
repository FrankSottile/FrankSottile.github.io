use 5.008006;
use strict;
use warnings;

sub write_maple_input_file {
  my ($prob,$files) = @_;
  open(MAPLEFILE,">$files->{'mapleinput'}") or return 0;
  write_maple_input_file_header(*MAPLEFILE,$prob,$files) or return 0;
  write_algebra_results_to_maple(*MAPLEFILE,$files) or return 0;
  write_maple_input_file_tail(*MAPLEFILE) or return 0;
  close(MAPLEFILE) or return 0;
  return 1;
}
    
# write header of Maple computation file (prototype is nrr.maple)
sub write_maple_input_file_header {
  my ($maplefile,$prob,$files) = @_;
  print $maplefile "# Problem name: ". $prob->{'problemname'} ."\n" or return 0;
  print $maplefile "# Flag variety: Fl(". $prob->{'flagvariety'} .";". $prob->{'dimension'} .")\n" or return 0;
#  print $maplefile "file:=fopen(\"$files->{'results'}\",WRITE):\n" or return 0;
  return 1;
}

# get results from singular/macaulay computation and make maple file to compute num real roots
sub write_algebra_results_to_maple {
  my ($maplefile,$files) = @_;
  open(ALGOUTPUT,$files->{'algebraoutput'}) or return 0;
    
  while (<ALGOUTPUT>){   # parse each line
    my $line = $_;
    chomp($line);
    if ( line_is_failure($line) ) {  # Singular encountered a failure to find eliminant
      # just pass it through
      print $maplefile "fprintf(file,\"$line\\n\"):\n" or return 0;
    } else {
      print $maplefile "n := nops(realroot($line,1/1000)):\n" or return 0;
#      print $maplefile "fprintf(file,\"%d\\n\",n):\n" or return 0;
      print $maplefile "printf(\"%d\\n\",n):\n" or return 0;
    }
    # Reset maple, try to get rid of datalimit errors!
    print $maplefile "restart:\n" or return 0;
  }
  close(ALGOUTPUT) or return 0;
  return 1;
}

#  Mind-boggling to have a routine to do this trivia!
#
sub write_maple_input_file_tail {
#  my $maplefile = $_[0];
#  print $maplefile "fclose(file):\n" or return 0;
  return 1;
}


return 1;
__END__
