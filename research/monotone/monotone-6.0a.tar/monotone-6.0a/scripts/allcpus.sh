#!/bin/bash
# a non-interactive shell script to run secant.pl on all CPUs
# should work on linuxes, not on macs
# Usage: sh allcpus.sh 3 --- computationlength 3
# If no arguments, then DEFAULT COMPUTATIONLENGTH = 1 !!!
# See below for more detailed documentation.
# v1.0.3 - added lines to delete "Error, cannot raise..."
if [ $# -eq 0 ];
then
  computationlength=1
else
  computationlength=$1
fi

workingdir=/u/sura/secant/secantTesting/v107
tmpdir=/data/scratch/secant

# ^processor matches "processor" only at the beginning of the line
# this occurs once for each cpu
numcpus=`grep ^processor < /proc/cpuinfo | wc -l`
### Kludge to handle calclabs only running one CPU at a time:
### numcpus=1

verbosepercentage=1

# DOCUMENTATION
# 1. Creating directories: It creates temporary directories
# for working files and output files in the /data/scratch filesystem.

# 2. Starting one job per processor: It reads the number of cpus, above.
# (If you just want one job, uncomment the line numcpus=1.)
# Then it starts one copy of perl secant.pl, for each cpu counted by numcpus.
# stdout and stderr are redirected to $tmpdir/outs_raw.

# 3. Randomly verbose jobs: A certain percentage of jobs, selected
# randomly, are run in verbose mode, for spot checking.
# The percentage can be set by setting verbosepercentage above.
# It is allowed to set it to 0 or 100.
# http://tldp.org/LDP/abs/html/randomvar.html

# 4. "wait": it waits for all the jobs to complete.

# 5. It checks to see if any output was produced by any of the jobs.
# If any one of the jobs produced output (on stdout or on stderr),
# then we capture all the output from all the jobs.

# 6. If there is output to be captured, create a file in $tmpdir/outs_pretty,
# print some information (which qsub job number, the computer's hostname...)
# and then concatenate all the outputs (stdout and stderr)
# of all the jobs that ran on this computer.

# 7. Then, delete the "raw" output files in $tmpdir/outs_raw.
# (Either they were empty, or else they weren't empty and they've
# been captured into outs_pretty.)

# Note, if step #5 or #6 doesn't occur --- e.g., walltime limit is
# exceeded and those steps don't get run --- then the "raw" output
# files are still left behind. They might not say the computer's
# hostname but it's better than nothing.


# Just seed with PID of script, good enough!
RANDOM=$$

cd $workingdir

##### Make temporary directories #####

if [ ! -e frsc-tmp ] ; then
  ln -s $tmpdir frsc-tmp
fi
if [ ! -e frsc-tmp/outs_raw ] ; then
  mkdir frsc-tmp/outs_raw
fi
if [ ! -e frsc-tmp/outs_pretty ] ; then
  mkdir frsc-tmp/outs_pretty
fi
if [ ! -e frsc-tmp/$host ] ; then
  mkdir frsc-tmp/$host
fi


##### Start one secant.pl for each CPU #####

for i in $(seq 1 $numcpus);
do
  number=$[($RANDOM % 100)+1]
  if [ "$number" -le "$verbosepercentage" ];
  then
    perl secant.pl -n1 -cl $computationlength -V \
      1> frsc-tmp/outs_raw/$PBS_JOBID.$i.o \
      2> frsc-tmp/outs_raw/$PBS_JOBID.$i.e &
    sleep 1
  else
    perl secant.pl -n1 -cl $computationlength \
      1> frsc-tmp/outs_raw/$PBS_JOBID.$i.o \
      2> frsc-tmp/outs_raw/$PBS_JOBID.$i.e &
    sleep 1
  fi
done

##### wait for background jobs to complete #####
wait


##### Post-process output and error files #####

cd $workingdir/frsc-tmp/outs_raw

# Strip out the uninteresting errors:
# Error, cannot raise the datalimit above the hard limit
# Died at secant.pl line 86.
datalimiterror="Error, cannot raise the datalimit above the hard limit\n"
noflylisterror="Died at secant.pl line 86.\n"
for i in $(seq 1 $numcpus);
do
  perl -pi -e "s/$datalimiterror// ; s/$noflylisterror//" $PBS_JOBID.$i.o
  perl -pi -e "s/$datalimiterror// ; s/$noflylisterror//" $PBS_JOBID.$i.e
done


# Is there any output/error?
anyoutput=0
for i in $(seq 1 $numcpus);
do
  # -s: size of file is not zero
  if [[ -s $PBS_JOBID.$i.o || -s $PBS_JOBID.$i.e ]]; then
    anyoutput=1
  fi
done

# Change back to directory frsc-tmp
cd $workingdir/frsc-tmp

# If there is any output, merge all output + error files into single file
if [ $anyoutput -eq 1 ]; then
  outfile=outs_pretty/$PBS_JOBID.oe.txt
  separator="------------------------------"
  touch $outfile
  echo "PBS Job: $PBS_JOBID" >> $outfile
  echo "Host: $HOST" >> $outfile
  echo "Date: `date`" >> $outfile
  for i in $(seq 1 $numcpus);
  do
    echo $separator >> $outfile
    echo "Job $i stdout:" >> $outfile
    cat outs_raw/$PBS_JOBID.$i.o >> $outfile
    echo $separator >> $outfile
    echo "Job $i stderr:" >> $outfile
    cat outs_raw/$PBS_JOBID.$i.e >> $outfile
  done
fi


# Delete the separate files
for i in $(seq 1 $numcpus);
do
  rm outs_raw/$PBS_JOBID.$i.o
  rm outs_raw/$PBS_JOBID.$i.e
done


##### Exit #####

exit 0
