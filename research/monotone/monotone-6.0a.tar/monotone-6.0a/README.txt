
README
5/26/09
Zach Teitler


Steps to get secant.pl running:

1. Get a MySQL database server. This can be running on the same computer that will run secant.pl.

2. Create a database.

3. Load in one of the database files, e.g., loaded_problems.sql.
(For this, a program such as CocoaMySQL or Sequel Pro may be useful: <http://www.sequelpro.com/>.)


4. Edit my_config.txt to contain the right name of database server, database, password, etc.
Also take a look at "Options.txt" to see some of the other options.


5. Try checking in:

    perl checkin.pl

If this succeeds, then you can connect to the database server.



6. To make computations return results MUCH faster, edit SchubertProblems: make numcomputationsperfile
and packetsize smaller.

(It's not making the computations RUN faster, just return results in much smaller chunks.
So you will see the results much sooner. Useful for testing, or if you want to grab some Singular/Macaulay2
input files to see what the polynomial systems look like.)

You can control which problems it works on: Edit the database (e.g. using Sequel Pro) to make some
problems higher-priority. If you set priority < 0, they will not be worked on.



7. Try running some computations:

    perl secant.pl -V

(However this may take several hours if you skipped step 6.)



8. Set up web monitoring:
* copy contents of "PHP_files" into web server directory. E.g., ~/public_html/*, or (on Mac),
    /Library/WebServer/Documents/*
I made a directory for these files:
    /Library/WebServer/Documents/frsc/*
* Edit the phpconfig.data file
* Visit the pages at appropriate URL, e.g., http://localhost/frsc/monitor.php (served from your own machine)
  or http://www.math.tamu.edu/~secant/phpfiles/monitor.php (served from TAMU math dept web server).


