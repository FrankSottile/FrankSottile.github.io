use 5.008006;
use strict;
use warnings;

sub write_sarag_input_file {
  my ($prob,$files) = @_;
  open(SAGEFILE,">$files->{'sageinput'}") or return 0;
  write_sarag_input_file_header(*SAGEFILE,$prob) or return 0;
  write_singular_results_to_sarag(*SAGEFILE,$files) or return 0;
  write_sarag_input_file_tail(*SAGEFILE) or return 0;
  close(SAGEFILE) or return 0;
  return 1;
}

# write header of SARAG computation file (prototype is nrr.maple)
sub write_sarag_input_file_header {
  my ($sagefile,$prob) = @_;
  my @a = permutation_to_array($prob->{'flagvariety'});
  my $n = $prob->{'dimension'};
  my $d = $a[0]*($n-$a[0]);
  for (my $i=1; $i<=$#a; $i++) {
   $d = $d + ($a[$i] - $a[$i-1])*( $n - $a[$i] );
  }
  print $sagefile "# Problem name: ". $prob->{'problemname'} ."\n" or return 0;
  print $sagefile "# Flag variety: Fl(". $prob->{'flagvariety'} .";". $prob->{'dimension'} .")\n" or return 0;
  print $sagefile "maxima.load('sarag')\n" or return 0;
   # Singular uses x1...x$d. Macaulay uses x_0...x_($d-1),
   # ie, index shifted down by 1, and with underscores
   # Better yet: we just change them all to simply "x"
   print $sagefile "x=polygen(QQ)\n" or return 0;
 return 1;
}

# get results from singular computation and make maple file to compute num real roots
sub write_singular_results_to_sarag {
 my ($sagefile,$files) = @_;
  open(SINGOUTPUT,$files->{'singularoutput'}) or return 0;
  while (<SINGOUTPUT>){   # parse each line
    my $line = $_;
    chomp($line);
    if ( line_is_failure($line) ) {  # Singular encountered a failure to find eliminant
      # just pass it through
      print $sagefile "print(\"$line\")\n" or return 0;
    } else {
      # change x_number -> x
      # change xnumber  -> x
      $line =~ s/x[_]*\d/x/g;
      print $sagefile "e = $line\n" or return 0;
      print $sagefile "n = len(maxima.isolateRoots(e,x))\n" or return 0;
      print $sagefile "print(n)\n" or return 0;
    }
  }
  close(SINGOUTPUT) or return 0;
  return 1;
}

sub write_sarag_input_file_tail {
  my ($sagefile) = @_;
  print $sagefile "maxima.quit()\n" or return 0;
  print $sagefile "quit\n" or return 0;
  return 1;
}


return 1;
__END__
