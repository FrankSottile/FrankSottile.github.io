import java.util.*;
import java.lang.*;


class twovargenerator {

    public int r;
    public int s;
    public int n;
    public int count = 0;

    public static void main(String[] args) {
	twovargenerator wc = new twovargenerator();
	wc.r = Integer.valueOf( args[0] ).intValue();
	wc.s = Integer.valueOf( args[1] ).intValue();
	wc.n = Integer.valueOf( args[2] ).intValue();
	wc.produceMatrix( wc.r, wc.s, wc.n );
    }

    public void produceMatrix (int r, int s, int n) {
	int i, j, k;
	String totLine = "";

	for ( i = 1; i <= n; i++ ) {   
	    for ( j = 1; j <= n; j++ ) {
		for ( k = 1; k <= n, k != j; k++ ) {
		    if ( j == i ) 
			totLine = totLine + r + ' ';
		    if ( k == i ) 
			totLine = totLine + s + ' ';
		}	    		
	    
	    }
	    System.out.println(totLine);
	}
    }
}
