# Library
This contains the files

schubert.lib  - the Libraary we are creating for Singular

--------------------------------------------------------
Some notes by Frank:

We should have scripts here to run and test all routines in our libraries

The Schubert library should be rekeyed completely

We should have a separate library for our calculation of cycle types of 
  Frobenius elements

And the same for numbers of real solutions.  Nick Hein has some code for this, 
  I think.
