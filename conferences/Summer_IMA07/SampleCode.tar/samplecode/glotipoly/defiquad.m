function P = defiquad(A,b,c,t)
% Given a matrix A, a vector B and a scalar C, the instruction
%
%   P = DEFIQUAD(A,B,C,TYPE)
%
% returns a structure P in GloptiPoly's format corresponding to the
% quadratic expression x'*A*x + 2*B'*x + C
%
% An optional fourth input argument ('min', 'max', '>=', '<=', '==')
% specifies the expression type in P (default '>=',
% i.e. x'A*x + 2*B'*x + C >= 0)

% Author: Didier Henrion, December 21, 2001

P = [];

if ~isa(A,'double'),
 error('First input argument must be a matrix');
end;
[m,n] = size(A);
if n ~= m,
 error('First input argument must be a square matrix');
end;
A = (A+A')/2;
if nargin < 2, b = []; end;
if nargin < 3, c = []; end;
if nargin < 4, t = []; end;
if isempty(b), b = zeros(m, 1); end;
if isempty(c), c = 0; end;
if isempty(t), t = '>='; end;
if ~isa(b,'double') | (min(size(b)) > 1),
 error('Second input argument must be a column vector');
end;
if ~isa(c,'double') | (length(c) > 1),
 error('Third input argument must be a scalar');
end;
if length(b) ~= m,
 error('Incompatible dimensions of first and second input arguments');
end;

P = [];
P.c = sparse(m*(m+1)/2+m+1,1);
for row = 1:m,
 P.c(1+2*3^(row-1)) = A(row,row);
 P.c(1+3^(row-1)) = 2*b(row);
 for col = row+1:m,
  P.c(1+3^(row-1)+3^(col-1)) = 2*A(row,col);
 end;
end;
P.c(1) = c;
P.s = 3*ones(1,n);
P.t = t;

