import java.util.*;
import java.lang.*;


class wordscount {

    public int count = 0;
    public int n;
    public Hashtable  wordTable = new Hashtable();


    public static void main(String[] args) {
	wordscount wc = new wordscount();
	wc.n = Integer.valueOf( args[0] ).intValue();
	wc.recurse( "", 0, wc.n );
	System.out.println(wc.count);
    }

    public void recurse (String word, int length, int n) {
	
	if ( length == n ) {
	    if ( !inTable(word) ) {
		System.out.println(word);
		count++;
		wordTable.put( word, new Integer(1));
	    }		
	} else {
	    recurse( word + 'a', length + 1 , n);
	    recurse( word + 'b', length + 1 , n );
	}
    }
    public boolean inTable (String word) {

	String interchange, reversal = "";
	int i;

	interchange = word.replace('a','c');
	interchange = interchange.replace('b','a');
	interchange = interchange.replace('c','b');

	if ( wordTable.get( interchange ) != null ) 
	    return true;
	
	for ( i = 1; i <= word.length(); i++ ) 
	    reversal = reversal + word.charAt(word.length()-i);
		
	if ( word.equalsIgnoreCase( reversal ) )
	    return true;

	if ( wordTable.get( reversal ) != null ) 
	    return true;
	
	interchange = reversal.replace('a','c');
	interchange = interchange.replace('b','a');
	interchange = interchange.replace('c','b');
	
	if ( wordTable.get( interchange ) != null ) 
	    return true;
	
	return false;
    }
}

