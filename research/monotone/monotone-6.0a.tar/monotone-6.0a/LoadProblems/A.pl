#!/usr/bin/perl -w
################################################################################
#
#  Warning:  Must check the flags that are set in this program!
#
################################################################################
# Loads problems into database for the monotone conjecture project.  
#
# Created by Christopher Hillar
#  Modified by Frank Sottile and Zach Teitler
# 
#   Usage: perl loadproblems.pl -l Problems.file
#
#  Problems.file is a text file which has a |-delimited list of data
#     describing a Schubert problem to run.  
# 
#  ---->> Will need variable for 
#         * block or fine necklaces
#
#  # sols|name|Flag var.| enum perms | necklaces |
#
#       2|Y^3Z^2|2,3,4|1,3,2,4;1,3,2,4;1,3,2,4;1,2,4,3;1,2,4,3|1,2,3,4,5;1,2,4,3,5|
#
#   Computation type and algebraprogram  are set in this file
#
################################################################################

use PERL_LIBS::monotone;
#
$dbhr = {
# Math department:
#  'database' => 'monotoneSecant',     
  'database' => 'secantDevelopment',     
#  'database' => 'secantTesting',     
  'db_server' => 'dbu.math.tamu.edu',
  'db_user_name' => 'secant',
  'db_password' => 'Sec48MatH',
  'db_port' => '3306',
};
#
#   This tells the code which algebra programs to test
#
$ALGEBRA_PROGRAM      = 'both';
#$ALGEBRA_PROGRAM      = 'singular';
#$ALGEBRA_PROGRAM      = 'macaulay';

my $computationtype = 4;
#
#  Computation type is set here
# type   Description
#  4   +Pure monotone conjecture:  Osculating flags and necklaces, with one flag at infinity   fine necklaces
#  5   -Full monotone secant conjecture:  Disjoint secant flags and necklaces   fine necklaces
#  6   *Like #5, but with one osculating flag (at infinity)      fine necklaces
#  7   *Pure monotone conjecture:  Osculating flags and necklaces, with one flag at infinity  Block necklaces
#  8   *Full monotone secant conjecture:  Disjoint secant flags and necklaces  Block necklaces
#  9   *Like #8, but with one osculating flag (at infinity)        Block necklaces
#
#  + := implemented
#  - := not fully implemented
#  * := not currently implemented
#
##############################################################
# Default variable declarations
#
my $numiterations 	= 1;   # default NUMBER of PACKET COMPUTATIONS
$FLUSH_WORKING  	= 0;   # leave 'working' flags alone in Problem tables

# database defaults:

$SINGULAR_path        = 'Singular'; 
$MACAULAY2_path        = 'M2'; 
$MAPLE_path 	      = 'maple';
$PROBLEM_FILE_NAME    = 'testing';
$KEEPTEMPFILES	      = 0;
##############################################################

############################################################
# Command line parameters
#
# -dd   -->   Do not Delete temporary files (for debugging, etc.)
#
# -l    -->   pick filename to load problems from
#
#   Retrieval of command line parameters
#
my $parameters = "";
foreach my $argnum (0 .. $#ARGV) {
  $parameters .= $ARGV[$argnum];
}
if ( $parameters =~ m/-dd/ ) {
  $KEEPTEMPFILES = 1;
}
if ( $parameters =~ m/-l([a-zA-Z1-9.\/_]*)/ ) {
  $PROBLEM_FILE_NAME = $1;
}
#############################################################

$dbhr->{'datasource'} = "DBI:mysql:"
                   ."database=$dbhr->{'database'};"
                   ."hostname=$dbhr->{'db_server'};"
                   ."port=$dbhr->{'db_port'}";

# load this computer's information
my ($compid,$cpufreq,$host,$num_running_instances) = frsc_checkin( $dbhr );

if( $FLUSH_WORKING == 1 ) {
    frsc_flushdatabase( $dbhr );
}

########################################################################			
# Get the list of points (as rational numbers with , delimeters) 
# These are expected to be sorted in numeric order.
#######################################################################
@master_points=@{get_points( )};

my $logfile = $PROBLEM_FILE_NAME . ".log.load";
my $oldlog = $logfile."old";
if (-e $logfile) { 
  use File::Copy;
  move($logfile, $logfile.".old");
  print "moved old log file ! \n";
}
open LOGFILE, ">$logfile" or die "ERROR: could not open file $logfile - $!\n";

my $todaysdatetime = localtime(time);
printf(LOGFILE "Problems loaded from file %s into %s database by computer %s on %s \n", 
          $PROBLEM_FILE_NAME, $dbhr->{'database'}, $host,  $todaysdatetime);

one_iteration($dbhr,$compid,\@master_points,$host);

close(LOGFILE);

################################################################
# MAIN PROCEDURE
#
################################################################
# int one_iteration()
#
# This is the main heart of the code.  For each problem in the 
# problems file, it computes one (or more) runs through all 
# necklaces in both Singular and Macaulay 2, using the timing 
# to determine the packet size, number of files in each packets 
# and number of computations per file, as well as the algebra program.
#
sub one_iteration {
  my ($dbhr,$compid,$masterpoints,$host) = @_;
    
  use Benchmark;		

  # read input file
  open(PROBLEMS, $PROBLEM_FILE_NAME);
  my $line = "";
  my @problemarr;
  $problemcount = 0;
  # main loop to test timing and load each problem into dbase
  while (<PROBLEMS>){         # load file into $line	

    #  Avoid computing empty lines
    if (length($_)>10) {
    $problemcount++;
    $line = $_;
    # parse input specifications
    #
    #  # sols|name|Flag var.|  enum perms  |  necklaces  |
    #
    #       2|Y^3Z^2|2,3,4|1,3,2,4;1,3,2,4;1,3,2,4;1,2,4,3;1,2,4,3|1,2,3,4,5;1,2,4,3,5|
    $line =~ m/([0-9]+)\|([A-Z^0-9,]+)\|([0-9,]+)\|([0-9,;]+)\|([0-9,;]+)\|/g;  
    #
    $numsolutions = $1;				
    $problemname = $2;
    $flagvariety = $3;
    $allperms = $4;
    $necklaces_raw = $5;

    my @flag;
    while ($flagvariety =~ m/([0-9]+)/g ) {	# pick out flag variety and dimension
      push(@flag,$1);
    }		
    $flagvariety = "$flag[0]";
    for ( my $i = 1; $i < $#flag; $i++ ) {
      $flagvariety = $flagvariety.", $flag[$i]";
    }
    $dimension = $flag[$#flag];

    # get list of Schubert conditions
    $schubertconditions = "";
    while ( $allperms =~ m/([0-9,]+)/g ) {
      $schubertconditions .= "[$1]";
    }

    # get list of necklaces
    $necklaces = "";
    $number_necklaces = 0;
    while ( $necklaces_raw =~ m/([0-9,]+)/g ) {
      $necklaces .= "[$1]";
      $number_necklaces++;
    }

    # check if this flag variety exists in the dbase
    my $datasource = "DBI:mysql:"
         ."database=$dbhr->{'database'};"
         ."hostname=$dbhr->{'db_server'};"
         ."port=$dbhr->{'db_port'}";
    my $dbh = DBI->connect($datasource,
           $dbhr->{'db_user_name'},
           $dbhr->{'db_password'},
                  {RaiseError => 1, AutoCommit => 0});
    my $sth = $dbh->prepare("SELECT id FROM FlagVariety WHERE (dimension='$dimension' AND
                               flagvariety='$flagvariety');");
    $sth->execute();

    # if the flag variety is in there
    if ( ($flagid) = $sth->fetchrow_array() ) {
      } else {		# need to add flag variety to dbase
      my $sth2 = $dbh->prepare(qq{INSERT INTO FlagVariety (flagvariety,dimension) values 
                                    ('$flagvariety','$dimension');});	
      $sth2->execute();
      $flagid = $dbh->{'mysql_insertid'};		
    }
    # now insert Schubert problem into database		
    $sth = $dbh->prepare("SELECT id FROM SchubertProblems WHERE (flagvariety_id='$flagid'
 			AND numsolutions='$numsolutions'
 			AND schubertconditions='$schubertconditions');");
    $sth->execute();
    my $schubertproblemid;
    
    # if the Schubert problem is in there 
    if ( ($schubertproblemid) = $sth->fetchrow_array() ) {
      } else {		# need to add Schubert problem to database
      my $sth2 = $dbh->prepare(qq{INSERT INTO SchubertProblems 
             (problemname, schubertconditions, numsolutions, flagvariety_id )
            values
             ('$problemname', '$schubertconditions', '$numsolutions', '$flagid');});
      $sth2->execute();
      $schubertproblemid = $dbh->{'mysql_insertid'};					
    }

    # now insert Necklaces into database		
    $sth = $dbh->prepare("SELECT id FROM Necklaces WHERE (necklaces='$necklaces');");
    $sth->execute();
    my $necklaceid;
    
    # if the Necklace is in there 
    if ( ($necklace_id) = $sth->fetchrow_array() ) {
      } else {		# need to add necklace to database
      my $sth2 = $dbh->prepare(qq{INSERT INTO Necklaces
             (necklaces)
            values
             ('$necklaces');});
      $sth2->execute();
      $necklace_id = $dbh->{'mysql_insertid'};					
    }

    $sth->finish();
    $dbh->commit();
    $dbh->disconnect();

    ##########################################################################################
    # We now run the problem to get the timing information, once for Singular and once for 
    # Macaulay2.    This is used to determine the optimal algebra program, as well as 
    # packet size, files per packet and computations per file according to the rule:
    # num packets * num files * num computations per file * number_necklaces 
    # Should be around 2 hours of processing time.

    printf( LOGFILE "\nStatistics for loading the Schubert problem %s=%d with computation type %d:\n",
                    $problemname,$numsolutions,$computationtype);
    #
    #  We compute small problems many times to reduce Singular/Macaulay2/Sage/Maple loading issues
    #
    my $prob = {
        'packetnumber'   => 1,
        'priority'       => 0,
        'request_id'     => $problemname,          
        'computationtypeid' => $computationtype,
        'necklace_id'      => $necklace_id,
        'number_necklaces' => $number_necklaces, 
        'schubertproblem_id' => $schubertproblemid,
        'problemname'    => $problemname,
        'schubertconditions'   => $schubertconditions,
        'numsolutions'   => $numsolutions,
        'flagvariety'    => $flagvariety,
        'dimension'      => $dimension,
#        'necklace_type'     => $necklace_type, 
        'necklaces'         => $necklaces, 
    };

    # First find computation time in Singular
    $Stime = 0.;
    $Scomputationsperfile = 1;
    if ( $ALGEBRA_PROGRAM ne 'macaulay' ) {
      while ( $Stime < 10){ 

        $prob->{'numcomputationsperfile'} = $Scomputationsperfile;
        $prob->{'subpacket'} = $Scomputationsperfile;
        my $files = set_up_filenames($prob);

        ###################################################
        # make SINGULAR file for the computation
        ###################################################
    
        # creates new singular file with problem initializations
        $t0 = new Benchmark;

        $prob->{'algebraprogram'} = "singular";

        my (@crossnumbers) = write_algebra_file($options,$prob,$files,$masterpoints);

         # run Singular file 
        my $status = system("nice -n20 $SINGULAR_path -q < $files->{'singularinput'}");

        # creates new maple file with proper header
        write_maple_input_file($prob,$files);
 
        # now run maple file 
        $status = system("nice -n20 $MAPLE_path -q < $files->{'mapleinput'} > $files->{'results'}");

        # perl time benchmarking
        $t1 = new Benchmark;           
        $td = timediff($t1, $t0);
        my $timestr = timestr($td);
        $timestr =~ m/([.0-9]+) CPU/g;
        $Stime = $1; # in seconds (NOT scaled to cpu speed), whole loop 
#        printf("Singular computes all %-3d instances in %-7.3f seconds\n",$#crossnumbers+1,$Stime/$Scomputationsperfile);
#        printf(LOGFILE "Singular computes all %-3d instances in %-7.3f seconds\n",$#crossnumbers+1,$Stime/$Scomputationsperfile);
        #######################################################
        #
        # Erase temporary files unless the -dd option is used
        #
        #######################################################
        if( !$KEEPTEMPFILES ) {
          frsc_remove_temp_files($files) ;
        }
    
        #  If the computation went too fast, adjust the number of computations 
        #  and run the computation again.  This is to get more accurate timing data
        #
        if ( $Stime < 10 ) {
           $Scomputationsperfile = int ($Scomputationsperfile * 25/$Stime);
        }
      }
    }
    printf(LOGFILE "Singular computes all %-3d instances in %-7.3f seconds\n",$#crossnumbers+1,$Stime);

    # First find computation time in Macaulay
    $Mtime = 0.;
    $Mcomputationsperfile = 1;
    if ( $ALGEBRA_PROGRAM ne 'singular' ) {
      while ( $Mtime < 10){ 

        $prob->{'numcomputationsperfile'} = $Mcomputationsperfile;
        $prob->{'subpacket'} = $Mcomputationsperfile;
        my $files = set_up_filenames($prob);

        ###################################################
        # make Macaulay 2 file for the computation
        ###################################################
    
        # creates new Macaulay 2 file with problem initializations
        $t0 = new Benchmark;
        $prob->{'algebraprogram'} = "macaulay";
        my (@crossnumbers) = write_algebra_file($options,$prob,$files,$masterpoints);

        # run Macaulay 2 file 
        my $status = system("nice -n20 $MACAULAY2_path --script $files->{'macaulayinput'}");

        # creates new maple file with proper header
        write_maple_input_file($prob,$files);
 
        # now run maple file 
        $status = system("nice -n20 $MAPLE_path -q < $files->{'mapleinput'} > $files->{'results'}");

        # perl time benchmarking
        $t1 = new Benchmark;           
        $td = timediff($t1, $t0);
        my $timestr = timestr($td);
        $timestr =~ m/([.0-9]+) CPU/g;
        $Mtime = $1; # in seconds (NOT scaled to cpu speed), whole loop 
#        printf("Macaulay computes all %-3d instances in %-7.3f seconds\n",$#crossnumbers+1,$Mtime/$Mcomputationsperfile);
#        printf(LOGFILE "Macaulay computes all %-3d instances in %-7.3f seconds\n",$#crossnumbers+1,$Mtime/$Mcomputationsperfile);

        #######################################################
        #
        # Erase temporary files unless the -dd option is used
        #
        #######################################################
        if( !$KEEPTEMPFILES ) {
          frsc_remove_temp_files($files) ;
        }
    
        #  If the computation went too fast, adjust the number of computations 
        #  and run the computation again.  This is to get more accurate timing data
        #
        if ( $Mtime < 10 ) {
           $Mcomputationsperfile = int ($Mcomputationsperfile * 25/$Mtime);
        }
      }
    }
    printf(LOGFILE "Macaulay computes all %-3d instances in %-7.3f seconds\n",$#crossnumbers+1,$Mtime);

    #  Decide which algebra program to use
    $AlPr = $ALGEBRA_PROGRAM;

    if ( $ALGEBRA_PROGRAM eq 'both' ) { 
      if ( $Mtime/$Mcomputationsperfile < $Stime/$Scomputationsperfile ) {
        $AlPr = "macaulay";
      }
       if ( $Mtime/$Mcomputationsperfile >=  $Stime/$Scomputationsperfile ) {
        $AlPr = "singular";
      }
     }
    if ( $AlPr eq 'macaulay' ) { 
      $algebraprogram = "macaulay";
      $computationtime = $Mtime;
      $numcomputationsperfile = $Mcomputationsperfile;
    }
    if ( $AlPr eq 'singular' ) { 
      $algebraprogram = "singular";
      $computationtime = $Stime;
      $numcomputationsperfile = $Scomputationsperfile;
     }
    #   We now use this to determine how many runs through all necklaces 
    # can be computed in one hour, and then use that to determine packetsize,  
    # the number of computations per file, and the total number of packets
    #
    my $secondsperrun = $computationtime/$numcomputationsperfile;
    my $numberInTwoHours = 7200/$secondsperrun;

    printf(LOGFILE "    ---- In two hours, %s can compute %3.0f runs through all %d necklaces.\n",
              $algebraprogram,$numberInTwoHours,$number_necklaces);

    ############################################################################
    # This will set the computationlength_id in the dbase for this problem
    #  The default are packages that finish in about two hours
    my $computationLength = 1;  
    my $priority = 0;

    # Easy ones:  Over 50,000 runs in two hours        50 K
    if ($numberInTwoHours >= 50000 ) {
        $totalnumpackets = 1;
        $packetsize = 200;
        $numcomputationsperfile = 250;
    }
    #  Between 50,000 and 25,000 in about two hours    50 K     
    if ( 50000 > $numberInTwoHours  and  $numberInTwoHours >= 25000 ) {
        $totalnumpackets = 2;
        $packetsize = 200;
        $numcomputationsperfile = 125;
    }
    #  Between 25,000 and 15,000 in about two hours    60 K     
    if ( 25000 > $numberInTwoHours  and  $numberInTwoHours >= 15000 ) {
        $totalnumpackets = 4;
        $packetsize = 200;
        $numcomputationsperfile = 75;
    }
    #  Between 15,000 and 10,000 in about two hours    60 K     
    if ( 15000 > $numberInTwoHours  and  $numberInTwoHours >= 10000 ) {
        $totalnumpackets = 6;
        $packetsize = 100;
        $numcomputationsperfile = 100;
    }
    #  Between 10,000 and 5,000 in about two hours    75 K     
    if ( 10000 > $numberInTwoHours  and  $numberInTwoHours >= 5000 ) {
        $totalnumpackets = 20;
        $packetsize = 50;
        $numcomputationsperfile = 100;
    }
    #  Between 5000 and 2500 in about two hours    100 K     
    if ( 5000 > $numberInTwoHours  and  $numberInTwoHours >= 2500 ) {
        $totalnumpackets = 40;
        $packetsize = 50;
        $numcomputationsperfile = 50;
    }
    #  Between 2500 and 1500 in about two hours    90 K     
    if ( 2500 > $numberInTwoHours  and  $numberInTwoHours >= 1000 ) {
        $totalnumpackets = 60;
        $packetsize = 20;
        $numcomputationsperfile = 75;
    }
    #  Between 1500 and 1000 in about two hours    100 K     
    if ( 1500 > $numberInTwoHours  and  $numberInTwoHours >= 1000 ) {
        $totalnumpackets = 80;
        $packetsize = 25;
        $numcomputationsperfile = 50;
    }
    #  Between 1000 and 500 in about two hours    150 K     
    if ( 1000 > $numberInTwoHours  and  $numberInTwoHours >= 500 ) {
        $totalnumpackets = 300;
        $packetsize = 10;
        $numcomputationsperfile = 50;
    }
    #  Between 500 and 250 in about two hours    150 K     
    if ( 500 > $numberInTwoHours  and  $numberInTwoHours >= 250 ) {
        $totalnumpackets = 600;
        $packetsize = 10;
        $numcomputationsperfile = 25;
    }
    #  Between 250 and 150 in about two hours    120 K     
    if ( 250 > $numberInTwoHours  and  $numberInTwoHours >= 150 ) {
        $totalnumpackets = 1500;
        $packetsize = 6;
        $numcomputationsperfile = 25;
    }
    #  Between 150 and 100 in about two hours    150 K     
    if ( 150 > $numberInTwoHours  and  $numberInTwoHours >= 100 ) {
        $totalnumpackets = 1500;
        $packetsize = 4;
        $numcomputationsperfile = 25;
    }
    #  Between 100 and 50 in about two hours    100 K     
    if ( 100 > $numberInTwoHours  and  $numberInTwoHours >= 50 ) {
        $totalnumpackets = 2000;
        $packetsize = 5;
        $numcomputationsperfile = 10;
    }
##################  computationlength 2  (4 hours) ###############################

    #  Between 50 and 25 in about two hours    100 K     
    if ( 50 > $numberInTwoHours  and  $numberInTwoHours >= 25 ) {
        $totalnumpackets = 2000;
        $packetsize = 10;
        $numcomputationsperfile = 5;
        $computationLength = 2;  # This has intermediate size
    }
    #  Between 25 and 15 in about two hours    90 K     
    if ( 25 > $numberInTwoHours  and  $numberInTwoHours >= 15 ) {
        $totalnumpackets = 3000;
        $packetsize = 6;
        $numcomputationsperfile = 5;
        $computationLength = 2;  # This has intermediate size
    }
    #  Between 15 and 10 in about two hours   100 K     
    if ( 15 > $numberInTwoHours  and  $numberInTwoHours >= 10 ) {
        $totalnumpackets = 5000;
        $packetsize = 4;
        $numcomputationsperfile = 5;
        $computationLength = 2;  # This has intermediate size
    }
    #  Between 10 and 5 in about two hours   50 K     
    if ( 10 > $numberInTwoHours  and  $numberInTwoHours >= 5 ) {
        $totalnumpackets = 5000;
        $packetsize = 2;
        $numcomputationsperfile = 5;
        $computationLength = 2;  # This has intermediate size
    }
    #  4 in about two hours   40 K     
    if ( $numberInTwoHours == 4 ) {
        $totalnumpackets = 5000;
        $packetsize = 2;
        $numcomputationsperfile = 4;
        $computationLength = 2;  # This has intermediate size
    }
    #  3 in about two hours   40 K     
    if ( $numberInTwoHours == 3 ) {
        $totalnumpackets = 5000;
        $packetsize = 2;
        $numcomputationsperfile = 3;
        $computationLength = 2;  # This has intermediate size
    }
    ##########################################################################################
    #  Here are the longer computation types
    #
    #  2: 2 --  4 hours
    #  3: 4 --  8 hours
    #  4: 8 -- 16 hours
    #  5: > 16 hours

    if ( $numberInTwoHours < 3 ) {
      my $hr = 3600;
      if ( $hr > $secondsperrun) {
         $totalnumpackets = 5000;
         $packetsize = 2;
         $numcomputationsperfile = 2;
         $computationLength = 2;  # This has intermediate size
      }
      if ( 2*$hr > $secondsperinstance and $secondsperinstance >= $hr ) {
         $totalnumpackets = 2500;
         $packetsize = 1;
         $numcomputationsperfile = 2;
         $computationLength = 2;  # This has intermediate size
      }
      if ( 4*$hr > $secondsperinstance and $secondsperinstance >= 2*$hr ) {
         $totalnumpackets = 2000;
         $packetsize = 2;
         $numcomputationsperfile = 1;
         $computationLength = 3;  
      }
      if ( 8*$hr > $secondsperinstance and $secondsperinstance >= 4*$hr ) {
         $totalnumpackets = 1000;
         $packetsize = 1;
         $numcomputationsperfile = 1;
         $computationLength = 3;  
      }
      if ( 16*$hr > $secondsperinstance and $secondsperinstance >= 8*$hr ) {
         $totalnumpackets = 1000;
         $packetsize = 1;
         $numcomputationsperfile = 1;
         $computationLength = 4;  
      }
      if ( $secondsperinstance >= 16*$hr ) {
         $totalnumpackets = 500;
         $packetsize = 1;
         $numcomputationsperfile = 1;
         $computationLength = 5;  
      }

    }


##################################################################################

    printf(LOGFILE "   The time for a single run through all necklaces was %6.4f CPU seconds.\n",
                  $secondsperrun);
    printf(LOGFILE "   This problem will have %d packets, each consisting of %d files containing %d computations,\n",
                  $totalnumpackets,$packetsize,$numcomputationsperfile);
    printf(LOGFILE "      and is scheduled to compute %d distinct Schubert problems in all.\n",
             $number_necklaces*$packetsize*$numcomputationsperfile*$totalnumpackets);
    printf(LOGFILE "   -Expected time per packet is %7.3f hours, and the request should consume %8.3f hours.\n",
             $packetsize*$numcomputationsperfile*$secondsperrun/3600,
             $packetsize*$numcomputationsperfile*$secondsperrun*$totalnumpackets/3600);

    my $cpufreq = figure_out_clockspeed($host);
    if ( $cpufreq == 0 ) {
       $cpufreq = 2600 ; # Speed of Frank's machine Hopf
    }
    # Scale timeperinstance to MHz-seconds
    my $mhzsecondsperinstance = $secondsperrun*$number_necklaces*$cpufreq;
    
    # update the Schubert problem 
    $dbh = DBI->connect($dbhr->{'datasource'},
                        $dbhr->{'db_user_name'},
                        $dbhr->{'db_password'},
                          {RaiseError => 1, AutoCommit => 0});         

#######################################################################

    $sth = $dbh->prepare(qq{SELECT id FROM Requests WHERE 
                 (schubertproblem_id='$schubertproblemid' AND 
                  necklace_id='$necklace_id' AND computationtype_id='$computationtype');});
    $sth->execute();
    my $requestid; 

#    print "totalnumpackets ", $totalnumpackets, "\n";
#    print "schubertproblem_id ", $schubertproblemid, "\n";
#    print "computationtype_id ", $computationtype, "\n";
#    print "computationlength_id ", $computationLength, "\n";
#    print "algebraprogram ", $algebraprogram, "\n";
#    print "necklace_id ", $necklace_id, "\n";
#    print "number_necklaces ", $number_necklaces, "\n";
#    print "priority ", 0, "\n";
#    print "packetsize ", $packetsize, "\n";
#    print "numcomputationsperfile ", $numcomputationsperfile, "\n";

    #
    #  This does not write over an old request !
    #
    if ( ($requestid) = $sth->fetchrow_array() ) {
      } else {		# need to add request to database
      $sth3 = $dbh->prepare(qq{INSERT INTO Requests 
           (totalnumpackets,schubertproblem_id,computationtype_id,computationlength_id,algebraprogram,
            necklace_id,number_necklaces,priority,packetsize,numcomputationsperfile,mhzsecondsperinstance) 
	 values 
          ('$totalnumpackets','$schubertproblemid','$computationtype','$computationLength','$algebraprogram','$necklace_id',
           '$number_necklaces','0','$packetsize','$numcomputationsperfile','$mhzsecondsperinstance');});	
      $sth3->execute();                                             
      $requestid = $dbh->{'mysql_insertid'};					
    }

    $sth->finish();
    $dbh->commit();
    $dbh->disconnect();
    print "request_id ", $requestid, "\n";

}
}
  close(PROBLEMS);
  return 1;
}
