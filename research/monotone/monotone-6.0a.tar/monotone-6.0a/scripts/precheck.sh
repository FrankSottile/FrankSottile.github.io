#!/bin/bash
#
#  precheck.sh
#
#  Check for presence of prerequisite items:
#  1. Perl Math/Random.pl library
#  2. Perl DBI library
#  3. Perl DBD/mysql library
#
#  Check frsc-tmp exists
#
#  If all prerequisite items are present, return 0 ("success")
#  otherwise return 1

perllibmathrandom=`perl -MMath::Random  -e 'print "ok"' 2> /dev/null`

if [[ "$perllibmathrandom" != "ok" ]]; then
  exit 1
fi

perllibdbi=`perl -MDBI  -e 'print "ok"' 2> /dev/null`

if [[ "$perllibdbi" != "ok" ]]; then
  exit 1
fi

perllibdbdmysql=`perl -MDBD::mysql  -e 'print "ok"' 2> /dev/null`

if [[ "$perllibdbdmysql" != "ok" ]]; then
  exit 1
fi


if [ ! -e frsc-tmp ] ; then
  exit 1
fi
if [ ! -e frsc-tmp/$host ] ; then
  exit 1
fi

exit 0
