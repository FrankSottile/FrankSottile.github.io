use 5.008006;
use strict;
use warnings;

# expected_time_to_complete
# create_running_instance
# get_problem_info_from_runninginstance

# expected_time_to_complete 
# Compute amount of time (in seconds)
#  expected to take for a packet.
# Determined by computation length id

sub expected_time_to_complete {
  my ($config, $prob) = @_;
  my @lengths = (3.5, 7, 15, 24, 50, 80);
  # 
  # computationlength   length in hours  Upper Bound
  #        1              <2               3:30
  #        2              2-4              7:00
  #        3              4-8             15:00
  #        4              8-16            24:00
  #        5             16-40            50:00
  #                        
  #
  return $lengths[$prob->{'computationlength_id'}-1]*3600;
}

sub expected_time_to_complete_old {
  my ($config, $prob) = @_;
  my $x = $prob->{'mhzsecondsperinstance'}
            *$prob->{'packetsize'}
            *$prob->{'numcomputationsperfile'}
            *$prob->{'number_necklaces'} ;
  if ( $config->{'cpufreq'} == 0 ) {
    # Don't know CPU speed. Should have died before this point.
    die "Please enter CPU speed into database.";
  } else {
    $x = int $x/$config->{'cpufreq'};
  }
  return $x;
}

# create_running_instance
# Create and post a RunningInstance record
# Input:
#   $config - hash reference with configuration information
#   $prob   - hash reference with info about problem
#   $dbh    - a handle to a database connection
# Output: the ID of the created runninginstance,
#         human-readable time when expected to finish,
#         expected time to complete (in honest seconds)
sub create_running_instance {
  my ($config,$prob,$dbh) = @_;
  my $thedatetime = time();
    # time in seconds since epoch   (epoch = 1970)
  my $time_to_complete = &expected_time_to_complete($config,$prob);
  my $expected_finish_time = $time_to_complete + $thedatetime;
  my $startdate_human = localtime($thedatetime);
  my $expectedfinish_human = localtime($expected_finish_time);
  
  my $run_id;
  eval {
  my $created_runninginstance_yet=0;
  my $tries_left=10;
  my $sleep_interval=30;
  while( $created_runninginstance_yet==0 && $tries_left>0 ) {
    my $returnvalue = $dbh->do(qq{INSERT INTO RunningInstance 
          (request_id,
           startdate,
           packetnumber,
           computer_id,
           expected_time_to_finish,
           startdate_human,
           expected_finish_human,
           priority,
           computationlength_id)
          values
          ($prob->{'request_id'},
           '$thedatetime',
           $prob->{'packetnumber'},
           $config->{'compid'},
           '$expected_finish_time',
           '$startdate_human',
           '$expectedfinish_human',
           $prob->{'priority'},
           $prob->{'computationlength_id'});});
  
    $run_id = $dbh->last_insert_id(undef,undef,undef,undef);
    # MySQL ignores the arguments of that command,
    # see: <http://search.cpan.org/~timb/DBI/DBI.pm#last_insert_id>
    if( $returnvalue && $run_id ) {
      $dbh->commit();
      $created_runninginstance_yet=1;
    } else {
      $tries_left -= 1;
      sleep $sleep_interval;
      $sleep_interval += 15;
    }
  }
  };
  if($@ || !$run_id) {
    print "Error, could not create RunningInstance record\n";
    for my $i (keys %{$prob}) {
        print "$i: $prob->{$i}.\n";
    }
    ### email!!! ###
    if( $config->{'email_to'} ) {
      system("echo -e \"Could not create RunningInstance record: ".
           "request_id=$prob->{'request_id'}, packet=$prob->{'packetnumber'}, computationlength_id=$prob->{'computationlength_id'}\n".
           "Host: $config->{'hostname'} at ".localtime()."\n".
           "Please run: INSERT INTO RunningInstance (request_id,priority,expected_time_to_finish,packetnumber,computationlength_id) ".
           "VALUES ($prob->{'request_id'}, $prob->{'priority'}, $expected_finish_time, $prob->{'packetnumber'}, $prob->{'computationlength_id'})\n\n\" ".
           " | mail -s \"Could not create RunningInstance record\" $config->{'email_to'}");
    }
    die;
  }
  
  return ($run_id,$expectedfinish_human,$time_to_complete);    
}


# get_problem_info_from_runninginstance
# Given a RunningInstance id,
# retrieve all the information from that problem's
# Request and SchubertProblem records.
# Input:
#   run_id - integer, the id of the RunningInstance record
#   dbh    - handle to database connection
# Output:
#   a hash reference containing information about the problem
#   that the RunningInstance was working on,
#   or 0 if an error occured
# It uses a huge JOIN query to get information from four tables together:
# RunningInstance, Requests, SchubertProblems, FlagVariety
sub get_problem_info_from_runninginstance {
  my ($run_id,$dbh) = @_;
  my $longquery = qq{SELECT 
               RunningInstance.packetnumber,
               RunningInstance.priority,
               RunningInstance.computationlength_id,
               Requests.id AS request_id,
               Requests.totalnumpackets,
               Requests.computationtype_id,
               Requests.algebraprogram, 
               Requests.necklace_id AS necklace_id,
               Requests.number_necklaces,
               Requests.initialrandseed,
               Requests.packetsize,
               Requests.numcomputationsperfile,
               Requests.mhzsecondsperinstance,
               SchubertProblems.id AS schubertproblem_id,
               SchubertProblems.problemname,
               SchubertProblems.schubertconditions,
               SchubertProblems.numsolutions,
               FlagVariety.flagvariety,
               FlagVariety.dimension,
               Necklaces.necklaces
        FROM RunningInstance JOIN Requests
              JOIN SchubertProblems JOIN FlagVariety JOIN Necklaces
        WHERE (RunningInstance.id = '$run_id'
               AND Necklaces.id = necklace_id
               AND RunningInstance.request_id = Requests.id
               AND Requests.schubertproblem_id = SchubertProblems.id
               AND SchubertProblems.flagvariety_id = FlagVariety.id)};
  my $sth = $dbh->prepare($longquery);
  $sth->execute();
  if( my ($packetnumber,$priority,$computationlength_id,
          $request_id, $totalnumpackets, $computationtype_id, $algebraprogram, $necklace_id, 
            $number_necklaces, $initialrandseed, $packetsize, $numcomputationsperfile,$mhzsecondsperinstance,
          $schubertproblem_id, $problemname, $schubertconditions, $numsolutions, 
          $flagvariety,$dimension,
          $necklaces) = $sth->fetchrow_array() ) {
    # Got the problem data!
    # Find random seed *for this packet*
    my $initseed;
    ### use secant_misc.pm->find_packet_random_seed ###
    $initseed = find_packet_random_seed($initialrandseed,$packetnumber);
    # Put the problem data in a hash.
    my $problemhash = {
            'packetnumber'      => $packetnumber,
            'priority' 		 => $priority,
            'computationlength_id' => $computationlength_id,
            'request_id'       => $request_id,
            'totalnumpackets'  => $totalnumpackets,
	    'computationtypeid' => $computationtype_id,
            'algebraprogram'   => $algebraprogram, 
            'necklace_id'      => $necklace_id,
            'number_necklaces' => $number_necklaces, 
            'initseed'         => $initseed,
            'packetsize'       => $packetsize, 
            'numcomputationsperfile'  => $numcomputationsperfile,
	    'schubertproblem_id' => $schubertproblem_id,
            'problemname'       => $problemname,
            'schubertconditions' => $schubertconditions,
            'numsolutions'      => $numsolutions,
	    'mhzsecondsperinstance' => $mhzsecondsperinstance,
            'flagvariety'       => $flagvariety,
            'dimension'         => $dimension,
            'necklaces'         => $necklaces, 
    };
    $sth->finish();
    return $problemhash;
  } else {
    # Couldn't find the info!
    $sth->finish();
    return 0;
  }
}

return 1;
__END__
