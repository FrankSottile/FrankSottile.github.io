function P = defifin(A,b,t)
% Given a matrix A and a vector B, the instruction
%
%   P = DEFILIN(A,B)
%
% returns a cell array of structures P in GloptiPoly's format
% corresponding to the linear expression A*x + B
%
% An optional third input argument ('min', 'max', '>=', '<=', '==')
% specifies the expression type in P (default '>=', i.e. A*x + B >= 0)

% Author: Didier Henrion, December 21, 2001

P = [];

if ~isa(A,'double'),
 error('First input argument must be a matrix');
end;
[m,n] = size(A);
if nargin < 2, b = []; end;
if nargin < 3, t = []; end;
if isempty(b), b = zeros(m, 1); end;
if isempty(t), t = '>='; end;
if ~isa(b,'double') | (min(size(b)) > 1),
 error('Second input argument must be a column vector');
end;
if length(b) ~= m,
 error('Incompatible dimensions of first and second input arguments');
end;

P = cell(1, m);
for row = 1:m,
 nzA = find(A(row,:));
 nbnzA = length(nzA);
 P{row}.c = sparse(nbnzA, 1); 
 for ent = 1:nbnzA
  P{row}.c(1+2^(nzA(ent)-1)) = A(row, nzA(ent));
 end;
 P{row}.c(1) = b(row);
 P{row}.s = 2*ones(1, n);
 P{row}.t = t;
end;





