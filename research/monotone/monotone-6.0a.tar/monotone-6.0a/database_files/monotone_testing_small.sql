# Sequel Pro dump
# Version 2210
# http://code.google.com/p/sequel-pro
#
# Host: dbu.math.tamu.edu (MySQL 5.0.67)
# Database: secantTesting
# Generation Time: 2010-05-14 13:57:57 -0500
# ************************************************************

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table ComputationLengthType
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ComputationLengthType`;

CREATE TABLE `ComputationLengthType` (
  `id` int(11) NOT NULL auto_increment,
  `computation_length` tinytext,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

LOCK TABLES `ComputationLengthType` WRITE;
/*!40000 ALTER TABLE `ComputationLengthType` DISABLE KEYS */;
INSERT INTO `ComputationLengthType` (`id`,`computation_length`)
VALUES
	(1,'Less than two hours'),
	(2,'two to four hours'),
	(3,'four to eight hours'),
	(4,'eight to sixteen hours'),
	(5,'over sixteen hours');

/*!40000 ALTER TABLE `ComputationLengthType` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table ComputationType
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ComputationType`;

CREATE TABLE `ComputationType` (
  `id` int(11) NOT NULL auto_increment,
  `description` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

LOCK TABLES `ComputationType` WRITE;
/*!40000 ALTER TABLE `ComputationType` DISABLE KEYS */;
INSERT INTO `ComputationType` (`id`,`description`)
VALUES
	(1,'Grassmannian, all secant flags, and Markov steps'),
	(2,'Grassmannian, osculating flag at infinity, and Markov steps'),
	(3,'Grassmannian, osculating flags at zero and infinity, and Markov steps'),
	(4,'Partial flags, all osculating flags with one at infinity, fine necklaces'),
	(5,'Partial flags,  all secant flags, and fine necklaces'),
	(6,'Partial flags, one osculating flag at infinity, the rest secant flags, and fine necklaces'),
	(7,'Partial flags, all osculating flags, and coarse necklaces '),
	(8,'Partial flags, all secant flags, and coarse necklaces'),
	(9,'Partial flags, one osculating flag at infinity, the rest secant flags, and coarse necklaces');

/*!40000 ALTER TABLE `ComputationType` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Computer
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Computer`;

CREATE TABLE `Computer` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(64) default NULL,
  `numcpus` int(11) default '1',
  `clockspeed` int(11) default NULL,
  `time_mhzseconds` bigint(40) default '0',
  `ostype_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

LOCK TABLES `Computer` WRITE;
/*!40000 ALTER TABLE `Computer` DISABLE KEYS */;
INSERT INTO `Computer` (`id`,`name`,`numcpus`,`clockspeed`,`time_mhzseconds`,`ostype_id`)
VALUES
	(1,'miln303',4,2830,0,1),
	(2,'schubert.math.tamu.edu',24,2600,0,1);

/*!40000 ALTER TABLE `Computer` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table FlagVariety
# ------------------------------------------------------------

DROP TABLE IF EXISTS `FlagVariety`;

CREATE TABLE `FlagVariety` (
  `id` int(11) NOT NULL auto_increment,
  `flagvariety` tinytext,
  `dimension` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

LOCK TABLES `FlagVariety` WRITE;
/*!40000 ALTER TABLE `FlagVariety` DISABLE KEYS */;
INSERT INTO `FlagVariety` (`id`,`flagvariety`,`dimension`)
VALUES
	(1,'2, 3',4),
	(2,'2, 3, 4',5),
	(3,'1, 2, 3, 4',5),
	(4,'1, 2',5),
	(5,'1, 3',5),
	(6,'2, 3',5),
	(7,'1, 2, 3',5);

/*!40000 ALTER TABLE `FlagVariety` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Necklaces
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Necklaces`;

CREATE TABLE `Necklaces` (
  `id` int(11) NOT NULL auto_increment,
  `necklaces` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

LOCK TABLES `Necklaces` WRITE;
/*!40000 ALTER TABLE `Necklaces` DISABLE KEYS */;
INSERT INTO `Necklaces` (`id`,`necklaces`)
VALUES
	(1,'[1,2,3,4,5][1,2,4,3,5]'),
	(2,'[1,2,3,4,5,6,7][1,2,3,5,4,6,7][1,2,3,6,4,5,7][1,2,3,7,4,5,6][1,2,4,5,3,6,7][1,2,4,6,3,5,7][1,2,4,7,3,5,6][1,2,5,6,3,4,7][1,2,5,7,3,4,6][1,2,6,7,3,4,5][1,3,2,4,5,6,7][1,3,2,5,4,6,7][1,3,2,6,4,5,7][1,3,2,7,4,5,6][1,3,4,5,2,6,7][1,3,4,6,2,5,7][1,3,5,6,2,4,7][1,4,2,3,5,6,7][1,4,2,5,3,6,7][1,4,2,6,3,5,7][1,4,2,7,3,5,6][1,4,3,5,2,6,7][1,4,3,6,2,5,7][1,5,2,3,4,6,7][1,5,2,4,3,6,7][1,5,2,6,3,4,7][1,5,3,4,2,6,7][1,6,2,3,4,5,7][1,6,2,4,3,5,7][1,6,2,5,3,4,7]'),
	(3,'[1,2,3,4,5][1,2,3,5,4][1,3,2,4,5][1,4,2,3,5]'),
	(4,'[1,2,3,4,5,6,7][1,3,2,4,5,6,7][1,4,2,3,5,6,7]'),
	(5,'[1,2,3,4,5,6,7][1,3,2,4,5,6,7][1,4,2,3,5,6,7]'),
	(6,'[1,2,3,4,5,6,7][1,2,3,5,4,6,7][1,2,3,6,4,5,7][1,2,3,7,4,5,6][1,2,4,5,3,6,7][1,2,4,6,3,5,7][1,2,4,7,3,5,6][1,2,5,6,3,4,7][1,3,4,5,2,6,7][1,3,4,6,2,5,7]'),
	(7,'[1,2,3,4,5,6,7,8][1,2,3,4,6,5,7,8][1,2,3,4,7,5,6,8][1,2,3,4,8,5,6,7][1,2,3,5,6,4,7,8][1,2,3,5,7,4,6,8][1,2,3,5,8,4,6,7][1,2,3,6,7,4,5,8][1,2,4,5,6,3,7,8][1,2,4,5,7,3,6,8][1,3,2,4,5,6,7,8][1,3,2,4,6,5,7,8][1,3,2,4,7,5,6,8][1,3,2,4,8,5,6,7][1,3,2,5,6,4,7,8][1,3,2,5,7,4,6,8][1,3,5,6,7,2,4,8][1,4,2,3,5,6,7,8][1,4,2,3,6,5,7,8][1,4,2,5,7,3,6,8][1,4,2,5,8,3,6,7][1,4,2,6,7,3,5,8][1,4,2,6,8,3,5,7][1,5,2,3,4,6,7,8][1,5,2,3,6,4,7,8][1,5,2,3,7,4,6,8][1,5,2,3,8,4,6,7][1,5,2,4,6,3,7,8][1,5,2,4,7,3,6,8][1,6,2,3,4,5,7,8][1,6,2,3,5,4,7,8][1,6,2,3,7,4,5,8][1,6,2,3,8,4,5,7][1,7,2,3,4,5,6,8][1,7,2,3,5,4,6,8][1,7,2,3,6,4,5,8][1,7,2,4,5,3,6,8][1,7,2,4,6,3,5,8]'),
	(8,'[1,2,3,4,5,6,7,8][1,2,4,3,5,6,7,8][1,2,5,3,4,6,7,8][1,3,5,2,4,6,7,8][1,3,6,2,4,5,7,8]'),
	(9,'[1,2,3,4,5,6,7,8][1,2,3,5,4,6,7,8][1,2,3,6,4,5,7,8][1,2,4,5,3,6,7,8][1,2,4,6,3,5,7,8][1,2,4,7,3,5,6,8][1,2,5,6,3,4,7,8][1,3,5,7,2,4,6,8]');

/*!40000 ALTER TABLE `Necklaces` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table OSType
# ------------------------------------------------------------

DROP TABLE IF EXISTS `OSType`;

CREATE TABLE `OSType` (
  `id` int(11) NOT NULL auto_increment,
  `description` varchar(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

LOCK TABLES `OSType` WRITE;
/*!40000 ALTER TABLE `OSType` DISABLE KEYS */;
INSERT INTO `OSType` (`id`,`description`)
VALUES
	(1,'linux'),
	(2,'darwin');

/*!40000 ALTER TABLE `OSType` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Requests
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Requests`;

CREATE TABLE `Requests` (
  `id` int(11) NOT NULL auto_increment,
  `totalnumpackets` int(11) default '0',
  `packetnumber` int(11) default '0',
  `schubertproblem_id` int(11) default NULL,
  `computationtype_id` tinyint(4) default NULL,
  `computationlength_id` tinyint(4) default '0',
  `algebraprogram` char(8) default 'singular',
  `necklace_id` int(11) default NULL,
  `number_necklaces` int(11) default NULL,
  `priority` tinyint(4) default '0',
  `initialrandseed` bigint(20) default '0',
  `packetsize` int(11) default NULL,
  `numcomputationsperfile` int(11) default NULL,
  `mhzsecondsperinstance` double default '100',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

LOCK TABLES `Requests` WRITE;
/*!40000 ALTER TABLE `Requests` DISABLE KEYS */;
INSERT INTO `Requests` (`id`,`totalnumpackets`,`packetnumber`,`schubertproblem_id`,`computationtype_id`,`computationlength_id`,`algebraprogram`,`necklace_id`,`number_necklaces`,`priority`,`initialrandseed`,`packetsize`,`numcomputationsperfile`,`mhzsecondsperinstance`)
VALUES
	(1,2,0,1,5,1,'singular',1,2,0,11112222,1,10,248.712195121951),
	(2,2,0,2,5,1,'singular',2,30,0,22223333,1,10,89128),
	(3,2,0,3,5,1,'singular',3,4,0,33334444,1,10,1966.95652173913),
	(4,2,0,4,5,1,'singular',4,3,0,44445555,1,10,919.989473684211),
	(5,2,0,5,5,1,'singular',5,3,0,55556666,1,10,906.8),
	(6,4,0,6,5,1,'singular',6,10,0,66667777,1,5,14512.1052631579),
	(7,20,0,7,5,1,'singular',7,38,0,77778888,1,1,296523.5),
	(8,4,0,8,5,1,'singular',8,5,0,88889999,1,5,11883.1818181818),
	(9,20,0,9,5,1,'singular',9,8,0,99990000,1,1,39424);

/*!40000 ALTER TABLE `Requests` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Results
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Results`;

CREATE TABLE `Results` (
  `id` int(11) NOT NULL auto_increment,
  `request_id` int(11) default NULL,
  `numinstances` int(11) default '0',
  `lastcomputeddate` text,
  `necklacetable` text,
  `schubertproblem_id` int(11) default NULL,
  `time_mhzseconds` bigint(40) default '0',
  `packetssubmitted` int(11) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table RunningInstance
# ------------------------------------------------------------

DROP TABLE IF EXISTS `RunningInstance`;

CREATE TABLE `RunningInstance` (
  `id` int(11) NOT NULL auto_increment,
  `request_id` int(11) default NULL,
  `startdate` int(11) default NULL,
  `computer_id` int(11) default NULL,
  `packetnumber` int(11) default NULL,
  `expected_time_to_finish` int(11) default NULL,
  `startdate_human` text,
  `expected_finish_human` text,
  `priority` tinyint(4) default NULL,
  `computationlength_id` tinyint(4) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table SchubertProblems
# ------------------------------------------------------------

DROP TABLE IF EXISTS `SchubertProblems`;

CREATE TABLE `SchubertProblems` (
  `id` int(11) NOT NULL auto_increment,
  `problemname` varchar(40) default NULL,
  `schubertconditions` text,
  `numsolutions` int(11) default NULL,
  `flagvariety_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

LOCK TABLES `SchubertProblems` WRITE;
/*!40000 ALTER TABLE `SchubertProblems` DISABLE KEYS */;
INSERT INTO `SchubertProblems` (`id`,`problemname`,`schubertconditions`,`numsolutions`,`flagvariety_id`)
VALUES
	(1,'Y^3Z^2','[1,3,2,4][1,3,2,4][1,3,2,4][1,2,4,3][1,2,4,3]',2,1),
	(2,'X21XY^2Z^3','[2,4,1,3,5][1,3,2,4,5][1,2,4,3,5][1,2,4,3,5][1,2,3,5,4][1,2,3,5,4][1,2,3,5,4]',3,2),
	(3,'A1325^2A214^2X11','[1,3,2,5,4][1,3,2,5,4][2,1,4,3,5][2,1,4,3,5][2,3,1,4,5]',4,3),
	(4,'W^2X^5','[2,1,3,4,5][2,1,3,4,5][1,3,2,4,5][1,3,2,4,5][1,3,2,4,5][1,3,2,4,5][1,3,2,4,5]',5,4),
	(5,'W2WY^5','[3,1,2,4,5][2,1,3,4,5][1,2,4,3,5][1,2,4,3,5][1,2,4,3,5][1,2,4,3,5][1,2,4,3,5]',5,5),
	(6,'X2X^3Y^3','[1,4,2,3,5][1,3,2,4,5][1,3,2,4,5][1,3,2,4,5][1,2,4,3,5][1,2,4,3,5][1,2,4,3,5]',6,6),
	(7,'W^2X^3Y11Y^2','[2,1,3,4,5][2,1,3,4,5][1,3,2,4,5][1,3,2,4,5][1,3,2,4,5][1,3,4,2,5][1,2,4,3,5][1,2,4,3,5]',7,7),
	(8,'X^3Y^5','[1,3,2,4,5][1,3,2,4,5][1,3,2,4,5][1,2,4,3,5][1,2,4,3,5][1,2,4,3,5][1,2,4,3,5][1,2,4,3,5]',10,6),
	(9,'X^4Y^4','[1,3,2,4,5][1,3,2,4,5][1,3,2,4,5][1,3,2,4,5][1,2,4,3,5][1,2,4,3,5][1,2,4,3,5][1,2,4,3,5]',12,6);

/*!40000 ALTER TABLE `SchubertProblems` ENABLE KEYS */;
UNLOCK TABLES;





/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
