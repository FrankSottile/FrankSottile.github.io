use 5.008006;
use strict;
use warnings;

# version: v1.0.2, 11/25/08: Implemented default options

# Functions defined here:
# initial_setup
# load_hash_file
# write_hash_file
# get_commandline_arguments
# default_options

# initial_setup
# Reads a configuration file (default: my_config.txt)
# and command line options to set up initial configuration.
#
# Inputs:
#   config_file - filename of configuration text file
#   argv - reference to array of command line arguments
# Output:
#   returns reference to hash array of config info
#
# Logic:
# 1. Read command line
# 2. Find out from command line if non-default config file.
#    If verbose + non-default config file, echo
#    (If config file doesn't exist, err & die)
# 3. Read config file.
# *** Precedence: commandline > config file > defaults ***

sub initial_setup {
  my ($config_file, $argv) = @_;
  my ($commandlineoptions,$fileoptions,$defaultoptions,$config);
  
  # Get default options (defined at bottom of this file)
  $defaultoptions = default_options();
  
  # Read command line arguments:
  $commandlineoptions = get_commandline_arguments($argv);
  
  # Read config file:
  if( $commandlineoptions->{'CONFIG_FILE'} ) {
    $config_file = $commandlineoptions->{'CONFIG_FILE'};
  }
  if( ! (-e $config_file) ) {
    print "Specified configuration file does not exist.\n";
    exit;
  }
  $fileoptions = load_hash_file($config_file);
  
  # Merge defaults, file options, & command line options
  # with precedence: command line > file > defaults
  # - copy defaults into $config
  # - copy file options into $config on top of defaults
  # - copy command line options on top of defaults+file
  for my $i (keys %{$defaultoptions}) {
    $config->{$i} = $defaultoptions->{$i};
  }
  for my $i (keys %{$fileoptions}) {
    $config->{$i} = $fileoptions->{$i};
  }
  for my $i (keys %{$commandlineoptions}) {
    $config->{$i} = $commandlineoptions->{$i};
  }
  
  # Now $config is all set up and ready to return
  
  # Last step: IF verbosity turned on, echo non-default options
  
  if( $config->{'verbosity'} >= 1 ) {
    # Echo information
    # Configuration file:
    if( $commandlineoptions->{'CONFIG_FILE'} ) {
      print "Using configuration file "
           ."$commandlineoptions->{'CONFIG_FILE'}.\n";
    }
    # Database:
    if( $commandlineoptions->{'database'} ) {
      print "Using database "
       ."$commandlineoptions->{'database'}.\n";
    }
    # Num iterations:
    if ( $commandlineoptions->{'numiterations'} ) {
      if ( $commandlineoptions->{'numiterations'} > 0 ) {
        print "You have selected to perform "
             ."$commandlineoptions->{'numiterations'} "
             ."iterations.\n";
      } else {
        print "You have selected to iterate until all "
             ."problems in the database are done.\n";
      }
    }
    # Text input:
    if ( $commandlineoptions->{'TEXTPROBLEMINPUT'} ) {
      print "Reading problem input from text file "
           ."$commandlineoptions->{'TEXTPROBLEMINPUT'}.\n";
    }
    # Computation length:
    if ( $commandlineoptions->{'MY_COMPUTATION_LENGTH'} ) {
      print "Computing problems up to computation length "
           ."$commandlineoptions->{'MY_COMPUTATION_LENGTH'}.\n";
    }
  }
  
  return $config;
}

# load_hash_file     Loads the configuration hash file
#
# input: filename
#   file contains the information of a hashtable
#   each line has the format:
# key value
#   (space-separated; the value can contain **any text** including spaces)
#
#   if a key is repeated, the LAST value is kept
#
#   skip lines that start with '#'
#   *silently* skip unparseable lines: can't get a key and value
#   (should maybe complain about such lines?)
#
# output: reference to a hashtable with those keys & values
#
sub load_hash_file {
    my ($filename) = @_;
    open(INFILE,"$filename") or die;
    my @inf = <INFILE>;
    close INFILE;
    
    my $filehashref;
    
    foreach(@inf) {
        chomp($_);
        if( substr($_,0,1) ne "#" ) {
            if( my ($key,$val) = split(/ /,$_,2) ) {
                $key =~ s/^\s+|\s+$//g; # trim leading and trailing whitespace
                $val =~ s/^\s+|\s+$//g; # trim leading and trailing whitespace
               $filehashref->{$key} = $val; # if $key occurs twice, last value is kept
            }
        }
    }
    
    return $filehashref;
}


# write_hash_file
#
# input: reference to a hashtable
#
# output: a string with one key-value pair per line
#
sub write_hash_file {
    my $outhashref = $_[0];
    my $outstr = "";
    
    while ( my ($key, $value) = each(%$outhashref) ) {
        $outstr .= "$key $value\n";
    }
    
    return $outstr;
}


# get_commandline_arguments
#
# input: reference to array $argv
#
# output: reference to hash $config
#

sub get_commandline_arguments {
    my ($argv) = @_;
    my $newconfig;
    
    ############################################################
    # here we retrieve command line parameters
    #
    # -v --> "verbose" - do not suppress as much console output as possible
    # -V --> "highly verbose" - print more detailed information
    #
    # -cf ARG   -->   Use configuration file ARG 
    #
    # -n ARG   -->   NUMBER of PACKET COMPUTATIONS
    #				 ARG = 0 signifies compute until dbase empty 		
    #				 EXAMPLE: monotone.pl -n10
    #				 DEFAULT: 1 
    #
    # -dd	  -->   don't delete temporary files  
    #
    # -t ARG  --> use ARG as problem input (find format at ???) instead of database
    #
    # -cl ARG --> MY_COMPUTATION_LENGTH = ARG (default=1)
    #
    ############################################################

    # get all the commandline arguments into a string:
    my $parameters = "";
    foreach my $argnum (0 .. $#{$argv}) {
      $parameters .= $argv->[$argnum];
    }
#    $newconfig->{'TEXTPROBLEMINPUT'} = "";  # default value = no input problem file

     # 1 = print basic info on startup
     # 2 = print detailed info on each packet and a tick on each subpacket
    
    # match the arguments:
    if ( $parameters =~ m/-v/ ) {
      $newconfig->{'verbosity'} = 1;
    }
    if ( $parameters =~ m/-V/ ) {
      $newconfig->{'verbosity'} = 2;
    }
    if ( $parameters =~ m/-cf\s*?([_.a-zA-Z1-9]*)/ ) {
      $newconfig->{'CONFIG_FILE'} = $1;
#      if( $newconfig->{'verbosity'} >= 1 ) {
#        print "Using configuration file ".$newconfig->{'CONFIG_FILE'}."\n";
#      }
#      $newconfig = load_hash_file($newconfig->{'CONFIG_FILE'},$newconfig);
    }
    if ( $parameters =~ m/-n\s*?(\d*)/ ) {
      $newconfig->{'numiterations'} = $1; 
    }
    if ( $parameters =~ m/-dd/ ) {
      $newconfig->{'KEEPTEMPFILES'} = 1;
    }
    if ( $parameters =~ m/-t\s*?([.a-zA-Z1-9]*)/ ) {
      $newconfig->{'TEXTPROBLEMINPUT'} = $1;
    }
#    if ( $parameters =~ m/-dt/ ) {
#      $newconfig->{'TRAPBADFILES'} = 0;
#    }
    if ( $parameters =~ m/-db\s*?([a-zA-Z1-9]*)/ ) {
      $newconfig->{'database'} = $1;
#      if( $newconfig->{'verbosity'} >= 1 ) {
#        print "Using database ".$1."\n";
#      }
    }
#      if( $newconfig->{'verbosity'} >= 1 ) {
#      if ( $newconfig->{'numiterations'} > 0 ) {
#        print "You have selected to perform $newconfig->{'numiterations'} iterations\n";
#      } else {
#        print "You have selected to iterate until all problems in the dbase are done\n";
#      }
#    }
    if ( $parameters =~ m/-cl(\d*)/ ) {
      $newconfig->{'MY_COMPUTATION_LENGTH'} = $1;
    }
    
    return $newconfig;
}

# default_options
# Input: none
# Output: return a reference to hash array
#   containing default options for various things in the program.
sub default_options {
  my $defaults = {
    'MY_COMPUTATION_LENGTH' => 1,
    'verbosity'             => 0,
    'numiterations'         => 1,
    'FLUSH_WORKING'         => 0,
    'KEEPTEMPFILES'         => 0,
    'algebraprogram'        => "singular",
    'rootfinder'            => "maple",
    'SINGULAR_path'         => "Singular",
    'MACAULAY_path'         => "M2",
    'MAPLE_path'            => "maple",
    'SAGE_path'             => "sage",
    'noflylist'             => "",
    'stallwindow_days'      => 1,
    'db_port'               => "3306",
    'email_to'              => "",
  };
  
  return $defaults;
}


return 1;
__END__
