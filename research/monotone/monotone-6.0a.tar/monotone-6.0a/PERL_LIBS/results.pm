use 5.008006;
use strict;
use warnings;

# v1.0.2c - 12/11/08 - zach: parse_results checks proper format
# of Maple output file, silently ignores & discards "Error, cannot raise...",
# and also ignores blank lines. Other than that, will DIE on unreadable line,
# i.e., anything other than a single integer.
# v1.0.4 - 3/24/09 - zach: start keeping track of which packets have been submitted

#############################################################
#
# Functions to deal with results.
#   Results (number of real roots) are stored in $files->{'results'}
#   format: one integer per line
#           failures are lines that start with "F"
#           We have decided to not store failures in the database
#
#######################################################
# At the end of this whole process
#
# the file $mapleoutput has the actual #s of solutions for all the $computationsize 
# problems computed as a sequence of [number of solutions] 
# e.g.  4 4 4 2 2 -1 4  
# (-1 here denotes that an eliminant couldn't be found)
#
# the array @necklacenumberlist has the list of corresponding neckalces' numbers 
#
# We need to recover these integers and add them to the real solutions table 
# that is in the database for this problem
#
#          0 1 2 ...   (number of necklace)
#       \--------------------- 
#     0 |
#     1 |    (#instances with this num real solns and this necklace)
#     ..|
# (num real solutions)
#
#  This will be stored first as a transposed table, and wher the rows are sorted
#
#
#  %solutiontable is a hashtable with 2 keys and one value:
#  $solutiontable{r}{c} = the number of instances with real solutions r and necklace number c	
#######################################################

# Input: 
#   $resultfile: name of file containing Maple/Sage results
#               and failures, as described above
#   @necklacenumbers: array containing list of necklaces' numbers
#
# Output: pair (\%solutiontable,\@failures) where:
#   \%resulttable = reference to hashtable of solutions
#           $resulttable{a}{b} = number of times we had
#                     <realroots=a,necklacenumber=b>
#   \@failures = ref. to array containing failures.
#        Each failure is a hashref.
sub parse_results {
  my ($resultfile,@necklacenumbers) = @_;
  my (@results,%resulttable,@failures);
  
  open(RESULTSFILE,"$resultfile") or return 0;
  @results = <RESULTSFILE>;
  close RESULTSFILE;
    
  foreach my $l (@results) {
    chomp($l);
    # is $l a failure?
    if( line_is_failure($l) ) {
      my $failure = failure_line_to_hashref($l);
      push(@failures,$failure);
    } elsif ( $l eq "Error, cannot raise the datalimit above the hard limit" ) {
      # $l is an annoying, ignorable error message, so we ignore it
      ;
    } elsif ( $l =~ /^\s*\d+\s*$/) {
      # exactly one nonnegative integer with >= 1 digit (nonempty);
      # ignore leading/trailing whitespace
      # $l is an integer: number of real roots
      # pair it up with necklacenumber & add to %resulttable
      my $cn = shift(@necklacenumbers);
      if ( !$resulttable{$l}{$cn} ) {  # this num real solns not found before
        $resulttable{$l}{$cn} = 1;
      } else {
        $resulttable{$l}{$cn}++;
      }
    } elsif ( $l =~ /^\s*$/ ) {
      # blank line, or only whitespace... ignore, i guess
      ;
    } else {
      # $l is some unexpected thing!!
      # what is it?!?
      # is it a previously unknown Maple error?
      print STDERR "Unreadable Maple output:\n$l\n";
      die;
    }
  }
  return (\%resulttable,\@failures);
}


# frsc_post_results
# Arguments:
#  dbhr: hashref with all the important information about the database
#  compid: scalar. The computer_id for this computer (discovered during checkin)
#  prob: hashref with all the important information about the problem and packet we just worked on
#  resulttable: hashref where $resulttable{$realroots}{$necklacenumber}=number of times observed
#  failures: array with list of failure information
#  mytime: scalar in MHz-seconds of how many CPU cycles were spent on this packet

# 8/28/08: Before posting results, check if RunningInstance record
# exists for this problem and packet with the same computer id.
# If it does, continute as before. If not, then someone else has
# taken over this RunningInstance --- discard results (don't double-post).
#
# Also, check how many "actual instances" have been computed.
# If it does not match the expected number
# (number_necklaces*numcomputationsperfile*packetsize)
# then fail, discarding results.
#
# 9/17/08: Check RunningInstance record by runninginstance_id,
# AND check computer_id + request_id + packetnumber match
# what they are supposed to (paranoia-check)
#
# 3/24/09: Results table gets a new column to keep track of *which* packets
# have been submitted (in addition to the *number* of packets submitted).
# Amend post_results() to update this field.

sub post_results {
  my ($dbhr,$compid,$cpufreq,$prob,
      $resulttable,$failures,$actualtime) = @_ ;
  my $thedatetime = localtime();
    
  # connect to database
  my $dbh = DBI->connect($dbhr->{'datasource'},
                         $dbhr->{'db_user_name'},
                         $dbhr->{'db_password'},
                         {RaiseError => 1,
                          AutoCommit => 0});
    
  # 0.9 Check for RunningInstance record
  my $sth = $dbh->prepare(qq{SELECT computer_id,request_id,packetnumber FROM RunningInstance
                             WHERE id = $prob->{'runninginstance_id'} });
  $sth->execute();
    
  my ($run_comp_id,$run_request_id,$run_packetnumber);
  # the data in the RunningInstance record
  # check if it matches our data
  if ( ( ($run_comp_id,$run_request_id,$run_packetnumber) = $sth->fetchrow_array())
        && ($run_comp_id==$compid)
        && ($run_request_id==$prob->{'request_id'})
        && ($run_packetnumber==$prob->{'packetnumber'}) ) {
    # Okay, we still "own" this running instance
    ;
  } else {
    # Someone else took over the RunningInstance.
    # Discard results and Failures.
    # Don't record time spent computing.
    $sth->finish();
    $dbh->disconnect();
    return 0;
  }
    
  # 0.91 Compare number of instances actually computed
  #      to expected number.
  my $actualinstances = count_instances_in_necklacetable($resulttable);
  my $expectedinstances = $prob->{'number_necklaces'}
                         *$prob->{'numcomputationsperfile'}
                         *$prob->{'packetsize'} ;
  if ( $actualinstances != $expectedinstances ) {
    # Something has gone wrong
    # post a Failure message;
    my $failuretext = "Number of instances actually computed "
            ."does not match expected number of instances. "
            ."Request id: $prob->{'request_id'}, "
            ."packet number: $prob->{'packetnumber'}, "
            ."computed: $actualinstances instances, "
            ."expected: $expectedinstances instances.";
    print $failuretext."\n";
    # leave RunningInstance in place (so packet will be redone)
    $sth->finish();
    $dbh->commit();
    $dbh->disconnect();
    return 0;
  }
  
#  #0.92 Read packetssubmittedlist, see if this packet has already been submitted
#  $sth = $dbh->prepare(qq{SELECT packetssubmittedlist FROM Results
#                          WHERE request_id = $prob->{'request_id'};});
#  $sth->execute();
#  my ($oldpacketssubmittedlist) = $sth->fetchrow_array();
#  my $oldpacketssubmitted_intspan = new Set::IntSpan $oldpacketssubmittedlist;
#  if ( member $oldpacketssubmitted_intspan $prob->{'packetnumber'} ) {
#   # it has already been submitted!!
#   # remove RunningInstance record:
#    $dbh->do(qq{DELETE FROM RunningInstance
#        WHERE id = $prob->{'runninginstance_id'};});
#    $sth->finish();
#    $dbh->commit();
#    $dbh->disconnect();
#    return 0;
#  }

        
    
  # 1. Get old necklacestable.
  #    Merge with new resultpairs. Post all that.
  #    Increment time.
  # now retrieve table from the problem table in the dbase
  $sth = $dbh->prepare(qq{SELECT id, necklacetable
        FROM Results
        WHERE request_id = $prob->{'request_id'}
        FOR UPDATE;});
  $sth->execute();
	
  my ($result_id, $oldnecklacetable);
  if ( ($result_id, $oldnecklacetable) = $sth->fetchrow_array() ) {
  } else {
    # if there isn't a results table already in place then add one
    $sth = $dbh->prepare(qq{INSERT INTO Results
            (request_id, schubertproblem_id,
             numinstances, time_mhzseconds, packetssubmitted)
             VALUES ($prob->{'request_id'},
                    $prob->{'schubertproblem_id'},
                    '0', '0', '0') });
    $sth->execute();
    $result_id = $dbh->{'mysql_insertid'};
    $oldnecklacetable = ""; 
  }
    
    
  # merge old + new tables
  my $newtable;
  if ( (!$oldnecklacetable) || (length($oldnecklacetable) < 3) ) {   # if table empty simply stick new table in dbase
    $newtable = solutions_table_to_string($resulttable);
  } else {  	# need to merge the two tables
    my %oldhashtable = load_dbase_solutions_table($oldnecklacetable);
    my %mergedtable = merge_two_solutions_table(\%oldhashtable,$resulttable);
    $newtable = solutions_table_to_string(\%mergedtable);
  }
  my $newinstances = count_instances_in_necklacetable($resulttable);
  
  # Try this 5 times
  my $posted_results_yet = 0;
  my $tries_left = 5;
  while ( $posted_results_yet==0 && $tries_left > 0 ) {
    $sth = $dbh->prepare(qq{UPDATE Results
        SET lastcomputeddate='$thedatetime',
        necklacetable='$newtable',
        time_mhzseconds=time_mhzseconds+'$cpufreq'*'$actualtime',
        numinstances=numinstances+'$newinstances',
        packetssubmitted=packetssubmitted+1
        WHERE id ='$result_id' ;});
    my $returnvalue = $sth->execute();
    $sth->finish();
    if( $returnvalue ) {
      # it succeeded, yay
      $dbh->commit();
      $posted_results_yet = 1;
    } else {
      $tries_left -= 1;
      sleep 30;
    }
  }
  if ( $posted_results_yet == 0 ) {
    # tried 5 times, still couldn't post results?!?
    die "Unable to post results. Computer $compid, request $prob->{'request_id'}, ".
        "packet $prob->{'packetnumber'}\n";
  }

  # 2. Add time to computer record,
  #    provided there is a meaningful time ($cpufreq != 0)
  my $cputime = $cpufreq*$actualtime;
  $dbh->do(qq{UPDATE Computer
        SET time_mhzseconds = time_mhzseconds+'$cputime'
        WHERE id = '$compid';});
  $dbh->commit();

  # 3. Remove RunningInstance.
  # Update dbase to remove this running instance
    #######################################################
  $dbh->do(qq{DELETE FROM RunningInstance
        WHERE id = $prob->{'runninginstance_id'};});
  $dbh->commit();
  $dbh->disconnect();
}


# frsc_remove_temp_files:
# Remove all the temporary files listed in the input hashreference.
# (Note that if the hashreference mentions a file that doesn't
# actually exist, then calling unlink on it simply doesn't do
# anything, no error or anything, so it is safe.)
sub frsc_remove_temp_files {
  my $files = $_[0];
  foreach my $i (keys %{$files}) {
    unlink($files->{"$i"});
  }
}

return 1;
__END__
