use 5.008006;
use strict;
use warnings;


sub line_is_failure {
  my $line = shift;
  # if first character is 'F', it's a failure
  if (substr($line,0,1) eq "F") {
    return 1;
  } else {
    return 0;
  }
}

###############################################################
#
# How failure information is written into a line by Singular/Maple
#
# (6/16/08) We're not entirely sure what information
# about failures has to be captured and recorded.
# So I am going to make it a fairly flexible structure.
#
# The line will basically record a hashtable:
# F key1~~value1!!key2~~value2!! ...
#
# If a key shows up more than once, just keep the last value? (or concatenate?)
#
# not sure which separators to use, we'll try !! and ~~ for now...
# (it appears that Perl and Singular BOTH can handle !! and ~~ without escaping...
#  as long as they don't appear in our data, we should be okay)
#

sub failure_line_to_hashref {
  my $line = $_[0];
  # delete the "F " at the beginning:
  $line = substr($line,2);
  
  my %hash;
  my @keyvals = split(/!!/,$line);
    
  foreach my $i (@keyvals) {
    my ($key,$val) = split(/~~/,$i);
    $hash{$key} = $val;
  }
    
  return \%hash;
}


# input: reference to hash
# output: string containing: key1~~val1!!key2~~val2!!...
sub hashref_to_failure_line {
  my $hashref = $_[0];
  my $string = '';
    
  for my $i (keys %{$hashref}) {
    if ( $hashref->{$i} ) {
      $string .= "$i~~$hashref->{$i}!!";
    }
  }
  # delete last !!
  chop($string);chop($string);
        
  return $string;
}


#####################################################
#
# Failure hash to database INSERT
#
# Input: hashref with information from a failure
# Output: string with database INSERT to put that information
#   into database Failure table
#
# INSERT into Failure (key1,key2,key3,...) VALUES (value1,value2,value3,...)
#
# To do: be more intelligent/careful about
# hash keys versus database table column names?

sub failure_hash_to_database_insert {
  my $failure = shift;
    
  my $columns = "";
  my $values = "";
    
  # make list of columns and list of values
  foreach my $i (keys %{$failure}) {
    if ( $failure->{$i} ) {
      $columns .= "$i,";
      $values  .= "\'$failure->{$i}\',";
    }
  }
    
  # remove last commas
  chop($columns);
  chop($values);
    
  # put it all together
  my $dbinsert = "INSERT into Failure ($columns) VALUES ($values)";
    
  return $dbinsert;
}


# take information of a failure and make it a line that can be printed by Singular
#
# for right now: kind of dumb, just record everything in sight
#
# Todo: be smarter about quoting and escaping for Singular?
#       figure out a way to get the instancenumber in there?!?
sub failure_to_line {
  my ($prob,$randpointsptr,$permutationptr) = @_;
  use Sys::Hostname; my $host = hostname;
    
  my $string = "F ";
    
  foreach my $i (keys %{$prob}) {
    if ( $prob->{$i} ) {
      $string .= sprintf("%s~~%s!!", $i, $prob->{$i});
    }
  }
  $string .= sprintf("%s~~%s!!", 'randpoints', join(',', @{$randpointsptr}));
  $string .= sprintf("%s~~[%s]!!", 'permutation', join(',', @{$permutationptr}));
  $string .= sprintf("%s~~%s", 'hostname', $host);
   
  return $string;
}

# post_failures from the Singular computation
# post a list of failures to the database
# Input:
#   $dbh - handle to database connection
#   $failures - reference to array of references to hashes
#     (not as bad as it sounds!) $failures->[$i] is a hashref
#     containing all the information of a failure,
#     and feeding it through hashref_to_failure_line
#     makes it into a string that we put into the database
# No return.
sub post_failures {
  my ($dbh,$failures,$thedatetime,$compid) = @_;
  for( my $i=0 ; $i <= $#{$failures} ; ++$i ) {
    my $failuretext = hashref_to_failure_line($failures->[$i]);
    my $quotedfailuretext = $dbh->quote($failuretext);
        
    $dbh->do(qq{INSERT INTO Failure
            (request_id, date, computer_id, packetnumber,
             computername, failuretext)
            VALUES ('$failures->[$i]->{'request_id'}',
                    '$thedatetime',
                    '$compid',
                    '$failures->[$i]->{'packetnumber'}',
                    '$failures->[$i]->{'hostname'}',
                    $quotedfailuretext)
                     });
  }
  $dbh->commit();
}


# failure_message
# Connect to database and put a message in the Failure table
# Input:
#   $dbhr - hashref with database information
#   $config - hashref with information, incl computer, etc
#   $message - a string
#sub failure_message {
#  my ($dbhr,$config,$message) = @_;
#  
#  # standard code to connect to database
#  my $dbh = DBI->connect($dbhr->{'datasource'},
#                         $dbhr->{'db_user_name'},
#                         $dbhr->{'db_password'},
#                         {RaiseError => 1});
#  
#  my $quotedmessage = $dbh->quote($message);
#  my $datetime = localtime; # date & time as a human-readable string
#  
#  $dbh->do(qq{INSERT INTO Failure
#          (date,
#           computer_id,
#           computername,
#           failuretext)
#          VALUES
#          ('$datetime',
#           '$config->{'compid'}',
#           '$config->{'hostname'}',
#           $quotedmessage)
#          });
#  $dbh->disconnect();
#}


return 1;
__END__
