#!/usr/bin/perl -w
##############################################################
# Perl code to choose problems from the dbase not being worked on
# and compute a number of random iterations
#  Created by Christopher Hillar with updates by Frank Sottile and Zach Teitler
#    
# Began: 3 September 2007
#
# v1.0.6 8/19/09 - see "Versions.txt"
#
################################################################
# Command line arguments
#
#
# -cl ARG --> MY_COMPUTATION_LENGTH = ARG (default=1)
#
# -n ARG   -->   NUMBER of PACKET COMPUTATIONS
#				 ARG = 0 signifies compute until dbase empty 		
#				 EXAMPLE: perl monotone.pl -n10
#				 DEFAULT: 1 
#
# -dd	  -->   don't delete temporary files  
#
# -t ARG  --> use ARG as problem input (find format at ???) instead of database
#
# -v --> "verbose" - do not suppress as much console output as possible
# -V --> "highly verbose" - print more detailed information
#
###############################################################

use PERL_LIBS::monotone;

my $config;
$config = initial_setup("my_config.txt",\@ARGV);

# Organize configuration-file information into hashes
my $dbhr = {
    'db_server'    => $config->{'db_server'},
    'db_user_name' => $config->{'db_user_name'},
    'db_password'  => $config->{'db_password'},
    'db_port'      => $config->{'db_port'},
    'database'     => $config->{'database'},
    'datasource'   => "DBI:mysql:"
                   ."database=$config->{'database'};"
                   ."hostname=$config->{'db_server'};"
                   ."port=$config->{'db_port'}",
};

my $options = {
    'FLUSH_WORKING' => $config->{'FLUSH_WORKING'},
    'KEEPTEMPFILES' => $config->{'KEEPTEMPFILES'},
    'TEXTPROBLEMINPUT' => $config->{'TEXTPROBLEMINPUT'},
    'verbosity' => $config->{'verbosity'},
    'noflylist' => $config->{'noflylist'},
    'rootfinder' => $config->{'rootfinder'},
};

my $paths = {
    'singular' => $config->{'SINGULAR_path'},
    'macaulay' => $config->{'MACAULAY_path'},
    'maple'    => $config->{'MAPLE_path'},
    'sage'     => $config->{'SAGE_path'},
};

#####################################################################################
# load this computer's information
my ($compid,$cpufreq,$host,$num_running_instances);
eval {
  my $checkin_tries_left=5;
  while ( $checkin_tries_left > 0 ){
    ($compid,$cpufreq,$host,$num_running_instances) = frsc_checkin( $dbhr );
    if ( !$compid ) {
      sleep 30;
      $checkin_tries_left -= 1;
    } else {
      $checkin_tries_left = 0;
    }
  }
};
# did it manage to check in ?
if ( !$compid ) {
  print "Failed to check in. Please check database server and connection.\n";
  sleep 3600;
  die;
}

#####################################################################################
############  "No-fly list"  #################
##
##   The purpose of this hack is that several of the blocker computers are 
## incapable of computation, so we wish to avoid them.
##
##   Added by Abraham Oct 16 2008
##   Generalized by Zach 12/2/08
## Reads "noflylist" from my_config, a list of bad computers
## separated by spaces, e.g.:
## noflylist bloc125-00 bloc127-04
###############################
if ($options->{'noflylist'} =~ /$host/) {
    sleep 7200;
    if( $options->{'verbosity'} >= 1 ) {
      die "Computation canceled at $host.";
    } else {
      exit;
    }
}

# are there already way too many running instances for this computer?
if ( $num_running_instances > 50 ) {
  sleep 3600;
  die "Too many running instances ($num_running_instances) on host $host";
}

############  Check access to temporary directory  #################
##
##   Added by Zach March 23 2009
###############################
if ( !(-e "frsc-tmp" && -d "frsc-tmp") ){
    sleep 7200;
    # Here optionally email a notification of the problem
    # if( ! (-e "error_notification_$host") ) {
    #   <send email to sottile@math.tamu.edu or someone ...>
    #   <create file "error_notification_$host">
    # }
    exit;
}
if ( !(-e "frsc-tmp/$host") ) {
    mkdir "frsc-tmp/$host";
}
if ( !(-e "frsc-tmp/$host" && -d "frsc-tmp/$host") ) {
    sleep 7200;
    exit;
}
if( $options->{'verbosity'} >= 1 ) {
  print "Computer: $host.\n";
}

############################################################
#
#   Die if the code cannot read CPU speed
#
if ( ($cpufreq == 0) or (!($cpufreq))) {
    die "Please enter CPU speed of $host into database  $config->{'database'} and try again.";
}
$config->{'compid'} = $compid;
$config->{'cpufreq'} = $cpufreq;
$config->{'hostname'} = $host;

########################################################################			
# load the master list of points (as rational numbers with , delimeters) 
# found in  row "Master" of table Points in database.   
# These are expected to be sorted in numeric order.
#######################################################################

@master_points=@{get_points( )};

#############################################################
# Main Code Block
#
# uses iteration function defined below
#
if ( $config->{'numiterations'} > 0 ) {  # perform the number of iterations in the command line
  for ( my $i = 0; $i < $config->{'numiterations'}; $i++ ) {
    if ( -e "stop" ) { # if there exists file named simply "stop"
      exit;
    }
      $prob = &get_a_problem_to_work_on($dbhr,$compid,$config);
      one_iteration($prob,$paths,$options,$dbhr,$compid,\@master_points);
   }
} else {  # if user wants to empty entire database
  my $keepgoing = 1;
  # until can't find problem, or there exists file named simply "stop":
  while ( $keepgoing && ! -e "stop" ) {
    $prob = &get_a_problem_to_work_on($dbhr,$compid,$config);
    $keepgoing = &one_iteration($prob,$paths,$options,$dbhr,$compid,\@master_points);
  }
}
##############################################################
#
#   $prob is a hash that contains all date needed to create the Schubert problem
#
# $prob = {
    #    'packetnumber'      => $packetnumber,
    #    'priority' 		 => $priority,
    #    'computationlength_id' => $computationlength_id,
    #    'request_id'       => $request_id,
    #    'totalnumpackets'  => $totalnumpackets,
    #    'computationtypeid' => $computationtype_id,
    #    'algebraprogram'   => $algebraprogram, 
    #    'necklace_id'      => $necklace_id,
    #    'number_necklaces' => $number_necklaces, 
    #    'initseed'         => $initseed,
    #    'packetsize'       => $packetsize, 
    #    'numcomputationsperfile'  => $numcomputationsperfile,
    #    'schubertproblem_id' => $schubertproblem_id,
    #    'problemname'       => $problemname,
    #    'schubertconditions' => $schubertconditions,
    #    'numsolutions'      => $numsolutions,
    #    'mhzsecondsperinstance' => $mhzsecondsperinstance,
    #    'flagvariety'       => $flagvariety,
    #    'dimension'         => $dimension,
    #    'necklaces'         => $necklaces, 
# };      


################################################################
# MAIN PROCEDURE
#
################################################################
# int one_iteration()
#
# This is the main heart of the code
# This function looks for a free problem in the database
# and computes packet size number of calculations
# returns 0 if there are no more problems in the database left
#
# it assumes the variable declarations from top of this file
#
sub one_iteration {
  my ($prob,$paths,$options,$dbhr,$compid,$masterpoints) = @_;

  use Benchmark;		
  $t0 = new Benchmark;
    
  if( $prob ) { # found a problem to work on
    
    # Informational message:
    if( $options->{'verbosity'} >= 2 ) {
      print "Problem information:\n".
            "  Problem name : $prob->{'problemname'} = $prob->{'numsolutions'} ".
            "on Fl($prob->{'flagvariety'};$prob->{'dimension'})\n".
            "  Request id   : $prob->{'request_id'}\n".
            "  Packet number: $prob->{'packetnumber'}/$prob->{'totalnumpackets'}\n".
            "    $prob->{'packetsize'} subpackets @ $prob->{'numcomputationsperfile'} computations/file\n".
            "  Computation length: $prob->{'computationlength_id'}\n".
            "  MHz-seconds per instance: $prob->{'mhzsecondsperinstance'}\n".
            "  Expected time to finish: $prob->{'expectedfinishtime'}\n"
    }
    
    frsc_srand($prob->{'initseed'});

    # now compute $packetsize number of Singular/Macaulay computations
    # each singular computation consists of a long file with 
    # $numcomputationsperfile computations per singular file
		
    # Store results & failures for the whole packet:
    my %packetresultstable;
    my @packetfailures;
		
    for ( my $i = 0; $i < $prob->{'packetsize'}; $i++ ) {
    	  
      # Store results & failures for just this file ("subpacket")
      my %subpacketresultstable;
      my @subpacketfailures;
    	  
      $prob->{'subpacket'} = $i;
      my $files = &set_up_filenames($prob);
      # Write algebra input file
      # finds crossing numbers along the way. Return them in an array

      # For computation type 4, we do not compute crossing numbers.  We just assign
      # the crossing nunber to the index of the corresponding necklace
      #
      my @crossnumbers;
      eval {
        @crossnumbers = &write_algebra_file($options,$prob,$files,$masterpoints);
        if ( $#crossnumbers == 0  ) {
          die "Writing Singular/Macaulay input file failed.";
        }
      };
      if( $@ ) { # $@ contains any error/exception from inside eval
        die;
      }
      
      # run algebra input file
      eval {
        my $status;
        if ( $prob->{'algebraprogram'} eq 'singular' ) {
          $status = system("nice -n20 $paths->{'singular'} -q < $files->{'singularinput'}");
        } elsif ( $prob->{'algebraprogram'} eq 'macaulay' ) {
#          $status = system("nice -n20 $paths->{'macaulay'} --stop --silent --no-debug --no-prompts -q $files->{'macaulayinput'}");
          $status = system("nice -n20 $paths->{'macaulay'} --script $files->{'macaulayinput'}");
        }
        if ( $status != 0 ) {
          # Singular/Macaulay run failed.
          # Put an error message and stop the computation.

          die "Singular/Macaulay run failed.";
        }
      };
      if( $@ ) { # $@ contains any error/exception from inside eval
        die;
      }
        
      #########################################################################
      # Find number of real roots.
      # Use maple or sage according to $config->{'rootfinder'}
          
      if ( $config->{'rootfinder'} eq 'maple' ) {
        # Using Maple: creates new maple file        
        eval {
          if ( ! write_maple_input_file($prob,$files) ) {
            die "Writing Maple input file failed.";
          }
        };
        if( $@ ) { # $@ contains any error/exception from inside eval
          die;
        }
        # run maple file :
        eval {
          $status = system("nice -n20 $paths->{'maple'} -q < $files->{'mapleinput'} > $files->{'results'}");
          if( $status != 0 ) {

            # See comments about the similar structure with the Singular computation. 

            die "Maple run failed.";
          }
        };
        if( $@ ) { # $@ contains any error/exception from inside eval
           die;
        }
      } elsif( $config->{'rootfinder'} eq 'sage' ) {
         # Using Sage:
         # creates new sage file        
         eval {
           if ( ! write_sage_input_file($prob,$files) ) {
             die "Writing Sage input file failed.";
           }
         };
         if( $@ ) { # $@ contains any error/exception from inside eval
           die;
         }
         # run sage file :
         eval {
           $status = system("nice -n20 $paths->{'sage'} $files->{'sageinput'} > $files->{'results'}");
           if( $status != 0 ) {

             # See comments about the similar structure with the Singular computation. 

             die "Sage run failed.";
           }
         };
         if( $@ ) { # $@ contains any error/exception from inside eval
            die;
         }
      } elsif( $config->{'rootfinder'} eq 'sarag' ) {
         # Using SARAG:
         # accessed via Sage's Maxima interface
         # creates new input file at $files->{'sageinput'} location
         eval {
           if ( ! write_sarag_input_file($prob,$files) ) {
             die "Writing SARAG input file failed.";
           }
         };
         if( $@ ) { # $@ contains any error/exception from inside eval
           die;
         }
         # run SARAG file using Sage :
         eval {
           $status = system("nice -n20 $paths->{'sage'} $files->{'sageinput'} > $files->{'results'}");
           if( $status != 0 ) {

             # See comments about the similar structure with the Singular computation. 

             die "Sage/SARAG run failed.";
           }
         };
         if( $@ ) { # $@ contains any error/exception from inside eval
            die;
         }
      } else {
        # what rootfinder to use??
        # do nothing...
        die "Please specify maple, sage, or sarag to find real roots.";
      }
              
      # collect the results from the computation
      my ($a,$b) = parse_results($files->{'results'},@crossnumbers);          
      if( $a == 0 ) { # problem reading file
        die "Maple output file could not be read.";
      }
      %subpacketresultstable = %{$a};
      @subpacketfailures = @{$b};
            
      # Append/merge subpacket stuff to packet results & failures
      # Merge $subpacketresultstable into $packetresultstable:
      %packetresultstable = merge_two_solutions_table(\%packetresultstable,\%subpacketresultstable);
      # Append $subpacketfailures to $packetfailures:
      push(@packetfailures,@subpacketfailures);
          
      #######################################################
      #
      # Erase temporary files unless the -dd option is used
      #
      #######################################################
          
      if( !$options->{'KEEPTEMPFILES'} ) {
          frsc_remove_temp_files($files) ;
     }
          
     # end of this subpacket
     
    if( $options->{'verbosity'} >= 2 ) {
        print ".";
     }
     
     # next brace goes around to the next subpacket
  }
        
  # Finished packet.
  # Gather timing information and post results.

  $t1 = new Benchmark;   # perl time benchmarking
  $td = timediff($t1, $t0);
  my $timestr = timestr($td);
  $timestr =~ m/([.0-9]+) CPU/g;
  my $actualtime = $1; # time in honest seconds
  
  my $poststatus = post_results($dbhr,$compid,$cpufreq,$prob,\%packetresultstable,\@packetfailures,$actualtime);

  if( $options->{'verbosity'} >= 2 ) {
    if( $poststatus ) {
      print "\n(".localtime().") Completed packet and posted results.\n"
        ."  Time spent: $actualtime s\n"
        ."  Expected to spend: ".$prob->{'timetocomplete'}." s\n\n";
    } else {
      print "\n(".localtime().") Completed packet, could not post results.\n\n";
    }
  }
  
  return 1;   	       
  } else {		# no problems left in the database
    if( $options->{'verbosity'} >= 1 ) {
        print "Requests are all done - or - couldn't open the specified file\n";
    }
    return 0;  
  }
}
