use 5.008006;
use strict;
use warnings;

use DBI;

###########################################################################
# The following files contain Perl procedures written mostly by 
# Christopher Hillar  in 2007-2008
# 
# They have been edited by Zachariah Teitler and Frank Sottile in 2008
#
##########################################################################

use PERL_LIBS::configuration;
use PERL_LIBS::get_problem;
use PERL_LIBS::computationtype;
use PERL_LIBS::misc;
use PERL_LIBS::checkin;

use PERL_LIBS::failures;
use PERL_LIBS::results;
use PERL_LIBS::running_instances;

use PERL_LIBS::random_module;
#
#    Never choose
#
#use PERL_LIBS::secant_random_builtin;

### Choose one:
use PERL_LIBS::maple;
use PERL_LIBS::sage;
use PERL_LIBS::sarag;

# IntSpan
# Lets you deal with sets of integers like: "1-1000,1002-1005,1007,1009-1010"
# http://search.cpan.org/perldoc?Set::IntSpan
#use PERL_LIBS::IntSpan qw(grep_set map_set grep_spans map_spans);



return 1;
__END__
