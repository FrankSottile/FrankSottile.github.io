#!/bin/bash
##### Backup of FRSC-secant database #####
# Contains portions of code from:
# http://blogs.linux.ie/xeer/2005/06/28/simple-mysql-backup/
# http://ocaoimh.ie/2005/06/28/simple-mysql-backup/
# http://www.vbulletin.com/forum/showthread.php?threadid=4256

# List all of the MySQL databases that you want to backup in here, 
# each seperated by a space
databases="secant"

# Directory where you want the backup files to be placed
backupdir="$HOME/frsc/db-backups"

d=$(date +'%Y-%m-%d')
t=$(date +'%H-%M-%S')

# MySQL dump command, use the full path name here
mysqldumpcmd="/usr/bin/mysqldump"
dumpoptions=" --opt --comments"

# MySQL conf file: securely contains username, password, etc
#mysqlconf="./mysql.secant.conf"

# Unix Commands
gzip="/usr/bin/gzip"
tar="/bin/tar"
uuencode="/usr/bin/uuencode"
mail="/usr/bin/mail"
rm="/bin/rm"

# Send Backup?  Would you like the backup emailed to you?
# Set to "y" if you do
#sendbackup="n"
#subject="FRSC MySQL Backup, date $d"
#mailto="<username>@math.tamu.edu"

# Create our backup directory if not already there
mkdir -p $backupdir
if [ ! -d $backupdir ] 
then
  echo "Not a directory: $backupdir"
  exit 1
fi

# Dump all of our databases
# echo "Dumping MySQL Databases"
for database in $databases
do
#   $mysqldumpcmd $dumpoptions \
#     --defaults-extra-file=$mysqlconf \
#     $database \
#     > $backupdir/$database-$d-$t.sql
  $mysqldumpcmd $dumpoptions \
    $database \
    > $backupdir/$database-$d-$t.sql
done

# Compress all of our backup files
# echo "Compressing Dump Files"
for database in $databases
do
  $gzip $backupdir/$database-$d-$t.sql
done

# Send the backups via email
#if [ $sendbackup = "y" ]
#then
#   for database in $databases
#   do
#      $uuencode $backupdir/$database-$d-$t.sql.tar.gz \
#        > $backupdir/$database-$d-$t.sql.tar.gz.uu
#      $mail -s "$subject : $database" $mailto \
#        < $backupdir/$database-$d-$t.sql.tar.gz.uu
#      $rm $backupdir/$database-$d-$t.sql.tar.gz.uu
#   done
#fi

# And we're done
# ls -l $backupdir
# echo "Dump Complete!"
exit
