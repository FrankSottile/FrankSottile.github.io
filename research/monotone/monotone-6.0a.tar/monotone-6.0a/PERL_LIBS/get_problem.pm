use 5.008006;
use strict;
use warnings;

# v1.0.4 - 3/24/09 - zach: start keeping track of which packets have been started,
#   don't work on requests with priority < 0

# read_input_text_problem   Has been deleted
#

########################

# get_a_problem_to_work_on:
#   Contacts the database.
#   Gets the highest-priority problem with outstanding instances
#   if necessary, creates a random seed
#   create a running instance record
#   If found a problem, return relevant info in $problemhash
#   otherwise return 0
sub get_a_problem_to_work_on {
  my ($dbhr, $compid, $config) = @_;
    
  my $initseed;
  
  # Status message
  
  if( $config->{'verbosity'} >= 2 ) {
    print "(".localtime().") Looking for problem to work on...\n";
  }
  
  # Connect to database
    
  my $dbh = DBI->connect($dbhr->{'datasource'},
                        $dbhr->{'db_user_name'},
                        $dbhr->{'db_password'},
                        {RaiseError => 1,
                         AutoCommit => 0});
    
  ###########################################################
  # first we look for running instances that have been hanging
  # if they exist, we restart them
  ##########################################################
    
  my $prob;
  $prob = &cleanup_stalls($dbh, $config);
  #
  #   Pass $config to cleanup_stalls  (fix to a boolean value 0)
  #
  if ( $prob != 0 ) {
    # Found a stalled RunningInstance: Take it over!
    # (the frsc_cleanup_stalls routine already deleted the old RunningInstance record)
    # Post a new RunningInstance record
    if( $config->{'verbosity'} >= 2 ) {
        print "Found a stalled RunningInstance to take over.\n";
    }
    my ($run_id,$expectedfinishtime,$time_to_complete) = create_running_instance($config,$prob,$dbh);
    $dbh->disconnect();
    $prob->{'runninginstance_id'} = $run_id;
    $prob->{'expectedfinishtime'} = $expectedfinishtime;
    $prob->{'timetocomplete'}     = $time_to_complete;
    return $prob;
  }
  # There weren't any stalled RunningInstances:  Search for a request that is not yet completed
  #   First sort first by reverse comutationlength 
  #   (less than MY_COMPUTATION_LENGTH found in config file) and then by priority
  
  if( $config->{'verbosity'} >= 2 ) {
    print "No stalled RunningInstances found. Looking for a request to work on...\n";
  }

  my $configcomplengthid = $config->{'MY_COMPUTATION_LENGTH'};
  # Try to fetch a request 
  my $sth = $dbh->prepare(qq{SELECT id, totalnumpackets,  packetnumber,
        schubertproblem_id, computationtype_id, computationlength_id, algebraprogram, necklace_id, 
        number_necklaces, priority, initialrandseed, packetsize, numcomputationsperfile, mhzsecondsperinstance
        FROM Requests WHERE (packetnumber < totalnumpackets)
        AND ( computationlength_id <= $configcomplengthid )
        AND ( priority >= 0 )
        ORDER BY computationlength_id DESC, priority DESC LIMIT 1 FOR UPDATE});
  $sth->execute();
    
  # if there is a request to do
  if ( my ($request_id, $totalnumpackets, $packetnumber, $schubertproblem_id, $computationtype_id, 
           $computationlength_id, $algebraprogram, $necklace_id, $number_necklaces, $priority, $initialrandseed, 
           $packetsize, $numcomputationsperfile, $mhzsecondsperinstance) = $sth->fetchrow_array() ) {      
        $packetnumber++;
        
    # if first time problem worked on: need to initialize random seed
    if ( $initialrandseed == 0 ) {
      $initialrandseed = &generate_random_seed();
    }
    $initseed = &find_packet_random_seed($initialrandseed,$packetnumber);
    $dbh->do(qq{UPDATE Requests
            SET packetnumber='$packetnumber',
            initialrandseed='$initialrandseed'
            WHERE id='$request_id';});
        
    #################################################
    # now we must get the Schubert problem to work on
    #
    my $sth3 = $dbh->prepare(qq{SELECT problemname, schubertconditions, numsolutions,
            flagvariety, dimension,  
            necklaces
            FROM SchubertProblems JOIN FlagVariety JOIN Necklaces 
            WHERE (SchubertProblems.flagvariety_id = FlagVariety.id
                   and Necklaces.id = '$necklace_id' 
                   and SchubertProblems.id = '$schubertproblem_id')});
    $sth3->execute();
    my ($problemname, $schubertconditions, $numsolutions, $flagvariety,
         $dimension, $necklaces ) = $sth3->fetchrow_array();
    my $problemhash = {
            'packetnumber'         => $packetnumber,
            'priority' 		   => $priority,
            'computationlength_id' => $computationlength_id,
            'request_id'           => $request_id,
            'totalnumpackets'      => $totalnumpackets,
	    'computationtypeid'    => $computationtype_id,
            'algebraprogram'       => $algebraprogram, 
            'necklace_id'          => $necklace_id,
            'number_necklaces'     => $number_necklaces, 
            'initseed'             => $initseed,
            'packetsize'           => $packetsize, 
            'numcomputationsperfile'  => $numcomputationsperfile,
	    'schubertproblem_id'   => $schubertproblem_id,
            'problemname'          => $problemname,
            'schubertconditions'   => $schubertconditions,
            'numsolutions'         => $numsolutions,
	    'mhzsecondsperinstance' => $mhzsecondsperinstance,
            'flagvariety'          => $flagvariety,
            'dimension'            => $dimension,
            'necklaces'            => $necklaces, 
    };

    # create a "running instance" in the dbase
    my ($run_id,$expectedfinishtime,$time_to_complete)
      = &create_running_instance($config,$problemhash,$dbh);
    
    $sth->finish();
    $sth3->finish();
    $dbh->commit();
    $dbh->disconnect();   # disconnect until computation is done

    $problemhash->{'runninginstance_id'} = $run_id;
    $problemhash->{'expectedfinishtime'} = $expectedfinishtime;
    $problemhash->{'timetocomplete'}     = $time_to_complete;
    return $problemhash;
        
    } else {
        $sth->finish();
        $dbh->disconnect();
        return 0; # couldn't get a problem to work on
    }
}


###############################################################################
# set_up_filenames:
# Set up a hash reference with a bunch of filenames of temporary files
# This is be repeated for every subpacket.
# Also, make sure the directory where the temporary files will live exists.
##############################################################################
sub set_up_filenames {
  my ($prob) = @_;
    
  my $files;
  $files->{'random_string'} = "";
  use Sys::Hostname;
  $files->{'host'} = hostname;	   # get computer host name
  
  # Check temporary directory exists and is a directory
  if ( ! (-e "frsc-tmp" && -d "frsc-tmp") ) {
    mkdir("frsc-tmp")
      or die "Couldn't create temp directory (frsc-tmp).";
  }
  if ( ! (-e "frsc-tmp/$files->{'host'}"
              && -d "frsc-tmp/$files->{'host'}") ) {
    mkdir("frsc-tmp/$files->{'host'}")
      or die "Couldn't create temp directory (host=$files->{'host'}).";
  }
  
 
  $files->{'fileroot'} = "frsc-tmp/$files->{'host'}/"
                          ."req$prob->{'request_id'}-"
                          ."packet$prob->{'packetnumber'}-"
                          ."subpacket$prob->{'subpacket'}-"
                          ."pid$$-"
                          ."$files->{'random_string'}";
    
  $files->{'singularinput'}    = "$files->{'fileroot'}.sing";
  $files->{'macaulayinput'}    = "$files->{'fileroot'}.m2";
  $files->{'singularoutput'}   = "$files->{'fileroot'}.alg.out";
  $files->{'macaulayoutput'}   = "$files->{'fileroot'}.alg.out";
  $files->{'algebraoutput'}    = "$files->{'fileroot'}.alg.out";
  $files->{'mapleinput'}       = "$files->{'fileroot'}.maple";
  $files->{'sageinput'}        = "$files->{'fileroot'}.sage";
  $files->{'results'}          = "$files->{'fileroot'}.results";
  $files->{'sagepy'}           = "$files->{'fileroot'}.py";
    
    return $files;
}

# cleanup_stalls
# Look for stalled RunningInstances. If one is found, take it over.
# v1.0.4: Don't pick up stalls with priority < 0.
#
# Input:
#   dbh - handle to database connection
#   config - hashref with configuration info,
#      especially MY_COMPUTATION_LENGTH
# Output & behavior:
#   If a stalled RunningInstance is found:
#     1. retrieve all the information about the packet it was working
#     2. delete stalled instance record!
#     3. return problem info
#     Caller takes care of actually creating new RunningInstance.
#   If no stalled RunningInstance is found:
#     1. NO database changes
#     2. return 0 [would it be better to return, e.g., NULL?]
sub cleanup_stalls {
    my ($dbh,$config) = @_;
    
    my $thedatetime = time(); # time in seconds since epoch
                                       # (epoch = 1970)
    my $stallwindow = $config->{'stallwindow_days'}*24*60*60; # 1 day in seconds
    
    # need to check request table for priority and computationlength_id
    my $configcomplengthid = $config->{'MY_COMPUTATION_LENGTH'};
    my $sth = $dbh->prepare(qq{SELECT id FROM RunningInstance
                WHERE (expected_time_to_finish < $thedatetime-$stallwindow)
                AND ( computationlength_id <= $configcomplengthid )
                AND ( priority >= 0 )
                ORDER BY computationlength_id DESC, priority DESC, startdate
                LIMIT 1   FOR UPDATE});
    $sth->execute();

    if( my ($old_run_id) = $sth->fetchrow_array() ) {
        # Found a stalled RunningInstance. Take it over.
        # 1. retrieve all the information about the packet it was working
        my $prob = &get_problem_info_from_runninginstance($old_run_id,$dbh);
        # 2. delete stalled instance record!
        $dbh->do(qq{DELETE FROM RunningInstance WHERE id = '$old_run_id'});
        # 3. return problem info
        # Caller takes care of actually creating new RunningInstance.
        $sth->finish();
        $dbh->commit();
        return $prob;
    } else {
        $sth->finish();
        return 0 ;
    }
}


return 1;
__END__

