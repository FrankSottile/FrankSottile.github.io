#!/usr/bin/perl -w
#
# This file is designed to create a single input file for the monotone
# conjecture; its purpose is to help Frank write the code
#
#
use PERL_LIBS::monotone;

my $config;
$config = initial_setup("my_config.txt",\@ARGV);

$config->{'KEEPTEMPFILES'} = 1;

my $options = {
    'FLUSH_WORKING' => $config->{'FLUSH_WORKING'},
    'KEEPTEMPFILES' => $config->{'KEEPTEMPFILES'},
    'TEXTPROBLEMINPUT' => $config->{'TEXTPROBLEMINPUT'},
    'verbosity' => $config->{'verbosity'},
    'noflylist' => $config->{'noflylist'},
    'rootfinder' => $config->{'rootfinder'},
};

my $paths = {
    'singular' => $config->{'SINGULAR_path'},
    'macaulay' => $config->{'MACAULAY_path'},
    'maple'    => $config->{'MAPLE_path'},
    'sage'     => $config->{'SAGE_path'},
};


#my ($cpufreq,$host) = (2600,'hopf');
#my ($cpufreq,$host) = (1600,'Schur.local');
#
my ($cpufreq,$host) = (2400,'miln303');

if ( !(-e "frsc-tmp/$host") ) {
    mkdir "frsc-tmp/$host";
}

@master_points=@{get_points( )};
$masterpoints=\@master_points;
##########################################################################
#
#  Setting up problemhash
#
my $packetsize; my $initseed; my $problemname;my $loopsize; my $schubertconditions; 
my $necklaces; my $numsolutions; my $flagvariety; my $dimension; my $totalnumpackets; 
my $numcomputationsperfile;


####   X^2Y^2Z^2  
$packetsize=1;
$initseed=1;
$problemname='X^2Y^2Z^2';
$loopsize=11;
$schubertconditions='[2,1,3,4][2,1,3,4][1,3,2,4][1,3,2,4][1,2,4,3][1,2,4,3]';
$necklaces='[1,2,3,4,5,6][1,2,3,5,4,6][1,2,3,6,4,5][1,2,4,5,3,6][1,3,2,4,5,6][1,3,2,5,4,6][1,4,2,3,5,6][1,4,2,5,3,6][1,4,2,6,3,5][1,5,2,3,4,6][1,5,2,4,3,6]';
$numsolutions=2;
$flagvariety='1,2,3';
$dimension=4;
$totalnumpackets=1;
$numcomputationsperfile=1;


####   X21XY11Y^2  
$packetsize=1;
$initseed=11;
$problemname='X21XY11Y^2';
$loopsize=6;
$schubertconditions='[2,4,1,3,5][1,3,2,4,5][1,3,4,2,5][1,2,4,3,5][1,2,4,3,5]';
$necklaces='[1,2,3,4,5][1,2,4,3,5][1,2,5,3,4][1,3,2,4,5][1,3,4,2,5][1,4,2,3,5]';
$numsolutions=3;
$flagvariety='2,3';
$dimension=5;
$totalnumpackets=1;
$numcomputationsperfile=3;

####   X2X^2Y^4 
$packetsize=1;
$initseed=11;
$problemname='X2X^2Y^4';
$loopsize=9;
$schubertconditions='[1,4,2,3,5][1,3,2,4,5][1,3,2,4,5][1,2,4,3,5][1,2,4,3,5][1,2,4,3,5][1,2,4,3,5]';
$necklaces='[1,2,3,4,5,6,7][1,2,4,3,5,6,7][1,2,5,3,4,6,7][1,2,6,3,4,5,7][1,2,7,3,4,5,6][1,3,4,2,5,6,7][1,3,5,2,4,6,7][1,3,6,2,4,5,7][1,4,5,2,3,6,7]';
$numsolutions=7;
$flagvariety='2,3';
$dimension=5;
$totalnumpackets=1;
$numcomputationsperfile=30;


####   Y^3Z^2
$packetsize=1;
$initseed=11;
$problemname='Y^3Z^2';
$loopsize=2;
$schubertconditions='[1,3,2,4][1,3,2,4][1,3,2,4][1,2,4,3][1,2,4,3]';
$necklaces='[1,2,3,4,5][1,2,4,3,5]';
$numsolutions=2;
$flagvariety='2,3';
$dimension=4;
$totalnumpackets=1;
$numcomputationsperfile=1;

####    V^2W3W^4
$packetsize=1;
$initseed=11;
$problemname='V^2W3W^4';
$loopsize=9;
$schubertconditions='[2,1,3,4,5,6][2,1,3,4,5,6][1,5,2,3,4,6][1,3,2,4,5,6][1,3,2,4,5,6][1,3,2,4,5,6][1,3,2,4,5,6]';
$necklaces='[1,2,3,4,5,6,7][1,2,4,3,5,6,7][1,2,5,3,4,6,7][1,3,2,4,5,6,7][1,3,5,2,4,6,7][1,4,2,3,5,6,7][1,5,2,3,4,6,7][1,5,3,2,4,6,7][1,6,2,3,4,5,7]';
$numsolutions=4;
$flagvariety='1,2';
$dimension=6;
$totalnumpackets=1;
$numcomputationsperfile=1;


my $prob = {
#          'request_id'     => $request_id,
#          'packetnumber'   => $packetnumber,
          'packetsize'     => $packetsize,
          'initseed'       => $initseed,
          'problemname'    => $problemname,
          'loopsize'       => $loopsize,		 
          'schubertconditions' => $schubertconditions,
#
         'algebraprogram'  => "singular",
#           'algebraprogram'  => "macaulay",
          'necklaces'      => $necklaces,
          'numsolutions'   => $numsolutions,
          'flagvariety'    => $flagvariety,
          'dimension'      => $dimension,
          'totalnumpackets' => $totalnumpackets,
          'numcomputationsperfile'  => $numcomputationsperfile,
#	  'schubertproblem_id' => $schubertproblem_id,
	  'computationlength_id' => 4,    # The problem is assumed to be a home computer problem that 
		 			  # will take a long time to finish computing

#          'computationtypeid' => 4, # monotone conjecture
#          'computationtypeid' => 5, # Full monotone secant conjecture
          'computationtypeid' => 6, # Full monotone secant conjecture with one osculating flag

          'priority' => 1,

    };

frsc_srand($prob->{'initseed'});

# now compute $packetsize number of singular computations
# each singular computation consists of a long file with 
# $numcomputationsperfile computations per singular file
		
# Store results & failures for the whole packet:
my %packetresultstable;
my @packetfailures;

#
#   loop over packets
#		
for ( my $i = 0; $i < $prob->{'packetsize'}; $i++ ) {
	  
  # Store results & failures for just this file ("subpacket")
  my %subpacketresultstable;
  my @subpacketfailures;
	  
  $prob->{'subpacket'} = $i;

  my $files;
  $files->{'fileroot'}  = "frsc-tmp/$host/$prob->{'problemname'}";
  $files->{'singularinput'}    = "$files->{'fileroot'}.sing";
  $files->{'macaulayinput'}    = "$files->{'fileroot'}.m2";
  $files->{'singularoutput'}   = "$files->{'fileroot'}.alg.out";
  $files->{'macaulayoutput'}   = "$files->{'fileroot'}.alg.out";
  $files->{'algebraoutput'}    = "$files->{'fileroot'}.alg.out";
  $files->{'mapleinput'}       = "$files->{'fileroot'}.maple";
  $files->{'sageinput'}        = "$files->{'fileroot'}.sage";
  $files->{'results'}          = "$files->{'fileroot'}.results";
  $files->{'sagepy'}           = "$files->{'fileroot'}.py";

  # Write Algebra input file

  # For computation types 4 and up, we do not compute crossing numbers.  We just assign
  # the crossing nunber to the index of the corresponding necklace.  This has been renamed in the code
  #
  printf "Algebra program = %s\n", $prob->{'algebraprogram'} ;

  my @crossnumbers;
  eval {
    @crossnumbers = write_algebra_file($options,$prob,$files,$masterpoints);
    if ( $#crossnumbers == 0  ) {
   die "Writing Singular/Macaulay input file failed.";
    }
  };
  if( $@ ) { # $@ contains any error/exception from inside eval
    die;
  }
  
  # run algebra input file
  eval {
    my $status;
    if ( $prob->{'algebraprogram'} eq 'singular' ) {
      $status = system("nice -n20 $paths->{'singular'} -q < $files->{'singularinput'}");
    } elsif ( $prob->{'algebraprogram'} eq 'macaulay' ) {
      $status = system("nice -n20 $paths->{'macaulay'} --script $files->{'macaulayinput'}");
    }
    if ( $status != 0 ) {
    # Singular/Macaulay run failed.
    # Put an error message and stop the computation.

    die "Singular/Macaulay run failed.";
    }
  };
  if( $@ ) { # $@ contains any error/exception from inside eval
    die;
  }

  #########################################################################
  # Find number of real roots.
  # Use maple or sage according to $config->{'rootfinder'}
  
  if ( $config->{'rootfinder'} eq 'maple' ) {
    # Using Maple:
    # creates new maple file
    eval {
     if ( ! write_maple_input_file($prob,$files) ) {
    die "Writing Maple input file failed.";
      }
    };
    if( $@ ) { # $@ contains any error/exception from inside eval
      die;
   }
   # run maple file :
   eval {
      $status = system("nice -n20 $paths->{'maple'} -q < $files->{'mapleinput'} > $files->{'results'}");
      if( $status != 0 ) {

      # See comments about the similar structure with the Singular computation. 

      die "Maple run failed.";
      }
    };
    if( $@ ) { # $@ contains any error/exception from inside eval
      die;
    }
    } elsif( $config->{'rootfinder'} eq 'sage' ) {
    # Using Sage:
   # creates new sage file
   eval {
      if ( ! write_sage_input_file($prob,$files) ) {
    die "Writing Sage input file failed.";
      }
    };
    if( $@ ) { # $@ contains any error/exception from inside eval
      die;
    }
    # run sage file :
    eval {
      $status = system("nice -n20 $paths->{'sage'} $files->{'sageinput'} > $files->{'results'}");
      if( $status != 0 ) {

    # See comments about the similar structure with the Singular computation. 

     die "Sage run failed.";
       }
     };
    if( $@ ) { # $@ contains any error/exception from inside eval
    die;
   }
  } elsif( $config->{'rootfinder'} eq 'sarag' ) {
    # Using SARAG:
  # accessed via Sage's Maxima interface
  # creates new input file at $files->{'sageinput'} location
   eval {
     if ( ! write_sarag_input_file($prob,$files) ) {
   die "Writing SARAG input file failed.";
     }
   };
  if( $@ ) { # $@ contains any error/exception from inside eval
     die;
   }
   # run SARAG file using Sage :
    eval {
     $status = system("nice -n20 $paths->{'sage'} $files->{'sageinput'} > $files->{'results'}");
     if( $status != 0 ) {

    # See comments about the similar structure with the Singular computation. 

    die "Sage/SARAG run failed.";
      }
    };
   if( $@ ) { # $@ contains any error/exception from inside eval
    die;
    }
   } else {
    # what rootfinder to use??
    # do nothing...
   die "Please specify maple, sage, or sarag to find real roots.";
    }
  
  # collect the results from the computation


  my ($a,$b) = parse_results($files->{'results'},@crossnumbers);  
    if( $a == 0 ) { # problem reading file
    die "Maple output file could not be read.";
    }
   %subpacketresultstable = %{$a};
  @subpacketfailures = @{$b};

  # Append/merge subpacket stuff to packet results & failures
  # Merge $subpacketresultstable into $packetresultstable:
  %packetresultstable = merge_two_solutions_table(\%packetresultstable,\%subpacketresultstable);
  # Append $subpacketfailures to $packetfailures:
  push(@packetfailures,@subpacketfailures);
  
  #######################################################
  #
  # Erase temporary files unless the -dd option is used
  #   OR there is a counterexample to the conjecture
  #
  #######################################################
  
  if( !$options->{'KEEPTEMPFILES'} ) {
if( frsc_count_counterexamples($prob,\%subpacketresultstable) == 0 ) {
  frsc_remove_temp_files($files) ;
}
 }
  
 # end of this subpacket
 
if( $options->{'verbosity'} >= 2 ) {
print ".";
 }
 
 # next brace goes around to the next subpacket
}
