#!/usr/bin/perl -w
##############################################################
#  Plain check in code.
##############################################################

use PERL_LIBS::monotone;

# Get configuration-file information
my $config;	 
$config = load_hash_file("my_config.txt",$config);

my $dbhr = {
    'db_server'    => $config->{'db_server'},
    'db_user_name' => $config->{'db_user_name'},
    'db_password'  => $config->{'db_password'},
    'db_port'      => $config->{'db_port'},
    'database'     => $config->{'database'},
    'datasource'   => "DBI:mysql:"
                   ."database=$config->{'database'};"
                   ."hostname=$config->{'db_server'};"
                   ."port=$config->{'db_port'}",
};

  use Sys::Hostname; $host = hostname;	# get computer host name

my ($compid,$cpufreq) = frsc_checkin( $dbhr );

if ( !($cpufreq) ) {
    print "Could not check $host in to database $config->{'database'}.\n";
} elsif ( $cpufreq == 0 ) {
   print "Please manually enter the CPU speed of $host into database $config->{'database'}.\n";
} else {
   print "$host checked into the database $config->{'database'} on $config->{'db_server'}.\n";
}

exit;
