use 5.008006;
use strict;
use warnings;

# Checkin function
# 1. see if I am in the database already, create record if not
# 2. return computer_id, clockspeed, hostname, number of RunningInstance records
sub frsc_checkin {
  my $dbhr = $_[0]; #db_hashref
  my ($host, $sthcomp, $compid, $clockspeed);

  # connect to database
  my $dbh = DBI->connect($dbhr->{'datasource'},
                         $dbhr->{'db_user_name'},
                         $dbhr->{'db_password'},
                         {RaiseError => 1,
                          AutoCommit => 0});

  # see if I'm in the database already
  # determine the computer this code is running on
  use Sys::Hostname; $host = hostname;	# get computer host name

  $sthcomp = $dbh->prepare(qq{SELECT id,clockspeed FROM Computer WHERE 
                             (name = '$host') LIMIT 1});
  $sthcomp->execute();
  if ( ($compid,$clockspeed) = $sthcomp->fetchrow_array() ) {  # if this computer in dbase
       ;
  } else {    # must add this computer to the dbase

    # try to figure out clockspeed
    $clockspeed = figure_out_clockspeed($host);
    # figure out ostype, 1=linux 2=darwin
    my $ostype;
    if( $^O eq "linux" ) {
      $ostype = 1;
    } elsif( $^O eq "darwin" ) {
      $ostype = 2;
    }
    # figure out number of cpus
    my $numcpus = figure_out_numcpus();

    my $sth2 = $dbh->prepare(qq{INSERT INTO Computer
	       (name,clockspeed,ostype_id,numcpus)
	       VALUES ('$host','$clockspeed','$ostype','$numcpus')});
    $sth2->execute();
    $compid = $dbh->{'mysql_insertid'};		
    $sth2->finish();
  }
  
  $sthcomp = $dbh->prepare(qq{SELECT COUNT(id) FROM RunningInstance WHERE computer_id='$compid'});
  $sthcomp->execute();
  my ($num_running_instances) = $sthcomp->fetchrow_array();
    
  # disconnect from database
  $sthcomp->finish();
  $dbh->commit();
  $dbh->disconnect();
   	
  return ($compid,$clockspeed,$host,$num_running_instances);
}

# Find and return clockspeed in MHz
# Interesting article about CPU speed:
#   http://www.sheepguardingllama.com/?p=2287
# (to do: this no longer needs to know $host, take that out)
sub figure_out_clockspeed {
  my $host = $_[0];
    
  my $clockspeed;
    
  if( $^O eq "darwin" ) {
        
    $clockspeed = `/usr/sbin/sysctl -n hw.cpufrequency`;
    chomp($clockspeed);
    # on mac: "2.2 GHz" = 2200000000 Hz
    # make this into MHz
    $clockspeed /= 1000000;
    return $clockspeed;
 
   } elsif ( $^O eq "linux" ) {
        
    # Try to read info from /proc/cpuinfo
    # WORKS FOR INTEL ONLY.
     
    # Intel:
    # There are two relevant lines per CPU:
    # model name    : Intel(R) Pentium(R) 4 CPU 1.80GHz
    # cpu MHz       : 1794.856
    #
    # We read from the "model" line, as the other reflects the actual 
    # speed, which can be dramatically less whhen the CPU is throttled down
        
    # AMD:
    # Again two relevant lines per CPU:
    # model name    : AMD Athlon(tm) 64 X2 Dual Core Processor 5000+
    # cpu MHz       : 2600.000
    # 
    #  The "model" line does not have CPU speed, and the cpu MHz line is not
    # necessarily accurate.
    # So for AMD, just put cpuspeed=0 and let the humans figure it out. 

    my $cpuinfo =  `grep model /proc/cpuinfo | grep name`;
 
    if( $cpuinfo =~ m/Intel/ ) {  # Have an Intel chip
        $cpuinfo =~ m/([.0-9]+)GHz/g; # cpu speed in GHz
       my $clockspeed = $1*1000; # convert to MHz
        return $clockspeed;
     } elsif( $cpuinfo =~ m/AMD/ ) {
         return 0 ;
     } else {
        # Unknown cpu type?
        return 0 ;
     }
        
   } else {
        # Unknown OS?
        return 0;
  }
}


# figure_out_numcpus
# Try to figure out the number of CPUs,
# by reading sysctl on macs and /proc/cpuinfo on linux
# If it's not readable, return 0
# (then humans have to enter info in database)
# No input
# Just return numcpus
sub figure_out_numcpus {
  my $numcpus;
  if ( $^O eq "darwin" ) {
    $numcpus = `/usr/sbin/sysctl -n hw.ncpu`;
#    $numcpus = `/usr/bin/sysctl -n hw.ncpu`;
  } elsif ( $^O eq "linux" ) {
    $numcpus = `cat /proc/cpuinfo | grep "^processor" | wc -l`;
  } else {
    $numcpus = 0;
  }
  return $numcpus;
}

return 1;
__END__
